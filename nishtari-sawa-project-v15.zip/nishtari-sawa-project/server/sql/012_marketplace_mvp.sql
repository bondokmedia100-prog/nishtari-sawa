ALTER TABLE users
  ADD COLUMN governorate TEXT,
  ADD COLUMN city TEXT,
  ADD COLUMN address TEXT,
  ADD COLUMN latitude DOUBLE PRECISION,
  ADD COLUMN longitude DOUBLE PRECISION,
  ADD CONSTRAINT users_egyptian_governorate CHECK (governorate IS NULL OR governorate IN (
    'القاهرة', 'الجيزة', 'الإسكندرية', 'الدقهلية', 'البحر الأحمر', 'البحيرة', 'الفيوم',
    'الغربية', 'الإسماعيلية', 'المنوفية', 'المنيا', 'القليوبية', 'الوادي الجديد', 'السويس',
    'أسوان', 'أسيوط', 'بني سويف', 'بورسعيد', 'دمياط', 'الشرقية', 'جنوب سيناء', 'كفر الشيخ',
    'مطروح', 'الأقصر', 'قنا', 'شمال سيناء', 'سوهاج'
  )),
  ADD CONSTRAINT users_profile_text_bounds CHECK (
    (city IS NULL OR length(trim(city)) BETWEEN 1 AND 100) AND
    (address IS NULL OR length(trim(address)) BETWEEN 1 AND 300)
  ),
  ADD CONSTRAINT users_coordinates_pair CHECK ((latitude IS NULL) = (longitude IS NULL)),
  ADD CONSTRAINT users_coordinates_egypt_bounds CHECK (
    latitude IS NULL OR (latitude BETWEEN 21.7 AND 31.8 AND longitude BETWEEN 24.5 AND 37.0)
  );

ALTER TABLE supplier_profiles
  ADD COLUMN business_address TEXT,
  ADD COLUMN business_phone TEXT,
  ADD CONSTRAINT supplier_business_address_bounds CHECK (
    business_address IS NULL OR length(trim(business_address)) BETWEEN 5 AND 300
  ),
  ADD CONSTRAINT supplier_business_phone_format CHECK (
    business_phone IS NULL OR business_phone ~ '^[+][1-9][0-9]{7,14}$'
  );

ALTER TABLE products
  ADD COLUMN image_data BYTEA,
  ADD COLUMN image_mime_type TEXT,
  ADD CONSTRAINT product_image_pair CHECK ((image_data IS NULL) = (image_mime_type IS NULL)),
  ADD CONSTRAINT product_image_bounds CHECK (image_data IS NULL OR octet_length(image_data) <= 358400),
  ADD CONSTRAINT product_image_mime CHECK (image_mime_type IS NULL OR image_mime_type IN ('image/jpeg', 'image/png', 'image/webp'));

ALTER TABLE program_profile
  ADD COLUMN brand_logo_url TEXT,
  ADD COLUMN brand_primary_color TEXT NOT NULL DEFAULT '#0B7A75',
  ADD COLUMN brand_accent_color TEXT NOT NULL DEFAULT '#E97845',
  ADD CONSTRAINT program_profile_logo_https CHECK (brand_logo_url IS NULL OR brand_logo_url ~* '^https://'),
  ADD CONSTRAINT program_profile_primary_color CHECK (brand_primary_color ~ '^#[0-9A-Fa-f]{6}$'),
  ADD CONSTRAINT program_profile_accent_color CHECK (brand_accent_color ~ '^#[0-9A-Fa-f]{6}$');

CREATE TABLE product_reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  membership_id UUID NOT NULL UNIQUE REFERENCES deal_memberships(id) ON DELETE CASCADE,
  deal_id UUID NOT NULL REFERENCES deals(id) ON DELETE CASCADE,
  buyer_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  rating SMALLINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment TEXT NOT NULL CHECK (length(trim(comment)) BETWEEN 1 AND 1000),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX product_reviews_deal_idx ON product_reviews (deal_id, created_at DESC);
CREATE INDEX product_reviews_buyer_idx ON product_reviews (buyer_id, created_at DESC);

CREATE TABLE support_tickets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  subject TEXT NOT NULL CHECK (length(trim(subject)) BETWEEN 3 AND 120),
  message TEXT NOT NULL CHECK (length(trim(message)) BETWEEN 1 AND 2000),
  status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'in_progress', 'resolved', 'closed')),
  admin_reply TEXT CHECK (admin_reply IS NULL OR length(trim(admin_reply)) <= 2000),
  replied_by UUID REFERENCES users(id) ON DELETE SET NULL,
  replied_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX support_tickets_user_idx ON support_tickets (user_id, created_at DESC);
CREATE INDEX support_tickets_status_idx ON support_tickets (status, updated_at DESC);

CREATE TABLE supplier_notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  supplier_user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  event_type TEXT NOT NULL CHECK (event_type = 'order.created'),
  payload JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  read_at TIMESTAMPTZ
);

CREATE INDEX supplier_notifications_user_idx ON supplier_notifications (supplier_user_id, created_at DESC);

CREATE FUNCTION notify_supplier_of_new_membership() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
  deal_row RECORD;
  committed BIGINT;
  remaining BIGINT;
  notification_payload JSONB;
BEGIN
  SELECT d.id AS deal_id, d.supplier_id, d.moq, p.name AS product_name, p.emoji,
         sp.user_id AS supplier_user_id
  INTO deal_row
  FROM deals d
  JOIN products p ON p.id = d.product_id
  JOIN supplier_profiles sp ON sp.id = d.supplier_id
  WHERE d.id = NEW.deal_id;

  IF deal_row.supplier_user_id IS NULL THEN
    RETURN NEW;
  END IF;

  SELECT COALESCE(sum(m.quantity), 0)::bigint INTO committed
  FROM deal_memberships m
  WHERE m.deal_id = NEW.deal_id AND (
    m.status = 'held' OR
    (m.status = 'pending_payment' AND (m.reservation_expires_at IS NULL OR m.reservation_expires_at > now()))
  );
  remaining := greatest(0, deal_row.moq - committed);
  notification_payload := jsonb_build_object(
    'orderId', NEW.id,
    'dealId', NEW.deal_id,
    'productName', deal_row.product_name,
    'emoji', deal_row.emoji,
    'quantity', NEW.quantity,
    'remainingToMoq', remaining
  );

  INSERT INTO supplier_notifications (supplier_user_id, event_type, payload)
  VALUES (deal_row.supplier_user_id, 'order.created', notification_payload);

  INSERT INTO notification_outbox (channel, user_id, event_type, payload)
  SELECT 'push', deal_row.supplier_user_id, 'order.created', jsonb_build_object(
    'title', 'طلب جديد',
    'body', deal_row.product_name || ': ' || NEW.quantity::text || ' وحدة جديدة.',
    'data', notification_payload
  )
  WHERE EXISTS (SELECT 1 FROM push_devices WHERE user_id = deal_row.supplier_user_id);

  RETURN NEW;
END;
$$;

CREATE TRIGGER deal_membership_supplier_notification
AFTER INSERT ON deal_memberships
FOR EACH ROW EXECUTE FUNCTION notify_supplier_of_new_membership();
