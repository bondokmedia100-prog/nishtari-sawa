ALTER TABLE deal_memberships
  ADD COLUMN request_fingerprint TEXT;
ALTER TABLE deal_memberships
  ADD CONSTRAINT membership_request_fingerprint_format
    CHECK (request_fingerprint IS NULL OR request_fingerprint ~ '^[a-f0-9]{64}$');

UPDATE deal_memberships
SET reservation_expires_at = LEAST(created_at + interval '15 minutes', now())
WHERE status = 'pending_payment' AND reservation_expires_at IS NULL;

ALTER TABLE deal_memberships
  ADD CONSTRAINT pending_membership_requires_expiry
    CHECK (status <> 'pending_payment' OR reservation_expires_at IS NOT NULL),
  DROP CONSTRAINT deal_memberships_deal_id_buyer_id_key;

CREATE UNIQUE INDEX deal_memberships_non_cancelled_buyer_idx
  ON deal_memberships (deal_id, buyer_id)
  WHERE status <> 'cancelled';

CREATE INDEX deal_memberships_reservation_expiry_idx
  ON deal_memberships (reservation_expires_at)
  WHERE status = 'pending_payment';

ALTER TABLE notification_outbox
  ADD COLUMN suppressed_at TIMESTAMPTZ;
