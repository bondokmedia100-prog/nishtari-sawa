ALTER TABLE payments
  ADD COLUMN payment_method TEXT CHECK (payment_method IN ('vodafone_cash', 'instapay')),
  ADD COLUMN transfer_reference TEXT CHECK (transfer_reference IS NULL OR length(trim(transfer_reference)) BETWEEN 1 AND 80),
  ADD COLUMN receipt_data BYTEA,
  ADD COLUMN receipt_mime_type TEXT,
  ADD COLUMN submitted_at TIMESTAMPTZ,
  ADD COLUMN reviewed_by UUID REFERENCES users(id) ON DELETE SET NULL,
  ADD COLUMN reviewed_at TIMESTAMPTZ,
  ADD COLUMN review_note TEXT CHECK (review_note IS NULL OR length(trim(review_note)) BETWEEN 1 AND 300),
  ADD COLUMN updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  ADD CONSTRAINT payment_receipt_pair CHECK ((receipt_data IS NULL) = (receipt_mime_type IS NULL)),
  ADD CONSTRAINT payment_receipt_size CHECK (receipt_data IS NULL OR octet_length(receipt_data) <= 1048576),
  ADD CONSTRAINT payment_receipt_mime CHECK (receipt_mime_type IS NULL OR receipt_mime_type IN ('image/jpeg', 'image/png', 'image/webp'));

CREATE INDEX payments_manual_review_idx ON payments (status, submitted_at DESC)
  WHERE status = 'submitted';

DROP TRIGGER deal_membership_supplier_notification ON deal_memberships;
CREATE TRIGGER deal_membership_supplier_notification
AFTER UPDATE OF status ON deal_memberships
FOR EACH ROW
WHEN (OLD.status = 'pending_payment' AND NEW.status = 'held')
EXECUTE FUNCTION notify_supplier_of_new_membership();
