import { readFile, readdir } from "node:fs/promises"

const sqlDirectory = new URL("../sql/", import.meta.url)

export async function runMigrations(pool, { seedDemoData = process.env.SEED_DEMO_DATA === "true" } = {}) {
  const files = (await readdir(sqlDirectory)).filter((name) => /^\d+.*\.sql$/.test(name)).sort()
  const client = await pool.connect()
  try {
    await client.query("BEGIN")
    await client.query("SELECT pg_advisory_xact_lock(780214, 1)")
    await client.query(`CREATE TABLE IF NOT EXISTS schema_migrations (
      filename TEXT PRIMARY KEY,
      applied_at TIMESTAMPTZ NOT NULL DEFAULT now()
    )`)
    await client.query("COMMIT")
  } catch (error) {
    await client.query("ROLLBACK")
    throw error
  } finally {
    client.release()
  }

  for (const filename of files) {
    if (!seedDemoData && ["002-seed.sql", "003-demo-deal-window.sql"].includes(filename)) continue
    const migrationClient = await pool.connect()
    try {
      await migrationClient.query("BEGIN")
      await migrationClient.query("SELECT pg_advisory_xact_lock(780214, 1)")
      const applied = await migrationClient.query("SELECT 1 FROM schema_migrations WHERE filename = $1", [filename])
      if (!applied.rowCount) {
        const sql = await readFile(new URL(filename, sqlDirectory), "utf8")
        await migrationClient.query(sql)
        await migrationClient.query("INSERT INTO schema_migrations (filename) VALUES ($1)", [filename])
      }
      await migrationClient.query("COMMIT")
    } catch (error) {
      await migrationClient.query("ROLLBACK")
      throw error
    } finally {
      migrationClient.release()
    }
  }
}
