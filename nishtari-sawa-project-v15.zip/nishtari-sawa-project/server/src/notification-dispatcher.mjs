import { postPublicWebhook } from "./webhook-transport.mjs"

const RETRY_LIMIT = 8
const CLAIM_QUERY = `
  UPDATE notification_outbox
  SET locked_at = now(), attempts = attempts + 1
  WHERE id = (
    SELECT id FROM notification_outbox
    WHERE sent_at IS NULL AND suppressed_at IS NULL AND available_at <= now() AND attempts < $1
      AND (locked_at IS NULL OR locked_at < now() - interval '2 minutes')
      AND channel = $2
    ORDER BY created_at
    FOR UPDATE SKIP LOCKED
    LIMIT 1
  )
  RETURNING id, channel, user_id, event_type, payload, attempts
`

export function startNotificationDispatcher(pool, logger, {
  webhookUrl = process.env.N8N_WEBHOOK_URL,
  webhookSecret = process.env.N8N_WEBHOOK_SECRET,
  getWebhookConfig,
  webhookPoster = postPublicWebhook,
  fetcher = fetch,
  intervalMs = 2000,
} = {}) {
  let running = false
  let stopped = false

  async function deliver(channel, webhookConfig) {
    const client = await pool.connect()
    let event
    try {
      await client.query("BEGIN")
      const claimed = await client.query(CLAIM_QUERY, [RETRY_LIMIT, channel])
      event = claimed.rows[0]
      await client.query("COMMIT")
    } catch (error) {
      await client.query("ROLLBACK")
      throw error
    } finally {
      client.release()
    }
    if (!event) return false

    try {
      if (channel === "n8n") {
        await deliverWebhook(pool, event, webhookConfig, webhookPoster)
      } else {
        await deliverPush(pool, event, fetcher)
        await pool.query("UPDATE notification_outbox SET sent_at = now(), locked_at = NULL, last_error = NULL, payload = '{}'::jsonb WHERE id = $1", [event.id])
      }
    } catch (error) {
      const exhausted = event.attempts >= RETRY_LIMIT
      const delaySeconds = Math.min(3600, 5 * (2 ** Math.min(event.attempts, 9)))
      await pool.query(
        `UPDATE notification_outbox
          SET locked_at = NULL,
              available_at = now() + ($2 * interval '1 second'),
              last_error = $3
          WHERE id = $1 AND sent_at IS NULL AND suppressed_at IS NULL`,
        [event.id, exhausted ? 86400 * 365 : delaySeconds, String(error?.message ?? error).slice(0, 500)],
      )
      logger?.warn({ eventId: event.id, channel, attempt: event.attempts, error: error?.message }, "Notification delivery failed")
    }
    return true
  }

  async function drain() {
    if (running || stopped) return
    running = true
    try {
      const webhookConfig = getWebhookConfig ? await getWebhookConfig() : { webhookUrl, webhookSecret }
      for (let i = 0; i < 25 && !stopped; i += 1) {
        const sentN8n = webhookConfig?.webhookUrl && webhookConfig?.webhookSecret ? await deliver("n8n", webhookConfig) : false
        const sentPush = await deliver("push", webhookConfig)
        if (!sentN8n && !sentPush) break
      }
    } catch (error) {
      logger?.error({ error }, "Notification dispatcher failed")
    } finally {
      running = false
    }
  }

  const timer = setInterval(() => void drain(), intervalMs)
  timer.unref?.()
  void drain()
  return async function stopNotificationDispatcher() {
    stopped = true
    clearInterval(timer)
    while (running) await new Promise((resolve) => setTimeout(resolve, 10))
  }
}

async function deliverWebhook(pool, event, webhookConfig, webhookPoster) {
  if (!webhookConfig?.webhookUrl || !webhookConfig?.webhookSecret) throw new Error("n8n_webhook_not_configured")
  const client = await pool.connect()
  try {
    await client.query("BEGIN")
    const { rows } = await client.query(
      `SELECT id, full_name, phone
       FROM users
       WHERE id = $1 AND role = 'buyer' AND is_active AND whatsapp_opt_in AND phone IS NOT NULL
       FOR SHARE`,
      [event.user_id],
    )
    const customer = rows[0]
    if (!customer) {
      await client.query(
        `UPDATE notification_outbox
         SET suppressed_at = now(), locked_at = NULL,
             last_error = 'suppressed:whatsapp_consent', payload = '{}'::jsonb
         WHERE id = $1 AND sent_at IS NULL AND suppressed_at IS NULL`,
        [event.id],
      )
      await client.query("COMMIT")
      return
    }

    const payload = {
      ...event.payload,
      customer: { ...(event.payload.customer ?? {}), id: customer.id, name: customer.full_name, phone: customer.phone },
    }
    const response = await webhookPoster(webhookConfig.webhookUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${webhookConfig.webhookSecret}` },
      body: JSON.stringify({ id: event.id, event: event.event_type, createdAt: new Date().toISOString(), data: payload }),
    })
    if (!response.ok) throw new Error(`n8n_webhook_http_${response.status}`)
    await client.query(
      "UPDATE notification_outbox SET sent_at = now(), locked_at = NULL, last_error = NULL, payload = '{}'::jsonb WHERE id = $1 AND sent_at IS NULL AND suppressed_at IS NULL",
      [event.id],
    )
    await client.query("COMMIT")
  } catch (error) {
    await client.query("ROLLBACK")
    throw error
  } finally {
    client.release()
  }
}

async function deliverPush(pool, event, fetcher) {
  if (!event.user_id) return
  const { rows } = await pool.query(
    "SELECT id, expo_push_token FROM push_devices WHERE user_id = $1",
    [event.user_id],
  )
  for (let offset = 0; offset < rows.length; offset += 100) {
    const batch = rows.slice(offset, offset + 100)
    const response = await fetcher("https://exp.host/--/api/v2/push/send", {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify(batch.map((device) => ({
        to: device.expo_push_token,
        title: event.payload.title,
        body: event.payload.body,
        data: event.payload.data ?? {},
        sound: "default",
        priority: "high",
      }))),
      signal: AbortSignal.timeout(8000),
    })
    if (!response.ok) throw new Error(`expo_push_http_${response.status}`)
    const result = await response.json()
    for (const [index, ticket] of (result.data ?? []).entries()) {
      if (ticket.status === "error" && ticket.details?.error === "DeviceNotRegistered") {
        await pool.query("DELETE FROM push_devices WHERE id = $1", [batch[index]?.id])
      }
      if (ticket.status === "error" && ticket.details?.error !== "DeviceNotRegistered") {
        throw new Error(`expo_push_${ticket.details?.error ?? "ticket_error"}`)
      }
    }
  }
}
