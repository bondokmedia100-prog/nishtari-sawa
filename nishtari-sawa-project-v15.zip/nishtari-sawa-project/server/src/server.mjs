import Fastify from "fastify"
import pg from "pg"
import { randomBytes, timingSafeEqual } from "node:crypto"
import { hashPassword, issueToken, publicUser, requireRole, verifyPassword, verifyToken } from "./auth.mjs"
import { DealRepository } from "./deal-repository.mjs"
import { runMigrations } from "./migrate.mjs"
import { startNotificationDispatcher } from "./notification-dispatcher.mjs"
import { enqueueWhatsAppEvent } from "./notifications.mjs"
import { hashNonce, verifyProviderToken } from "./social-auth.mjs"
import { encryptWebhookSecret, isValidWebhookSecret, isValidWebhookUrl } from "./integration-secrets.mjs"
import { PRODUCT_CATEGORIES, isHttpsUrl, normalizeProductCategory, parseEgyptianLocation, parseProductImageDataUrl } from "./marketplace-validation.mjs"

const { Pool } = pg
const app = Fastify({ logger: true, bodyLimit: 16 * 1024 })
const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 10, connectionTimeoutMillis: 5000 })
const reservationTtlMinutes = Number(process.env.RESERVATION_TTL_MINUTES ?? 15)
const repository = new DealRepository(pool, { reservationTtlMinutes })
const jwtSecret = process.env.JWT_SECRET
const adminSetupToken = process.env.ADMIN_SETUP_TOKEN
const webOrigin = process.env.WEB_ORIGIN ?? "https://nishtari-sawa-preview.pages.bu.app"
const allowedOrigins = new Set([...envList(process.env.WEB_ORIGINS || webOrigin), "http://localhost:8081", "http://localhost:19006"])
const googleClientIds = envList(process.env.GOOGLE_CLIENT_IDS)
const appleClientIds = envList(process.env.APPLE_CLIENT_IDS)
const googleWebClientId = process.env.GOOGLE_WEB_CLIENT_ID ?? ""
const appleWebClientId = process.env.APPLE_WEB_CLIENT_ID ?? ""
const n8nWebhookUrl = process.env.N8N_WEBHOOK_URL ?? ""
const n8nWebhookSecret = process.env.N8N_WEBHOOK_SECRET ?? ""
const manualPaymentPhone = process.env.MANUAL_PAYMENT_PHONE ?? "01018040600"
const manualPaymentMethods = [
  { id: "vodafone_cash", name: "فودافون كاش", label: "فودافون كاش", accountNumber: manualPaymentPhone },
  { id: "instapay", name: "إنستا باي", label: "إنستا باي", accountNumber: manualPaymentPhone },
]

if (!jwtSecret || jwtSecret.length < 32) throw new Error("JWT_SECRET must contain at least 32 characters")
if (adminSetupToken && adminSetupToken.length < 32) throw new Error("ADMIN_SETUP_TOKEN must contain at least 32 characters")

await runMigrations(pool)

const authAttempts = new Map()
app.addHook("onRequest", async (request, reply) => {
  const origin = request.headers.origin
  if (origin && allowedOrigins.has(origin)) {
    reply.header("Access-Control-Allow-Origin", origin)
    reply.header("Vary", "Origin")
    reply.header("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, OPTIONS")
    reply.header("Access-Control-Allow-Headers", "Content-Type, Authorization, Idempotency-Key")
  }
  if (request.method === "OPTIONS") return reply.code(204).send()
  if (request.method !== "POST" || !request.url.startsWith("/api/v1/auth/")) return
  const now = Date.now()
  const key = request.ip
  const attempt = authAttempts.get(key)
  if (!attempt || now - attempt.startedAt > 15 * 60_000) {
    authAttempts.set(key, { startedAt: now, count: 1 })
  } else if (attempt.count >= 20) {
    reply.header("Retry-After", "900")
    return reply.code(429).send({ error: "too_many_auth_attempts" })
  } else {
    attempt.count += 1
  }
  if (authAttempts.size > 10_000) {
    for (const [ip, entry] of authAttempts) if (now - entry.startedAt > 15 * 60_000) authAttempts.delete(ip)
  }
})

app.get("/", async (_request, reply) => reply.send({
  service: "Nishtari Sawa API",
  status: "ok",
  health: "/health",
  nearbyDeals: "/api/v1/deals/nearby?lat=30.0444&lng=31.2357&radius_km=2",
}))

app.get("/health", async (_request, reply) => {
  await pool.query("SELECT 1")
  return reply.send({ status: "ok", database: "connected" })
})

app.get("/api/v1/config", async (_request, reply) => {
  return reply.send({
    settings: await repository.appSettings(),
    authProviders: publicAuthProviders(),
    programProfile: await repository.programProfile(),
    payment: { configured: true, methods: manualPaymentMethods },
  })
})

app.get("/api/v1/categories", async (_request, reply) => reply.send({ categories: PRODUCT_CATEGORIES }))

app.post("/api/v1/auth/nonce", async (request, reply) => {
  const provider = request.body?.provider
  if (!providerAudiences(provider).length) return reply.code(503).send({ error: "identity_provider_not_configured" })
  const nonce = randomBytes(32).toString("base64url")
  await pool.query("DELETE FROM auth_nonces WHERE expires_at < now() - interval '1 day'")
  await pool.query(
    "INSERT INTO auth_nonces (nonce_hash, provider, expires_at) VALUES ($1, $2, now() + interval '5 minutes')",
    [hashNonce(nonce), provider],
  )
  return reply.send({ nonce, expiresIn: 300 })
})

app.post("/api/v1/auth/social", async (request, reply) => {
  const provider = request.body?.provider
  const audiences = providerAudiences(provider)
  if (!audiences.length) return reply.code(503).send({ error: "identity_provider_not_configured" })
  const identity = await verifyProviderToken({ provider, idToken: request.body?.idToken, nonce: request.body?.nonce, audiences })
  const consumed = await pool.query(
    `UPDATE auth_nonces SET consumed_at = now()
     WHERE nonce_hash = $1 AND provider = $2 AND consumed_at IS NULL AND expires_at > now()
     RETURNING nonce_hash`,
    [hashNonce(request.body.nonce), provider],
  )
  if (!consumed.rowCount) return reply.code(401).send({ error: "invalid_or_expired_nonce" })

  let { rows } = await pool.query(
    `SELECT u.id, u.full_name, u.email, u.role, u.phone, u.whatsapp_opt_in, u.is_active
     FROM social_identities s JOIN users u ON u.id = s.user_id
     WHERE s.provider = $1 AND s.provider_subject = $2 LIMIT 1`,
    [provider, identity.subject],
  )
  let user = rows[0]
  if (user && !user.is_active) return reply.code(403).send({ error: "account_disabled" })

  if (!user) {
    if (!identity.emailVerified || !validEmail(identity.email)) return reply.code(401).send({ error: "verified_email_required" })
    const existing = await pool.query(
      "SELECT id, full_name, email, role, phone, whatsapp_opt_in, is_active FROM users WHERE lower(email) = $1 LIMIT 1",
      [identity.email],
    )
    user = existing.rows[0]
    if (user?.role === "admin") return reply.code(409).send({ error: "admin_social_login_must_be_linked" })
    if (user && !user.is_active) return reply.code(403).send({ error: "account_disabled" })
    if (!user) {
      const settings = await repository.appSettings()
      if (settings.maintenance_mode) return reply.code(503).send({ error: "maintenance_mode" })
      if (!settings.buyer_registration_enabled) return reply.code(403).send({ error: "buyer_registration_paused" })
      const locationResult = parseEgyptianLocation(request.body ?? {})
      if (locationResult.error) return reply.code(400).send({ error: locationResult.error })
      const name = socialName(request.body?.name || identity.name, identity.email)
      const client = await pool.connect()
      try {
        await client.query("BEGIN")
        const created = await client.query(
          `INSERT INTO users (full_name, email, role, governorate, city, address, latitude, longitude)
           VALUES ($1, $2, 'buyer', $3, $4, $5, $6, $7)
           RETURNING id, full_name, email, role, phone, whatsapp_opt_in, is_active`,
          [name, identity.email, locationResult.location.governorate ?? null, locationResult.location.city ?? null,
            locationResult.location.address ?? null, locationResult.location.latitude ?? null, locationResult.location.longitude ?? null],
        )
        user = created.rows[0]
        await client.query(
          "INSERT INTO social_identities (user_id, provider, provider_subject) VALUES ($1, $2, $3)",
          [user.id, provider, identity.subject],
        )
        await enqueueWhatsAppEvent(client, "customer.registered", user.id, { source: provider })
        await client.query("COMMIT")
      } catch (error) {
        await client.query("ROLLBACK")
        if (error.code === "23505") return reply.code(409).send({ error: "social_account_already_linked" })
        throw error
      } finally {
        client.release()
      }
    } else {
      try {
        await pool.query(
          "INSERT INTO social_identities (user_id, provider, provider_subject) VALUES ($1, $2, $3)",
          [user.id, provider, identity.subject],
        )
      } catch (error) {
        if (error.code === "23505") return reply.code(409).send({ error: "social_account_already_linked" })
        throw error
      }
    }
  }
  return reply.send({ user: publicUser(user), accessToken: issueToken(user, jwtSecret), provider })
})

app.post("/api/v1/auth/register", async (request, reply) => {
  const body = request.body ?? {}
  const fullName = String(body.name ?? "").trim()
  const email = normalizeEmail(body.email)
  const password = body.password
  const role = body.role
  const businessName = String(body.businessName ?? "").trim()
  const businessAddress = typeof body.businessAddress === "string" ? body.businessAddress.trim() : ""
  const businessPhone = normalizePhone(body.businessPhone)
  const phone = normalizePhone(body.phone)
  const whatsappOptIn = body.whatsappOptIn === true
  const locationResult = parseEgyptianLocation(body)
  const settings = await repository.appSettings()
  if (settings.maintenance_mode) return reply.code(503).send({ error: "maintenance_mode" })
  if (fullName.length < 2 || fullName.length > 100 || !validEmail(email)) {
    return reply.code(400).send({ error: "valid_name_and_email_required" })
  }
  if (typeof password !== "string" || password.length < 12 || password.length > 128) {
    return reply.code(400).send({ error: "password_must_be_12_to_128_characters" })
  }
  if (role !== "buyer" && role !== "supplier") return reply.code(400).send({ error: "invalid_account_role" })
  if (locationResult.error) return reply.code(400).send({ error: locationResult.error })
  if (role === "buyer" && !settings.buyer_registration_enabled) return reply.code(403).send({ error: "buyer_registration_paused" })
  if (role === "supplier" && !settings.seller_registration_enabled) return reply.code(403).send({ error: "seller_registration_paused" })
  if (role === "supplier" && (businessName.length < 2 || businessName.length > 120 ||
      businessAddress.length < 5 || businessAddress.length > 300 || !businessPhone)) {
    return reply.code(400).send({ error: "supplier_business_details_required" })
  }
  if ((body.phone && !phone) || (whatsappOptIn && !phone)) return reply.code(400).send({ error: "valid_phone_required_for_whatsapp" })

  const credentials = await hashPassword(password)
  const client = await pool.connect()
  try {
    await client.query("BEGIN")
    const { rows } = await client.query(
      `INSERT INTO users (full_name, email, password_salt, password_hash, role, phone, whatsapp_opt_in,
                          governorate, city, address, latitude, longitude)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
       RETURNING id, full_name, email, role, phone, whatsapp_opt_in`,
      [fullName, email, credentials.salt, credentials.hash, role, phone, whatsappOptIn && role === "buyer",
        locationResult.location.governorate ?? null, locationResult.location.city ?? null, locationResult.location.address ?? null,
        locationResult.location.latitude ?? null, locationResult.location.longitude ?? null],
    )
    if (role === "supplier") {
      await client.query(
        "INSERT INTO supplier_profiles (user_id, business_name, business_address, business_phone) VALUES ($1, $2, $3, $4)",
        [rows[0].id, businessName, businessAddress, businessPhone],
      )
    } else if (role === "buyer") {
      await enqueueWhatsAppEvent(client, "customer.registered", rows[0].id, { source: "email" })
    }
    await client.query("COMMIT")
    return reply.code(201).send({ user: publicUser(rows[0]), accessToken: issueToken(rows[0], jwtSecret) })
  } catch (error) {
    await client.query("ROLLBACK")
    if (error.code === "23505") return reply.code(409).send({ error: "email_already_registered" })
    throw error
  } finally {
    client.release()
  }
})

app.post("/api/v1/auth/login", async (request, reply) => {
  const email = normalizeEmail(request.body?.email)
  const password = request.body?.password
  if (!validEmail(email) || typeof password !== "string" || password.length > 128) {
    return reply.code(401).send({ error: "invalid_credentials" })
  }
  const { rows } = await pool.query(
    `SELECT id, full_name, email, role, phone, whatsapp_opt_in, password_salt, password_hash, is_active
     FROM users WHERE lower(email) = $1 LIMIT 1`,
    [email],
  )
  const user = rows[0]
  const valid = user
    ? await verifyPassword(password, user.password_salt, user.password_hash)
    : (await verifyPassword(password, "0".repeat(32), "0".repeat(128)), false)
  if (!user || !valid || !user.is_active) return reply.code(401).send({ error: "invalid_credentials" })
  return reply.send({ user: publicUser(user), accessToken: issueToken(user, jwtSecret) })
})

app.get("/api/v1/auth/me", async (request, reply) => {
  const identity = authenticated(request)
  const { rows } = await pool.query(
    "SELECT id, full_name, email, role, phone, whatsapp_opt_in, is_active FROM users WHERE id = $1",
    [identity.sub],
  )
  if (!rows[0]?.is_active) return reply.code(401).send({ error: "unauthorized" })
  return reply.send({ user: publicUser(rows[0]) })
})

app.get("/api/v1/me/profile", async (request, reply) => {
  const identity = await requireAuthenticated(request, "buyer", "supplier")
  return reply.send({ profile: await repository.myProfile(identity.sub) })
})

app.patch("/api/v1/me/profile", async (request, reply) => {
  const identity = await requireAuthenticated(request, "buyer", "supplier")
  const body = request.body ?? {}
  const profile = {}
  if (Object.hasOwn(body, "name")) {
    const name = typeof body.name === "string" ? body.name.trim() : ""
    if (name.length < 2 || name.length > 100) return reply.code(400).send({ error: "invalid_name" })
    profile.name = name
  }
  if (Object.hasOwn(body, "phone")) {
    profile.phone = body.phone === null || body.phone === "" ? null : normalizePhone(body.phone)
    if (body.phone !== null && body.phone !== "" && !profile.phone) return reply.code(400).send({ error: "invalid_phone" })
  }
  const locationResult = parseEgyptianLocation(body, { partial: true })
  if (locationResult.error) return reply.code(400).send({ error: locationResult.error })
  Object.assign(profile, locationResult.location)
  if (identity.role === "supplier") {
    if (Object.hasOwn(body, "businessName")) {
      profile.businessName = typeof body.businessName === "string" ? body.businessName.trim() : ""
      if (profile.businessName.length < 2 || profile.businessName.length > 120) return reply.code(400).send({ error: "invalid_business_name" })
    }
    if (Object.hasOwn(body, "businessAddress")) {
      profile.businessAddress = typeof body.businessAddress === "string" ? body.businessAddress.trim() : ""
      if (profile.businessAddress.length < 5 || profile.businessAddress.length > 300) return reply.code(400).send({ error: "invalid_business_address" })
    }
    if (Object.hasOwn(body, "businessPhone")) {
      profile.businessPhone = normalizePhone(body.businessPhone)
      if (!profile.businessPhone) return reply.code(400).send({ error: "invalid_business_phone" })
    }
    const current = await repository.myProfile(identity.sub)
    const businessName = profile.businessName ?? current.businessName ?? ""
    const businessAddress = profile.businessAddress ?? current.businessAddress ?? ""
    const businessPhone = profile.businessPhone ?? current.businessPhone ?? ""
    if (businessName.length < 2 || businessName.length > 120 || businessAddress.length < 5 || businessAddress.length > 300 ||
        !/^\+[1-9]\d{7,14}$/.test(businessPhone)) {
      return reply.code(400).send({ error: "supplier_business_details_required" })
    }
  } else if (["businessName", "businessAddress", "businessPhone"].some((key) => Object.hasOwn(body, key))) {
    return reply.code(403).send({ error: "supplier_profile_required" })
  }
  if (!Object.keys(profile).length) return reply.code(400).send({ error: "profile_update_required" })
  try {
    return reply.send({ profile: await repository.updateMyProfile(identity.sub, profile) })
  } catch (error) {
    if (error.code === "23505") return reply.code(409).send({ error: "phone_already_registered" })
    throw error
  }
})

app.post("/api/v1/me/reviews", async (request, reply) => {
  const identity = await requireAuthenticated(request, "buyer")
  const membershipId = request.body?.membershipId
  const rating = request.body?.rating
  const comment = typeof request.body?.comment === "string" ? request.body.comment.trim() : ""
  if (!isUuid(membershipId)) return reply.code(400).send({ error: "invalid_membership_id" })
  if (!Number.isInteger(rating) || rating < 1 || rating > 5 || comment.length < 1 || comment.length > 1000) {
    return reply.code(400).send({ error: "invalid_review" })
  }
  return reply.code(201).send({ review: await repository.createReview({ buyerId: identity.sub, membershipId, rating, comment }) })
})

app.post("/api/v1/me/memberships/:membershipId/payment-receipt", { bodyLimit: 1_500_000 }, async (request, reply) => {
  const identity = await requireAuthenticated(request, "buyer")
  if (!isUuid(request.params.membershipId)) return reply.code(400).send({ error: "invalid_order_id" })
  const receiptResult = parseProductImageDataUrl(request.body?.receiptDataUrl, { maxBytes: 1024 * 1024 })
  if (receiptResult.error) return reply.code(400).send({ error: "invalid_payment_receipt" })
  const reference = request.body?.transferReference
  if (reference !== undefined && reference !== null && (typeof reference !== "string" || reference.trim().length > 80)) {
    return reply.code(400).send({ error: "invalid_transfer_reference" })
  }
  const result = await repository.submitPaymentReceipt({
    membershipId: request.params.membershipId,
    buyerId: identity.sub,
    receipt: receiptResult.image,
    paymentReference: reference?.trim() || null,
  })
  return reply.send(result)
})

app.get("/api/v1/deals/:dealId/reviews", async (request, reply) => {
  if (!isUuid(request.params.dealId)) return reply.code(400).send({ error: "invalid_deal_id" })
  return reply.send(await repository.dealReviews(request.params.dealId))
})

app.get("/api/v1/sellers/:sellerUserId/reviews", async (request, reply) => {
  if (!isUuid(request.params.sellerUserId)) return reply.code(400).send({ error: "invalid_seller_id" })
  return reply.send(await repository.sellerReviews(request.params.sellerUserId))
})

app.post("/api/v1/me/support-tickets", async (request, reply) => {
  const identity = await requireAuthenticated(request, "buyer", "supplier")
  const subject = typeof request.body?.subject === "string" ? request.body.subject.trim() : ""
  const message = typeof request.body?.message === "string" ? request.body.message.trim() : ""
  if (subject.length < 3 || subject.length > 120 || message.length < 1 || message.length > 2000) {
    return reply.code(400).send({ error: "invalid_support_ticket" })
  }
  return reply.code(201).send({ ticket: await repository.createSupportTicket({ userId: identity.sub, subject, message }) })
})

app.get("/api/v1/me/support-tickets", async (request, reply) => {
  const identity = await requireAuthenticated(request, "buyer", "supplier")
  return reply.send({ tickets: await repository.supportTickets(identity.sub) })
})

app.post("/api/v1/auth/bootstrap-admin", async (request, reply) => {
  if (!adminSetupToken) return reply.code(404).send({ error: "admin_setup_disabled" })
  if (!safeEqual(String(request.body?.setupCode ?? ""), adminSetupToken)) {
    return reply.code(401).send({ error: "invalid_admin_setup_code" })
  }
  const fullName = String(request.body?.name ?? "").trim()
  const email = normalizeEmail(request.body?.email)
  const password = request.body?.password
  if (fullName.length < 2 || fullName.length > 100 || !validEmail(email)) {
    return reply.code(400).send({ error: "valid_name_and_email_required" })
  }
  if (typeof password !== "string" || password.length < 12 || password.length > 128) {
    return reply.code(400).send({ error: "password_must_be_12_to_128_characters" })
  }

  const credentials = await hashPassword(password)
  const client = await pool.connect()
  try {
    await client.query("BEGIN")
    await client.query("SELECT pg_advisory_xact_lock(780214, 2)")
    const existing = await client.query("SELECT 1 FROM users WHERE role = 'admin' AND password_hash IS NOT NULL LIMIT 1")
    if (existing.rowCount) {
      await client.query("ROLLBACK")
      return reply.code(409).send({ error: "admin_already_bootstrapped" })
    }
    const { rows } = await client.query(
      `INSERT INTO users (full_name, email, password_salt, password_hash, role)
       VALUES ($1, $2, $3, $4, 'admin')
       RETURNING id, full_name, email, role`,
      [fullName, email, credentials.salt, credentials.hash],
    )
    await client.query("COMMIT")
    return reply.code(201).send({ user: publicUser(rows[0]), accessToken: issueToken(rows[0], jwtSecret) })
  } catch (error) {
    await client.query("ROLLBACK")
    if (error.code === "23505") return reply.code(409).send({ error: "email_already_registered" })
    throw error
  } finally {
    client.release()
  }
})

app.get("/api/v1/deals/nearby", async (request, reply) => {
  const settings = await repository.appSettings()
  if (settings.maintenance_mode) return reply.code(503).send({ error: "maintenance_mode" })
  const latitude = Number(request.query.lat)
  const longitude = Number(request.query.lng)
  const radiusKm = Number(request.query.radius_km ?? 2)
  const coordinates = parseEgyptianLocation({ latitude, longitude })
  if (coordinates.error) return reply.code(400).send({ error: coordinates.error })
  if (!Number.isFinite(radiusKm) || radiusKm < 1 || radiusKm > 3) {
    return reply.code(400).send({ error: "radius_must_be_between_1_and_3_km" })
  }
  const deals = await repository.nearby({ latitude, longitude, radiusKm })
  return reply.send({ deals })
})

app.get("/api/v1/deals/highlights", async (request, reply) => {
  const latitude = Number(request.query.lat)
  const longitude = Number(request.query.lng)
  const radiusKm = Number(request.query.radius_km ?? 2)
  const coordinates = parseEgyptianLocation({ latitude, longitude })
  if (coordinates.error) return reply.code(400).send({ error: coordinates.error })
  if (!Number.isFinite(radiusKm) || radiusKm < 1 || radiusKm > 50) {
    return reply.code(400).send({ error: "radius_must_be_between_1_and_50_km" })
  }
  return reply.send(await repository.highlights({ latitude, longitude, radiusKm }))
})

app.get("/api/v1/deals/:dealId/image", async (request, reply) => {
  if (!isUuid(request.params.dealId)) return reply.code(400).send({ error: "invalid_deal_id" })
  const image = await repository.dealImage(request.params.dealId)
  if (!image) return reply.code(404).send({ error: "deal_image_not_found" })
  return reply
    .header("Content-Type", image.mimeType)
    .header("Content-Length", String(image.bytes.length))
    .header("X-Content-Type-Options", "nosniff")
    .header("Cache-Control", "public, max-age=300")
    .send(image.bytes)
})

app.get("/api/v1/me/memberships", async (request, reply) => {
  const identity = await requireAuthenticated(request, "buyer")
  return reply.send({ memberships: await repository.buyerMemberships(identity.sub) })
})

app.get("/api/v1/me/loyalty", async (request, reply) => {
  const identity = await requireAuthenticated(request, "buyer")
  return reply.send(await repository.buyerLoyalty(identity.sub))
})

app.delete("/api/v1/me/memberships/:membershipId", async (request, reply) => {
  const identity = await requireAuthenticated(request, "buyer")
  if (!isUuid(request.params.membershipId)) return reply.code(400).send({ error: "invalid_membership_id" })
  return reply.send(await repository.cancelBuyerMembership(identity.sub, request.params.membershipId))
})

app.get("/api/v1/me/cart", async (request, reply) => {
  const identity = await requireAuthenticated(request, "buyer")
  return reply.send({ items: await repository.buyerCart(identity.sub) })
})

app.put("/api/v1/me/cart/items/:dealId", async (request, reply) => {
  const identity = await requireAuthenticated(request, "buyer")
  if (!isUuid(request.params.dealId)) return reply.code(400).send({ error: "invalid_deal_id" })
  const quantity = Number(request.body?.quantity)
  if (!Number.isSafeInteger(quantity) || quantity < 1 || quantity > 1_000_000) {
    return reply.code(400).send({ error: "quantity_must_be_1_to_1000000" })
  }
  const settings = await repository.appSettings()
  if (settings.maintenance_mode || !settings.orders_enabled) return reply.code(403).send({ error: "orders_paused" })
  return reply.send({ item: await repository.setCartItem({ buyerId: identity.sub, dealId: request.params.dealId, quantity }) })
})

app.delete("/api/v1/me/cart/items/:dealId", async (request, reply) => {
  const identity = await requireAuthenticated(request, "buyer")
  if (!isUuid(request.params.dealId)) return reply.code(400).send({ error: "invalid_deal_id" })
  return reply.send(await repository.removeCartItem(identity.sub, request.params.dealId))
})

app.post("/api/v1/me/push-devices", async (request, reply) => {
  const identity = await requireAuthenticated(request, "buyer", "supplier")
  const token = request.body?.token
  const platform = request.body?.platform
  if (typeof token !== "string" || token.length > 200 || !/^(Expo|Exponent)PushToken\[[A-Za-z0-9_-]+\]$/.test(token) ||
      !["android", "ios"].includes(platform)) {
    return reply.code(400).send({ error: "valid_expo_push_token_required" })
  }
  await pool.query(
    `INSERT INTO push_devices (user_id, expo_push_token, platform)
     VALUES ($1, $2, $3)
     ON CONFLICT (expo_push_token) DO UPDATE
     SET user_id = EXCLUDED.user_id, platform = EXCLUDED.platform, updated_at = now()`,
    [identity.sub, token, platform],
  )
  return reply.code(204).send()
})

app.delete("/api/v1/me/push-devices/:token", async (request, reply) => {
  const identity = await requireAuthenticated(request, "buyer", "supplier")
  const token = decodeURIComponent(request.params.token)
  await pool.query("DELETE FROM push_devices WHERE user_id = $1 AND expo_push_token = $2", [identity.sub, token])
  return reply.code(204).send()
})

app.patch("/api/v1/me/notifications/whatsapp", async (request, reply) => {
  const identity = await requireAuthenticated(request, "buyer")
  const optIn = request.body?.whatsappOptIn
  const phone = normalizePhone(request.body?.phone)
  if (typeof optIn !== "boolean" || (request.body?.phone && !phone) || (optIn && !phone)) {
    return reply.code(400).send({ error: "valid_phone_required_for_whatsapp" })
  }
  const client = await pool.connect()
  try {
    await client.query("BEGIN")
    const { rows } = await client.query(
      `UPDATE users SET phone = COALESCE($2, phone), whatsapp_opt_in = $3
       WHERE id = $1 AND role = 'buyer'
       RETURNING whatsapp_opt_in`,
      [identity.sub, phone, optIn],
    )
    if (!rows.length) {
      await client.query("ROLLBACK")
      return reply.code(404).send({ error: "customer_not_found" })
    }
    if (!optIn) {
      await client.query(
        `UPDATE notification_outbox
         SET suppressed_at = now(), locked_at = NULL,
             last_error = 'suppressed:whatsapp_opt_out', payload = '{}'::jsonb
         WHERE user_id = $1 AND channel = 'n8n' AND sent_at IS NULL AND suppressed_at IS NULL`,
        [identity.sub],
      )
    }
    await client.query("COMMIT")
    return reply.send({ whatsappOptIn: rows[0].whatsapp_opt_in })
  } catch (error) {
    await client.query("ROLLBACK")
    throw error
  } finally {
    client.release()
  }
})

app.get("/api/v1/seller/deals", async (request, reply) => {
  const identity = await requireAuthenticated(request, "supplier")
  return reply.send({ deals: await repository.sellerDeals(identity.sub) })
})

app.get("/api/v1/seller/orders", async (request, reply) => {
  const identity = await requireAuthenticated(request, "supplier")
  return reply.send({ orders: await repository.sellerOrders(identity.sub) })
})

app.get("/api/v1/seller/reviews", async (request, reply) => {
  const identity = await requireAuthenticated(request, "supplier")
  return reply.send(await repository.sellerReviews(identity.sub))
})

app.get("/api/v1/seller/notifications", async (request, reply) => {
  const identity = await requireAuthenticated(request, "supplier")
  return reply.send({ notifications: await repository.sellerNotifications(identity.sub) })
})

app.patch("/api/v1/seller/orders/:membershipId/fulfillment", async (request, reply) => {
  const identity = await requireAuthenticated(request, "supplier")
  if (!isUuid(request.params.membershipId)) return reply.code(400).send({ error: "invalid_order_id" })
  return reply.send(await repository.setFulfillment({
    membershipId: request.params.membershipId,
    ownerUserId: identity.sub,
    ...fulfillmentUpdate(request.body),
  }))
})

app.patch("/api/v1/seller/deals/:dealId/inventory", async (request, reply) => {
  const identity = await requireAuthenticated(request, "supplier")
  if (!isUuid(request.params.dealId)) return reply.code(400).send({ error: "invalid_deal_id" })
  return reply.send(await repository.updateDealInventory({
    dealId: request.params.dealId,
    ownerUserId: identity.sub,
    ...inventoryUpdate(request.body),
  }))
})

app.post("/api/v1/seller/deals", { bodyLimit: 512 * 1024 }, async (request, reply) => {
  const identity = await requireAuthenticated(request, "supplier")
  const body = request.body ?? {}
  const settings = await repository.appSettings()
  if (settings.maintenance_mode) return reply.code(503).send({ error: "maintenance_mode" })
  if (!settings.deal_creation_enabled) return reply.code(403).send({ error: "deal_creation_paused" })
  const name = String(body.name ?? "").trim()
  const category = normalizeProductCategory(body.category)
  const emoji = String(body.emoji ?? "🛍️").trim()
  const unit = String(body.unit ?? "").trim()
  const pickupLabel = String(body.pickupLabel ?? "").trim()
  const price = Number(body.price)
  const retailPrice = Number(body.retailPrice)
  const moq = Number(body.moq)
  const maxQuantity = body.maxQuantity == null || body.maxQuantity === "" ? null : Number(body.maxQuantity)
  const stockQuantity = Number(body.stockQuantity)
  const acceptsShipping = body.acceptsShipping
  const acceptsPickup = body.acceptsPickup
  const suppliedCoordinates = [body.latitude, body.longitude].some((value) => value !== undefined && value !== null && value !== "")
  const coordinates = suppliedCoordinates
    ? parseEgyptianLocation({ latitude: body.latitude, longitude: body.longitude })
    : { location: { latitude: 30.0444, longitude: 31.2357 } }
  const latitude = coordinates.location?.latitude
  const longitude = coordinates.location?.longitude
  const endsAt = new Date(body.endsAt ?? Date.now() + 30 * 24 * 60 * 60 * 1000)
  if (name.length < 2 || name.length > 100 || unit.length < 1 || unit.length > 30 || emoji.length > 12) {
    return reply.code(400).send({ error: "invalid_product_details" })
  }
  if (!category) return reply.code(400).send({ error: "invalid_product_category" })
  if (coordinates.error) return reply.code(400).send({ error: coordinates.error })
  if (pickupLabel.length < 3 || pickupLabel.length > 150) return reply.code(400).send({ error: "pickup_label_required" })
  if (!Number.isFinite(price) || price <= 0 || price > 10_000_000 || !Number.isFinite(retailPrice) || retailPrice < price || retailPrice > 10_000_000) {
    return reply.code(400).send({ error: "invalid_product_price" })
  }
  if (!Number.isInteger(moq) || moq < 1 || moq > 1_000_000 ||
      (maxQuantity !== null && (!Number.isSafeInteger(maxQuantity) || maxQuantity < moq || maxQuantity > 1_000_000))) {
    return reply.code(400).send({ error: "invalid_group_quantity" })
  }
  if (!Number.isSafeInteger(stockQuantity) || stockQuantity < moq || stockQuantity > 1_000_000) {
    return reply.code(400).send({ error: "invalid_stock_quantity" })
  }
  if (typeof acceptsShipping !== "boolean" || typeof acceptsPickup !== "boolean" || (!acceptsShipping && !acceptsPickup)) {
    return reply.code(400).send({ error: "fulfillment_option_required" })
  }
  if ((acceptsShipping && !settings.merchant_shipping_enabled) || (acceptsPickup && !settings.self_pickup_enabled)) {
    return reply.code(403).send({ error: "fulfillment_option_disabled" })
  }
  let image = null
  if (body.imageDataUrl !== undefined && body.imageDataUrl !== null) {
    const imageResult = parseProductImageDataUrl(body.imageDataUrl)
    if (imageResult.error) return reply.code(400).send({ error: imageResult.error })
    image = imageResult.image
  }
  if (Number.isNaN(endsAt.getTime()) || endsAt <= new Date() || endsAt > new Date(Date.now() + 90 * 24 * 60 * 60 * 1000)) {
    return reply.code(400).send({ error: "deal_end_must_be_within_90_days" })
  }
  const deal = await repository.createOffer({
    userId: identity.sub,
    name,
    category,
    emoji,
    unit,
    price,
    retailPrice,
    moq,
    maxQuantity,
    stockQuantity,
    acceptsShipping,
    acceptsPickup,
    latitude,
    longitude,
    pickupLabel,
    endsAt,
    image,
  })
  return reply.code(201).send({ deal })
})

app.patch("/api/v1/seller/deals/:dealId", { bodyLimit: 512 * 1024 }, async (request, reply) => {
  const identity = await requireAuthenticated(request, "supplier")
  if (!isUuid(request.params.dealId)) return reply.code(400).send({ error: "invalid_deal_id" })
  if (!Object.hasOwn(request.body ?? {}, "imageDataUrl")) return reply.code(400).send({ error: "image_update_required" })
  let image = null
  if (request.body.imageDataUrl !== null) {
    const imageResult = parseProductImageDataUrl(request.body.imageDataUrl)
    if (imageResult.error) return reply.code(400).send({ error: imageResult.error })
    image = imageResult.image
  }
  return reply.send(await repository.updateDealImage({ dealId: request.params.dealId, ownerUserId: identity.sub, image }))
})

app.get("/api/v1/admin/dashboard", async (request, reply) => {
  await requireAuthenticated(request, "admin")
  return reply.send(await repository.adminDashboard())
})

app.get("/api/v1/admin/support-tickets", async (request, reply) => {
  await requireAuthenticated(request, "admin")
  const limit = Number(request.query.limit ?? 100)
  const offset = Number(request.query.offset ?? 0)
  if (!Number.isInteger(limit) || limit < 1 || limit > 200 || !Number.isInteger(offset) || offset < 0 || offset > 10_000) {
    return reply.code(400).send({ error: "invalid_pagination" })
  }
  return reply.send({ tickets: await repository.adminSupportTickets({ limit, offset }) })
})

app.patch("/api/v1/admin/support-tickets/:ticketId", async (request, reply) => {
  const identity = await requireAuthenticated(request, "admin")
  if (!isUuid(request.params.ticketId)) return reply.code(400).send({ error: "invalid_ticket_id" })
  const body = request.body ?? {}
  let status
  let response
  if (Object.hasOwn(body, "status")) {
    status = body.status
    if (!["open", "in_progress", "resolved", "closed"].includes(status)) return reply.code(400).send({ error: "invalid_support_ticket_status" })
  }
  if (Object.hasOwn(body, "reply")) {
    if (body.reply !== null && typeof body.reply !== "string") return reply.code(400).send({ error: "invalid_support_reply" })
    response = body.reply === null ? null : body.reply.trim()
    if ((response ?? "").length > 2000) return reply.code(400).send({ error: "invalid_support_reply" })
  }
  if (status === undefined && response === undefined) return reply.code(400).send({ error: "support_ticket_update_required" })
  return reply.send({ ticket: await repository.updateSupportTicket({ ticketId: request.params.ticketId, adminId: identity.sub, status, reply: response }) })
})

app.get("/api/v1/admin/orders", async (request, reply) => {
  await requireAuthenticated(request, "admin")
  const limit = Number(request.query.limit ?? 100)
  const offset = Number(request.query.offset ?? 0)
  if (!Number.isInteger(limit) || limit < 1 || limit > 200 || !Number.isInteger(offset) || offset < 0 || offset > 10_000) {
    return reply.code(400).send({ error: "invalid_pagination" })
  }
  return reply.send({ orders: await repository.adminOrders({ limit, offset }) })
})

app.get("/api/v1/admin/payments/pending", async (request, reply) => {
  await requireAuthenticated(request, "admin")
  const limit = Number(request.query.limit ?? 100)
  const offset = Number(request.query.offset ?? 0)
  if (!Number.isInteger(limit) || limit < 1 || limit > 200 || !Number.isInteger(offset) || offset < 0 || offset > 10_000) {
    return reply.code(400).send({ error: "invalid_pagination" })
  }
  return reply.send({ payments: await repository.adminPendingPayments({ limit, offset }) })
})

app.get("/api/v1/admin/payments/:membershipId/receipt", async (request, reply) => {
  await requireAuthenticated(request, "admin")
  if (!isUuid(request.params.membershipId)) return reply.code(400).send({ error: "invalid_order_id" })
  const receipt = await repository.adminPaymentReceipt(request.params.membershipId)
  if (!receipt) return reply.code(404).send({ error: "payment_receipt_not_found" })
  return reply
    .header("Content-Type", receipt.mimeType)
    .header("Content-Length", String(receipt.bytes.length))
    .header("X-Content-Type-Options", "nosniff")
    .header("Cache-Control", "private, no-store")
    .send(receipt.bytes)
})

app.patch("/api/v1/admin/payments/:membershipId", async (request, reply) => {
  const identity = await requireAuthenticated(request, "admin")
  if (!isUuid(request.params.membershipId)) return reply.code(400).send({ error: "invalid_order_id" })
  const action = request.body?.action
  if (!["approve", "reject"].includes(action)) return reply.code(400).send({ error: "invalid_payment_review_action" })
  const note = request.body?.note
  if (action === "reject" && (typeof note !== "string" || note.trim().length < 3 || note.trim().length > 300)) {
    return reply.code(400).send({ error: "payment_rejection_note_required" })
  }
  return reply.send(await repository.reviewManualPayment({
    membershipId: request.params.membershipId,
    adminId: identity.sub,
    action,
    note,
  }))
})

app.get("/api/v1/admin/customers", async (request, reply) => {
  await requireAuthenticated(request, "admin")
  const limit = Number(request.query.limit ?? 50)
  const offset = Number(request.query.offset ?? 0)
  const search = typeof request.query.search === "string" ? request.query.search.trim() : ""
  if (!Number.isInteger(limit) || limit < 1 || limit > 200 || !Number.isInteger(offset) || offset < 0 || offset > 10_000 || search.length > 100) {
    return reply.code(400).send({ error: "invalid_customer_query" })
  }
  return reply.send(await repository.adminCustomers({ search, limit, offset }))
})

app.get("/api/v1/admin/customers/export.csv", async (request, reply) => {
  const identity = await requireAuthenticated(request, "admin")
  const search = typeof request.query.search === "string" ? request.query.search.trim() : ""
  if (search.length > 100) return reply.code(400).send({ error: "invalid_customer_query" })
  const customers = await repository.adminCustomerExportRows({ search })
  if (customers.length > 50_000) return reply.code(413).send({ error: "export_too_large_use_filters" })
  await repository.recordCustomerExport(identity.sub, { search }, customers.length)
  const columns = ["معرف العميل", "الاسم", "البريد الإلكتروني", "الهاتف", "موافقة واتساب", "الحالة", "عدد الطلبات", "إجمالي الطلبات المسجلة", "تاريخ التسجيل"]
  const rows = customers.map((customer) => [
    customer.id, customer.name, customer.email, customer.phone,
    customer.whatsappOptIn ? "نعم" : "لا", customer.isActive ? "نشط" : "موقوف",
    customer.orderCount, customer.orderTotal.toFixed(2), customer.createdAt,
  ])
  const csv = `\uFEFF${[columns, ...rows].map((row) => row.map(csvCell).join(",")).join("\r\n")}`
  const stamp = new Date().toISOString().slice(0, 10)
  return reply
    .header("Content-Type", "text/csv; charset=utf-8")
    .header("Content-Disposition", `attachment; filename="customers-${stamp}.csv"`)
    .send(csv)
})

app.get("/api/v1/admin/customers/:customerId", async (request, reply) => {
  const identity = await requireAuthenticated(request, "admin")
  if (!isUuid(request.params.customerId)) return reply.code(400).send({ error: "invalid_customer_id" })
  const details = await repository.adminCustomerDetails(request.params.customerId)
  app.log.info({ adminId: identity.sub, customerId: request.params.customerId }, "Admin viewed customer profile")
  return reply.send(details)
})

app.get("/api/v1/admin/integrations/notifications", async (request, reply) => {
  await requireAuthenticated(request, "admin")
  const webhookConfig = await activeN8nWebhookConfig()
  const { rows } = await pool.query(
    `SELECT channel,
            count(*) FILTER (WHERE sent_at IS NULL AND suppressed_at IS NULL AND attempts < 8)::int AS pending,
            count(*) FILTER (WHERE sent_at IS NULL AND suppressed_at IS NULL AND attempts >= 8)::int AS failed,
            count(*) FILTER (WHERE suppressed_at IS NOT NULL)::int AS suppressed
     FROM notification_outbox GROUP BY channel`,
  )
  const totals = Object.fromEntries(rows.map((row) => [row.channel, row]))
  return reply.send({
    n8n: {
      configured: Boolean(webhookConfig.webhookUrl && webhookConfig.webhookSecret),
      webhookUrl: webhookConfig.webhookUrl,
      ...(totals.n8n ?? { pending: 0, failed: 0, suppressed: 0 }),
    },
    push: { available: true, ...(totals.push ?? { pending: 0, failed: 0, suppressed: 0 }) },
  })
})

app.patch("/api/v1/admin/integrations/notifications", async (request, reply) => {
  const identity = await requireAuthenticated(request, "admin")
  const body = request.body ?? {}
  if (body.clear === true) {
    await repository.disableN8nWebhookConfig(identity.sub)
    return reply.send({ n8n: { configured: false, webhookUrl: "" } })
  }
  const webhookUrl = typeof body.webhookUrl === "string" ? body.webhookUrl.trim() : ""
  if (!isValidWebhookUrl(webhookUrl)) return reply.code(400).send({ error: "valid_public_https_webhook_required" })
  let webhookSecret = body.webhookSecret
  if (webhookSecret === undefined || webhookSecret === "") {
    webhookSecret = (await activeN8nWebhookConfig()).webhookSecret
  }
  if (!isValidWebhookSecret(webhookSecret)) return reply.code(400).send({ error: "webhook_secret_must_be_32_to_4096_characters" })
  await repository.saveN8nWebhookConfig({
    webhookUrl,
    encryptedSecret: encryptWebhookSecret(webhookSecret, jwtSecret),
    adminId: identity.sub,
  })
  return reply.send({ n8n: { configured: true, webhookUrl } })
})

app.get("/api/v1/admin/settings", async (request, reply) => {
  await requireAuthenticated(request, "admin")
  return reply.send({ settings: await repository.appSettings() })
})

app.get("/api/v1/admin/program-profile", async (request, reply) => {
  await requireAuthenticated(request, "admin")
  return reply.send({ programProfile: await repository.programProfile() })
})

app.patch("/api/v1/admin/program-profile", async (request, reply) => {
  const identity = await requireAuthenticated(request, "admin")
  const body = request.body ?? {}
  const current = await repository.programProfile()
  const profile = {
    brandName: body.brandName === undefined ? current.brandName : typeof body.brandName === "string" ? body.brandName.trim() : "",
    brandTagline: body.brandTagline === undefined ? current.brandTagline : typeof body.brandTagline === "string" ? body.brandTagline.trim() : "",
    brandDescription: body.brandDescription === undefined ? current.brandDescription : typeof body.brandDescription === "string" ? body.brandDescription.trim() : "",
    loyaltyEarnPointsPerEgp: body.loyaltyEarnPointsPerEgp === undefined ? current.loyaltyEarnPointsPerEgp : Number(body.loyaltyEarnPointsPerEgp),
    loyaltyPointsPerEgp: body.loyaltyPointsPerEgp === undefined ? current.loyaltyPointsPerEgp : Number(body.loyaltyPointsPerEgp),
    brandLogoUrl: body.brandLogoUrl === undefined ? current.brandLogoUrl : body.brandLogoUrl === null || body.brandLogoUrl === "" ? null : String(body.brandLogoUrl).trim(),
    brandPrimaryColor: body.brandPrimaryColor === undefined ? current.brandPrimaryColor : body.brandPrimaryColor,
    brandAccentColor: body.brandAccentColor === undefined ? current.brandAccentColor : body.brandAccentColor,
  }
  if (profile.brandName.length < 2 || profile.brandName.length > 60 ||
      profile.brandTagline.length < 2 || profile.brandTagline.length > 120 ||
      profile.brandDescription.length < 2 || profile.brandDescription.length > 300 ||
      !Number.isInteger(profile.loyaltyEarnPointsPerEgp) || profile.loyaltyEarnPointsPerEgp < 0 || profile.loyaltyEarnPointsPerEgp > 100 ||
      !Number.isInteger(profile.loyaltyPointsPerEgp) || profile.loyaltyPointsPerEgp < 1 || profile.loyaltyPointsPerEgp > 100_000 ||
      (profile.brandLogoUrl !== null && !isHttpsUrl(profile.brandLogoUrl)) ||
      typeof profile.brandPrimaryColor !== "string" || !/^#[0-9a-fA-F]{6}$/.test(profile.brandPrimaryColor) ||
      typeof profile.brandAccentColor !== "string" || !/^#[0-9a-fA-F]{6}$/.test(profile.brandAccentColor)) {
    return reply.code(400).send({ error: "invalid_program_profile" })
  }
  return reply.send({ programProfile: await repository.updateProgramProfile(profile, identity.sub) })
})

app.patch("/api/v1/admin/sellers/:sellerUserId/trust", async (request, reply) => {
  await requireAuthenticated(request, "admin")
  if (!isUuid(request.params.sellerUserId) || typeof request.body?.verified !== "boolean") {
    return reply.code(400).send({ error: "valid_seller_id_and_verified_required" })
  }
  return reply.send({ seller: await repository.setSellerTrusted(request.params.sellerUserId, request.body.verified) })
})

app.get("/api/v1/admin/coupons", async (request, reply) => {
  await requireAuthenticated(request, "admin")
  return reply.send({ coupons: await repository.adminCoupons() })
})

app.post("/api/v1/admin/coupons", async (request, reply) => {
  const identity = await requireAuthenticated(request, "admin")
  const body = request.body ?? {}
  const code = typeof body.code === "string" ? body.code.trim().toUpperCase() : ""
  const discountType = body.discountType
  const value = Number(body.value)
  const minOrder = Number(body.minOrder ?? 0)
  const maxDiscount = body.maxDiscount == null || body.maxDiscount === "" ? null : Number(body.maxDiscount)
  const usageLimit = body.usageLimit == null || body.usageLimit === "" ? null : Number(body.usageLimit)
  const perUserLimit = Number(body.perUserLimit ?? 1)
  const startsAt = new Date(body.startsAt ?? Date.now())
  const endsAt = body.endsAt ? new Date(body.endsAt) : null
  if (!/^[A-Z0-9_-]{3,40}$/.test(code) || !["fixed", "percent"].includes(discountType) ||
      !Number.isFinite(value) || value <= 0 || (discountType === "percent" && value > 90) ||
      !Number.isFinite(minOrder) || minOrder < 0 || minOrder > 10_000_000 ||
      (maxDiscount !== null && (!Number.isFinite(maxDiscount) || maxDiscount <= 0 || maxDiscount > 10_000_000)) ||
      (usageLimit !== null && (!Number.isSafeInteger(usageLimit) || usageLimit < 1 || usageLimit > 1_000_000)) ||
      !Number.isInteger(perUserLimit) || perUserLimit < 1 || perUserLimit > 1000 ||
      Number.isNaN(startsAt.getTime()) || (endsAt && (Number.isNaN(endsAt.getTime()) || endsAt <= startsAt))) {
    return reply.code(400).send({ error: "invalid_coupon" })
  }
  try {
    const coupon = await repository.createCoupon({
      code,
      discountType,
      value: discountType === "percent" ? Math.round(value * 100) : Math.round(value * 100),
      minOrderMinor: Math.round(minOrder * 100),
      maxDiscountMinor: maxDiscount === null ? null : Math.round(maxDiscount * 100),
      usageLimit,
      perUserLimit,
      startsAt,
      endsAt,
    }, identity.sub)
    return reply.code(201).send({ coupon })
  } catch (error) {
    if (error.code === "23505") return reply.code(409).send({ error: "coupon_code_exists" })
    throw error
  }
})

app.patch("/api/v1/admin/coupons/:couponId", async (request, reply) => {
  await requireAuthenticated(request, "admin")
  if (!isUuid(request.params.couponId) || typeof request.body?.enabled !== "boolean") {
    return reply.code(400).send({ error: "valid_coupon_status_required" })
  }
  return reply.send({ coupon: await repository.setCouponEnabled(request.params.couponId, request.body.enabled) })
})

app.patch("/api/v1/admin/settings", async (request, reply) => {
  const identity = await requireAuthenticated(request, "admin")
  return reply.send({ settings: await repository.updateAppSettings(request.body?.settings, identity.sub) })
})

app.patch("/api/v1/admin/deals/:dealId", async (request, reply) => {
  const identity = await requireAuthenticated(request, "admin")
  if (!isUuid(request.params.dealId)) return reply.code(400).send({ error: "invalid_deal_id" })
  const action = request.body?.action
  if (!['approve', 'reject', 'pause', 'activate'].includes(action)) {
    return reply.code(400).send({ error: "invalid_admin_action" })
  }
  const result = await repository.reviewDeal(request.params.dealId, action)
  app.log.info({ adminId: identity.sub, dealId: result.id, action }, "Admin updated deal")
  return reply.send({ deal: result })
})

app.patch("/api/v1/admin/deals/:dealId/inventory", async (request, reply) => {
  await requireAuthenticated(request, "admin")
  if (!isUuid(request.params.dealId)) return reply.code(400).send({ error: "invalid_deal_id" })
  return reply.send(await repository.updateDealInventory({
    dealId: request.params.dealId,
    ...inventoryUpdate(request.body),
  }))
})

app.patch("/api/v1/admin/deals/:dealId/subsidy", async (request, reply) => {
  await requireAuthenticated(request, "admin")
  if (!isUuid(request.params.dealId)) return reply.code(400).send({ error: "invalid_deal_id" })
  const subsidy = Number(request.body?.subsidyPerUnit)
  if (!Number.isFinite(subsidy) || subsidy < 0 || subsidy > 10_000_000) return reply.code(400).send({ error: "invalid_subsidy" })
  return reply.send({ subsidy: await repository.setDealSubsidy(request.params.dealId, Math.round(subsidy * 100)) })
})

app.patch("/api/v1/admin/orders/:membershipId", async (request, reply) => {
  await requireAuthenticated(request, "admin")
  if (!isUuid(request.params.membershipId)) return reply.code(400).send({ error: "invalid_order_id" })
  if (request.body?.action === "cancel") return reply.send(await repository.cancelAdminOrder(request.params.membershipId))
  if (request.body?.action !== "fulfillment") return reply.code(400).send({ error: "invalid_admin_order_action" })
  return reply.send(await repository.setFulfillment({
    membershipId: request.params.membershipId,
    ...fulfillmentUpdate(request.body),
  }))
})

app.patch("/api/v1/admin/users/:userId", async (request, reply) => {
  const identity = await requireAuthenticated(request, "admin")
  if (!isUuid(request.params.userId) || typeof request.body?.isActive !== "boolean") {
    return reply.code(400).send({ error: "valid_user_id_and_status_required" })
  }
  const user = await repository.setUserActive(request.params.userId, request.body.isActive, identity.sub)
  app.log.info({ adminId: identity.sub, userId: user.id, isActive: user.isActive }, "Admin updated user")
  return reply.send({ user })
})

app.post("/api/v1/deals/:dealId/memberships", async (request, reply) => {
  const identity = await requireAuthenticated(request, "buyer")
  if (!isUuid(request.params.dealId)) return reply.code(400).send({ error: "invalid_deal_id" })
  const requestKey = request.headers["idempotency-key"]
  if (typeof requestKey !== "string" || !/^[A-Za-z0-9_-]{16,128}$/.test(requestKey)) {
    return reply.code(400).send({ error: "idempotency_key_required" })
  }
  const body = request.body ?? {}
  const result = await repository.join({
    dealId: request.params.dealId,
    buyerId: identity.sub,
    quantity: Number(body.quantity),
    requestKey,
    paymentMethod: body.paymentMethod,
    fulfillmentMethod: body.fulfillmentMethod ?? "self_pickup",
    shippingAddress: body.shippingAddress,
    couponCode: body.couponCode ?? null,
    loyaltyPointsToUse: Number(body.loyaltyPointsToUse ?? 0),
    appSettings: await repository.appSettings(),
  })
  return reply.code(201).send(result)
})

app.setErrorHandler((error, _request, reply) => {
  if (error.statusCode) return reply.code(error.statusCode).send({ error: error.code ?? "request_failed" })
  app.log.error(error)
  return reply.code(500).send({ error: "internal_error" })
})

function authenticated(request) {
  return verifyToken(request.headers.authorization, jwtSecret)
}

async function requireAuthenticated(request, ...roles) {
  const identity = requireRole(authenticated(request), ...roles)
  const { rows } = await pool.query("SELECT role, is_active FROM users WHERE id = $1", [identity.sub])
  if (!rows[0]?.is_active) throw Object.assign(new Error("unauthorized"), { statusCode: 401, code: "unauthorized" })
  if (rows[0].role !== identity.role) throw Object.assign(new Error("forbidden"), { statusCode: 403, code: "forbidden" })
  return identity
}

function inventoryUpdate(body = {}) {
  if (!body || typeof body !== "object" || Array.isArray(body)) {
    throw Object.assign(new Error("invalid_inventory_update"), { statusCode: 400, code: "invalid_inventory_update" })
  }
  const fields = {}
  if (body.stockQuantity !== undefined) {
    fields.stockQuantity = Number(body.stockQuantity)
    if (!Number.isSafeInteger(fields.stockQuantity) || fields.stockQuantity < 0 || fields.stockQuantity > 1_000_000) {
      throw Object.assign(new Error("invalid_stock_quantity"), { statusCode: 400, code: "invalid_stock_quantity" })
    }
  }
  if (body.maxQuantity !== undefined) {
    fields.maxQuantity = body.maxQuantity === null || body.maxQuantity === "" ? null : Number(body.maxQuantity)
    if (fields.maxQuantity !== null && (!Number.isSafeInteger(fields.maxQuantity) || fields.maxQuantity < 1 || fields.maxQuantity > 1_000_000)) {
      throw Object.assign(new Error("invalid_group_quantity"), { statusCode: 400, code: "invalid_group_quantity" })
    }
  }
  for (const [input, output] of [["acceptsShipping", "acceptsShipping"], ["acceptsPickup", "acceptsPickup"]]) {
    if (body[input] !== undefined) {
      if (typeof body[input] !== "boolean") throw Object.assign(new Error("invalid_fulfillment_option"), { statusCode: 400, code: "invalid_fulfillment_option" })
      fields[output] = body[input]
    }
  }
  if (!Object.keys(fields).length) {
    throw Object.assign(new Error("inventory_update_required"), { statusCode: 400, code: "inventory_update_required" })
  }
  return fields
}

function fulfillmentUpdate(body = {}) {
  body ??= {}
  if (typeof body !== "object" || Array.isArray(body)) {
    throw Object.assign(new Error("invalid_fulfillment_update"), { statusCode: 400, code: "invalid_fulfillment_update" })
  }
  const status = String(body.status ?? "")
  const allowed = new Set(["preparing", "shipped", "in_transit", "ready_for_pickup", "delivered", "picked_up"])
  if (!allowed.has(status)) throw Object.assign(new Error("invalid_fulfillment_status"), { statusCode: 400, code: "invalid_fulfillment_status" })
  const carrierName = optionalText(body.carrierName, 120, "invalid_carrier_name")
  const trackingNumber = optionalText(body.trackingNumber, 120, "invalid_tracking_number")
  const trackingUrl = optionalText(body.trackingUrl, 500, "invalid_tracking_url")
  const note = optionalText(body.note, 500, "invalid_fulfillment_note")
  if (trackingUrl) {
    let url
    try { url = new URL(trackingUrl) } catch { throw Object.assign(new Error("invalid_tracking_url"), { statusCode: 400, code: "invalid_tracking_url" }) }
    if (url.protocol !== "https:") throw Object.assign(new Error("invalid_tracking_url"), { statusCode: 400, code: "invalid_tracking_url" })
  }
  return { status, carrierName, trackingNumber, trackingUrl, note }
}

function optionalText(value, max, code) {
  if (value === undefined || value === null || value === "") return null
  if (typeof value !== "string" || value.trim().length > max) throw Object.assign(new Error(code), { statusCode: 400, code })
  return value.trim()
}

function normalizeEmail(value) {
  return typeof value === "string" ? value.trim().toLowerCase() : ""
}

function normalizePhone(value) {
  if (typeof value !== "string" || !value.trim()) return null
  const phone = value.trim().replace(/[\s().-]/g, "")
  if (/^01[0125]\d{8}$/.test(phone)) return `+2${phone}`
  if (/^20\d{10}$/.test(phone)) return `+${phone}`
  return /^\+[1-9]\d{7,14}$/.test(phone) ? phone : null
}

function validEmail(value) {
  return value.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)
}

function envList(value) {
  return typeof value === "string" ? value.split(",").map((item) => item.trim()).filter(Boolean) : []
}

async function activeN8nWebhookConfig() {
  const config = await repository.n8nWebhookConfig({
    fallbackUrl: n8nWebhookUrl,
    fallbackSecret: n8nWebhookSecret,
    masterSecret: jwtSecret,
  })
  if (!isValidWebhookUrl(config.webhookUrl) || !isValidWebhookSecret(config.webhookSecret)) {
    return { webhookUrl: "", webhookSecret: "" }
  }
  return config
}

function csvCell(value) {
  let text = String(value ?? "")
  if (/^[=+\-@\t\r]/.test(text)) text = `'${text}`
  return `"${text.replaceAll('"', '""')}"`
}

function providerAudiences(provider) {
  if (provider === "google") return [...new Set([...googleClientIds, googleWebClientId].filter(Boolean))]
  if (provider === "apple") return [...new Set([...appleClientIds, appleWebClientId].filter(Boolean))]
  return []
}

function publicAuthProviders() {
  return {
    google: { enabled: googleClientIds.length > 0 || Boolean(googleWebClientId), clientId: googleWebClientId || null },
    apple: { enabled: appleClientIds.length > 0 || Boolean(appleWebClientId), clientId: appleWebClientId || null },
  }
}

function socialName(value, email) {
  const name = typeof value === "string" ? value.replace(/[\u0000-\u001f\u007f]/g, "").trim() : ""
  return (name || email.split("@")[0] || "مستخدم جديد").slice(0, 100)
}

function safeEqual(left, right) {
  const a = Buffer.from(left)
  const b = Buffer.from(right)
  return a.length === b.length && timingSafeEqual(a, b)
}

function isUuid(value) {
  return typeof value === "string" && /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value)
}

const port = Number(process.env.PORT ?? 3000)
await app.listen({ host: "0.0.0.0", port })
const notificationsStop = startNotificationDispatcher(pool, app.log, { getWebhookConfig: activeN8nWebhookConfig })
const reservationTimer = setInterval(() => {
  void repository.expirePendingReservations().catch((error) => app.log.error({ error }, "Reservation expiry sweep failed"))
}, 60_000)
reservationTimer.unref?.()
void repository.expirePendingReservations().catch((error) => app.log.error({ error }, "Initial reservation expiry sweep failed"))

for (const signal of ["SIGINT", "SIGTERM"]) {
  process.on(signal, async () => {
    clearInterval(reservationTimer)
    await app.close()
    await notificationsStop()
    await pool.end()
    process.exit(0)
  })
}
