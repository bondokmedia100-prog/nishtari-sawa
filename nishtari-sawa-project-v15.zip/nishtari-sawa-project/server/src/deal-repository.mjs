import { createHash } from "node:crypto"
import { enqueuePublishedDeal, enqueuePushNotification, enqueueWhatsAppEvent } from "./notifications.mjs"
import { decryptWebhookSecret } from "./integration-secrets.mjs"

export class DealRepository {
  constructor(pool, { reservationTtlMinutes = 15 } = {}) {
    if (!Number.isInteger(reservationTtlMinutes) || reservationTtlMinutes < 5 || reservationTtlMinutes > 60) {
      throw new Error("reservation_ttl_minutes_must_be_5_to_60")
    }
    this.pool = pool
    this.reservationTtlMinutes = reservationTtlMinutes
  }

  async nearby({ latitude, longitude, radiusKm }) {
    const { rows } = await this.pool.query(
      `SELECT d.id,
               p.name,
               p.category,
               p.emoji,
               p.unit_label AS unit,
               (p.image_data IS NOT NULL) AS has_image,
               sp.business_name AS seller_name,
               d.unit_price_minor,
               d.retail_price_minor,
               d.platform_subsidy_minor,
               COALESCE((SELECT enabled FROM app_settings WHERE setting_key = 'platform_subsidies_enabled'), false) AS platform_subsidies_enabled,
               d.moq,
               d.max_quantity,
               d.stock_quantity,
                d.accepts_shipping,
                d.accepts_pickup,
                d.ends_at,
                (SELECT round(avg(r.rating)::numeric, 1)
                 FROM product_reviews r JOIN deals reviewed ON reviewed.id = r.deal_id
                 WHERE reviewed.supplier_id = d.supplier_id) AS seller_rating,
                (SELECT count(*)::int
                 FROM product_reviews r JOIN deals reviewed ON reviewed.id = r.deal_id
                 WHERE reviewed.supplier_id = d.supplier_id) AS review_count,
                round((extensions.ST_Distance(d.pickup_location, extensions.ST_SetSRID(extensions.ST_MakePoint($2, $1), 4326)::extensions.geography) / 1000.0)::numeric, 1) AS distance_km,
                COALESCE(SUM(m.quantity) FILTER (
                 WHERE m.status = 'held' OR
                   (m.status = 'pending_payment' AND
                     (m.reservation_expires_at IS NULL OR m.reservation_expires_at > now()))
                 ), 0)::bigint AS committed_quantity
       FROM deals d
        JOIN products p ON p.id = d.product_id AND p.is_active
        JOIN supplier_profiles sp ON sp.id = d.supplier_id
        LEFT JOIN deal_memberships m ON m.deal_id = d.id
        WHERE d.status = 'active'
         AND d.starts_at <= now()
         AND d.ends_at > now()
         AND extensions.ST_DWithin(d.pickup_location, extensions.ST_SetSRID(extensions.ST_MakePoint($2, $1), 4326)::extensions.geography, $3 * 1000)
          GROUP BY d.id, p.id, sp.id, d.supplier_id
        ORDER BY d.unit_price_minor ASC, d.ends_at ASC
       LIMIT 100`,
      [latitude, longitude, radiusKm],
    )
    return rows.map((row) => ({
      id: row.id,
      name: row.name,
      category: row.category,
       emoji: row.emoji,
       imageUrl: row.has_image ? `/api/v1/deals/${row.id}/image` : null,
       sellerName: row.seller_name,
       sellerRating: row.seller_rating === null ? null : Number(row.seller_rating),
       sellerReviewCount: Number(row.review_count ?? 0),
      unit: row.unit,
       price: Math.max(1, Number(row.unit_price_minor) - (row.platform_subsidies_enabled ? Number(row.platform_subsidy_minor) : 0)) / 100,
       sellerPrice: Number(row.unit_price_minor) / 100,
       platformSubsidy: row.platform_subsidies_enabled ? Number(row.platform_subsidy_minor) / 100 : 0,
      retailPrice: Number(row.retail_price_minor) / 100,
      moq: row.moq,
      maxQuantity: row.max_quantity,
      stockQuantity: row.stock_quantity,
      availableQuantity: Math.max(0, Math.min(Number(row.stock_quantity), row.max_quantity === null ? 1_000_000 : Number(row.max_quantity)) - Number(row.committed_quantity)),
      acceptsShipping: row.accepts_shipping,
      acceptsPickup: row.accepts_pickup,
      committedQuantity: row.committed_quantity,
      distanceKm: Number(row.distance_km),
      endsAt: row.ends_at,
    }))
  }

  async highlights({ latitude, longitude, radiusKm }) {
    const { rows } = await this.pool.query(
      `WITH seller_sales AS (
         SELECT d.supplier_id, COALESCE(sum(m.quantity), 0)::bigint AS completed_quantity
         FROM deal_memberships m
         JOIN deals d ON d.id = m.deal_id
         JOIN payments payment ON payment.membership_id = m.id
         WHERE m.status = 'held' AND payment.status = 'paid'
           AND m.fulfillment_status IN ('delivered', 'picked_up')
         GROUP BY d.supplier_id
       ), seller_ratings AS (
         SELECT d.supplier_id, round(avg(r.rating)::numeric, 1) AS rating, count(*)::int AS review_count
         FROM product_reviews r
         JOIN deals d ON d.id = r.deal_id
         GROUP BY d.supplier_id
       )
       SELECT d.id, p.name, p.category, p.emoji, p.unit_label AS unit,
              (p.image_data IS NOT NULL) AS has_image,
              sp.business_name AS seller_name, sp.user_id AS seller_user_id,
              sp.verified_at, d.unit_price_minor, d.retail_price_minor, d.platform_subsidy_minor,
              COALESCE((SELECT enabled FROM app_settings WHERE setting_key = 'platform_subsidies_enabled'), false) AS subsidies_enabled,
              d.moq, d.max_quantity, d.stock_quantity, d.accepts_shipping, d.accepts_pickup,
              d.ends_at,
              COALESCE(sales.completed_quantity, 0)::bigint AS seller_completed_quantity,
              ratings.rating AS seller_rating, COALESCE(ratings.review_count, 0)::int AS review_count,
              round((extensions.ST_Distance(d.pickup_location,
                extensions.ST_SetSRID(extensions.ST_MakePoint($2, $1), 4326)::extensions.geography) / 1000.0)::numeric, 1) AS distance_km,
              COALESCE(SUM(m.quantity) FILTER (
                WHERE m.status = 'held' OR
                  (m.status = 'pending_payment' AND
                    (m.reservation_expires_at IS NULL OR m.reservation_expires_at > now()))
              ), 0)::bigint AS committed_quantity
       FROM deals d
       JOIN products p ON p.id = d.product_id AND p.is_active
       JOIN supplier_profiles sp ON sp.id = d.supplier_id
       LEFT JOIN seller_sales sales ON sales.supplier_id = d.supplier_id
       LEFT JOIN seller_ratings ratings ON ratings.supplier_id = d.supplier_id
       LEFT JOIN deal_memberships m ON m.deal_id = d.id
       WHERE d.status = 'active' AND d.starts_at <= now() AND d.ends_at > now()
         AND extensions.ST_DWithin(d.pickup_location,
           extensions.ST_SetSRID(extensions.ST_MakePoint($2, $1), 4326)::extensions.geography, $3 * 1000)
       GROUP BY d.id, p.id, sp.id, sales.completed_quantity, ratings.rating, ratings.review_count
       ORDER BY d.unit_price_minor ASC, d.ends_at ASC
       LIMIT 100`,
      [latitude, longitude, radiusKm],
    )
    const deals = rows.map(mapHighlightDeal)
    const cheapest = deals.slice().sort((a, b) => a.price - b.price || a.endsAt - b.endsAt).slice(0, 20)
    const bestSellers = deals
      .filter((deal) => deal.sellerCompletedQuantity > 0)
      .sort((a, b) => b.sellerCompletedQuantity - a.sellerCompletedQuantity || a.price - b.price)
      .slice(0, 20)
    const trustedSellers = deals.filter((deal) => deal.sellerVerified).slice(0, 20)
    return { cheapest, bestSellers, trustedSellers }
  }

  async dealImage(dealId) {
    const { rows } = await this.pool.query(
      `SELECT p.image_data, p.image_mime_type
       FROM deals d JOIN products p ON p.id = d.product_id
       WHERE d.id = $1 AND p.image_data IS NOT NULL`,
      [dealId],
    )
    return rows[0] ? { bytes: rows[0].image_data, mimeType: rows[0].image_mime_type } : null
  }

  async updateDealImage({ dealId, ownerUserId, image }) {
    const { rows } = await this.pool.query(
      `UPDATE products p
       SET image_data = $3, image_mime_type = $4
       FROM deals d JOIN supplier_profiles sp ON sp.id = d.supplier_id
       WHERE d.id = $1 AND d.product_id = p.id AND sp.user_id = $2
       RETURNING p.id`,
      [dealId, ownerUserId, image?.bytes ?? null, image?.mimeType ?? null],
    )
    if (!rows.length) throw httpError(404, "deal_not_found")
    return { dealId, imageUrl: image ? `/api/v1/deals/${dealId}/image` : null }
  }

  async sellerDeals(userId) {
    const { rows } = await this.pool.query(
        `SELECT d.id, p.name, p.category, p.emoji, p.unit_label AS unit,
                (p.image_data IS NOT NULL) AS has_image,
               d.unit_price_minor, d.retail_price_minor, d.platform_subsidy_minor, d.moq, d.max_quantity,
              d.stock_quantity, d.accepts_shipping, d.accepts_pickup,
              COALESCE((SELECT SUM(m.quantity) FROM deal_memberships m
                        WHERE m.deal_id = d.id AND (m.status = 'held' OR
                          (m.status = 'pending_payment' AND
                            (m.reservation_expires_at IS NULL OR m.reservation_expires_at > now())))), 0)::bigint AS committed_quantity,
              d.ends_at, d.status, d.created_at, d.pickup_label
       FROM supplier_profiles sp
       JOIN deals d ON d.supplier_id = sp.id
       JOIN products p ON p.id = d.product_id
       WHERE sp.user_id = $1
       ORDER BY d.created_at DESC`,
      [userId],
    )
    return rows.map(row => ({
      id: row.id,
      name: row.name,
      category: row.category,
      emoji: row.emoji,
      imageUrl: row.has_image ? `/api/v1/deals/${row.id}/image` : null,
      unit: row.unit,
       price: Number(row.unit_price_minor) / 100,
       platformSubsidy: Number(row.platform_subsidy_minor ?? 0) / 100,
      retailPrice: Number(row.retail_price_minor) / 100,
      moq: row.moq,
      maxQuantity: row.max_quantity,
      stockQuantity: row.stock_quantity,
      availableQuantity: Math.max(0, Math.min(Number(row.stock_quantity), row.max_quantity === null ? 1_000_000 : Number(row.max_quantity)) - Number(row.committed_quantity)),
      committedQuantity: row.committed_quantity,
      acceptsShipping: row.accepts_shipping,
      acceptsPickup: row.accepts_pickup,
      endsAt: row.ends_at,
      status: row.status,
      reviewStatus: row.status === "draft" ? "pending" : row.status === "active" ? "approved" : "rejected",
      location: row.pickup_label,
      createdAt: row.created_at,
    }))
  }

  async createOffer({ userId, name, category, emoji, unit, price, retailPrice, moq, maxQuantity, stockQuantity, acceptsShipping, acceptsPickup, latitude, longitude, pickupLabel, endsAt, image = null }) {
    const client = await this.pool.connect()
    try {
      await client.query("BEGIN")
      const { rows: suppliers } = await client.query(
        "SELECT id, business_name FROM supplier_profiles WHERE user_id = $1 FOR UPDATE",
        [userId],
      )
      const supplier = suppliers[0]
      if (!supplier) throw httpError(403, "seller_profile_required")

      const { rows: insertedLeaders } = await client.query(
        `INSERT INTO leader_profiles (user_id, pickup_location, pickup_label)
         VALUES ($1, extensions.ST_SetSRID(extensions.ST_MakePoint($2, $3), 4326)::extensions.geography, $4)
         ON CONFLICT (user_id) DO NOTHING
         RETURNING id`,
        [userId, longitude, latitude, pickupLabel],
      )
      const leaderId = insertedLeaders[0]?.id ?? (await client.query(
        "SELECT id FROM leader_profiles WHERE user_id = $1",
        [userId],
      )).rows[0]?.id
      if (!leaderId) throw new Error("leader_profile_creation_failed")
      const { rows: products } = await client.query(
        `INSERT INTO products (supplier_id, name, category, emoji, unit_label, is_active, image_data, image_mime_type)
         VALUES ($1, $2, $3, $4, $5, false, $6, $7)
         RETURNING id`,
        [supplier.id, name, category, emoji, unit, image?.bytes ?? null, image?.mimeType ?? null],
      )
      const { rows: deals } = await client.query(
        `INSERT INTO deals (product_id, supplier_id, leader_id, pickup_location, pickup_label,
                            unit_price_minor, retail_price_minor, moq, max_quantity,
                            stock_quantity, accepts_shipping, accepts_pickup, starts_at, ends_at, status)
         VALUES ($1, $2, $3,
                  extensions.ST_SetSRID(extensions.ST_MakePoint($4, $5), 4326)::extensions.geography,
                  $6, $7, $8, $9, $10, $11, $12, $13, now(), $14, 'draft')
         RETURNING id, starts_at, ends_at, status, created_at`,
        [products[0].id, supplier.id, leaderId, longitude, latitude, pickupLabel,
          Math.round(price * 100), Math.round(retailPrice * 100), moq, maxQuantity,
          stockQuantity, acceptsShipping, acceptsPickup, endsAt],
      )
      await client.query("COMMIT")
      return {
        id: deals[0].id,
        name,
        category,
        emoji,
        imageUrl: image ? `/api/v1/deals/${deals[0].id}/image` : null,
        unit,
        price,
        retailPrice,
        moq,
        maxQuantity,
        stockQuantity,
        availableQuantity: stockQuantity,
        acceptsShipping,
        acceptsPickup,
        endsAt: deals[0].ends_at,
        status: deals[0].status,
        reviewStatus: "pending",
        sellerName: supplier.business_name,
        location: pickupLabel,
        createdAt: deals[0].created_at,
      }
    } catch (error) {
      await client.query("ROLLBACK")
      throw error
    } finally {
      client.release()
    }
  }

  async myProfile(userId) {
    const { rows } = await this.pool.query(
      `SELECT u.id, u.full_name, u.email, u.role, u.phone, u.whatsapp_opt_in, u.governorate, u.city, u.address,
              u.latitude, u.longitude, sp.business_name, sp.business_address, sp.business_phone
       FROM users u LEFT JOIN supplier_profiles sp ON sp.user_id = u.id
       WHERE u.id = $1 AND u.is_active`,
      [userId],
    )
    if (!rows.length) throw httpError(404, "profile_not_found")
    const row = rows[0]
    return {
      id: row.id,
      name: row.full_name,
      email: row.email,
      role: row.role,
      phone: row.phone,
      whatsappOptIn: row.whatsapp_opt_in,
      governorate: row.governorate,
      city: row.city,
      address: row.address,
      latitude: row.latitude,
      longitude: row.longitude,
      ...(row.role === "supplier" ? {
        businessName: row.business_name,
        businessAddress: row.business_address,
        businessPhone: row.business_phone,
      } : {}),
    }
  }

  async updateMyProfile(userId, profile) {
    const userColumns = {
      name: "full_name", phone: "phone", governorate: "governorate", city: "city",
      address: "address", latitude: "latitude", longitude: "longitude",
    }
    const supplierColumns = {
      businessName: "business_name", businessAddress: "business_address", businessPhone: "business_phone",
    }
    const client = await this.pool.connect()
    try {
      await client.query("BEGIN")
      const { rows: users } = await client.query("SELECT role, whatsapp_opt_in FROM users WHERE id = $1 AND is_active FOR UPDATE", [userId])
      if (!users.length) throw httpError(404, "profile_not_found")
      if (users[0].whatsapp_opt_in && profile.phone === null) throw httpError(400, "phone_required_for_whatsapp")
      const entries = Object.entries(userColumns).filter(([key]) => Object.hasOwn(profile, key))
      if (entries.length) {
        const assignments = entries.map(([key, column], index) => `${column} = $${index + 2}`).join(", ")
        await client.query(`UPDATE users SET ${assignments} WHERE id = $1`, [userId, ...entries.map(([key]) => profile[key])])
      }
      const supplierEntries = Object.entries(supplierColumns).filter(([key]) => Object.hasOwn(profile, key))
      if (supplierEntries.length) {
        if (users[0].role !== "supplier") throw httpError(403, "supplier_profile_required")
        const assignments = supplierEntries.map(([key, column], index) => `${column} = $${index + 2}`).join(", ")
        const updated = await client.query(
          `UPDATE supplier_profiles SET ${assignments} WHERE user_id = $1`,
          [userId, ...supplierEntries.map(([key]) => profile[key])],
        )
        if (!updated.rowCount) throw httpError(404, "supplier_profile_not_found")
      }
      await client.query("COMMIT")
      return await this.myProfile(userId)
    } catch (error) {
      await client.query("ROLLBACK")
      throw error
    } finally {
      client.release()
    }
  }

  async createReview({ buyerId, membershipId, rating, comment }) {
    const client = await this.pool.connect()
    try {
      await client.query("BEGIN")
      const { rows: memberships } = await client.query(
        `SELECT m.id FROM deal_memberships m
         JOIN payments payment ON payment.membership_id = m.id
         WHERE m.id = $1 AND m.buyer_id = $2 AND m.status = 'held'
           AND m.fulfillment_status IN ('delivered', 'picked_up') AND payment.status = 'paid'
         FOR UPDATE OF m`,
        [membershipId, buyerId],
      )
      if (!memberships.length) throw httpError(409, "order_not_reviewable")
      const { rows } = await client.query(
        `INSERT INTO product_reviews (membership_id, deal_id, buyer_id, rating, comment)
         SELECT m.id, m.deal_id, m.buyer_id, $3, $4 FROM deal_memberships m WHERE m.id = $1
         ON CONFLICT (membership_id) DO NOTHING
         RETURNING id, membership_id, deal_id, rating, comment, created_at`,
        [membershipId, buyerId, rating, comment],
      )
      if (!rows.length) throw httpError(409, "review_already_exists")
      await client.query("COMMIT")
      return mapReview({ ...rows[0], reviewer_name: null })
    } catch (error) {
      await client.query("ROLLBACK")
      throw error
    } finally {
      client.release()
    }
  }

  async dealReviews(dealId) {
    const { rows } = await this.pool.query(
      `SELECT r.id, r.membership_id, r.deal_id, r.rating, r.comment, r.created_at,
              u.full_name AS reviewer_name
       FROM product_reviews r JOIN users u ON u.id = r.buyer_id
       WHERE r.deal_id = $1 ORDER BY r.created_at DESC LIMIT 200`,
      [dealId],
    )
    return mapReviewList(rows)
  }

  async sellerReviews(sellerUserId) {
    const { rows } = await this.pool.query(
      `SELECT r.id, r.membership_id, r.deal_id, r.rating, r.comment, r.created_at,
              u.full_name AS reviewer_name, p.name AS product_name
       FROM product_reviews r
       JOIN deals d ON d.id = r.deal_id
       JOIN supplier_profiles sp ON sp.id = d.supplier_id
       JOIN products p ON p.id = d.product_id
       JOIN users u ON u.id = r.buyer_id
       WHERE sp.user_id = $1 ORDER BY r.created_at DESC LIMIT 500`,
      [sellerUserId],
    )
    return mapReviewList(rows)
  }

  async createSupportTicket({ userId, subject, message }) {
    const { rows } = await this.pool.query(
      `INSERT INTO support_tickets (user_id, subject, message)
       VALUES ($1, $2, $3)
       RETURNING id, subject, message, status, admin_reply, created_at, updated_at`,
      [userId, subject, message],
    )
    return mapSupportTicket(rows[0])
  }

  async supportTickets(userId) {
    const { rows } = await this.pool.query(
      `SELECT id, subject, message, status, admin_reply, created_at, updated_at
       FROM support_tickets WHERE user_id = $1 ORDER BY created_at DESC LIMIT 100`,
      [userId],
    )
    return rows.map(mapSupportTicket)
  }

  async adminSupportTickets({ limit = 100, offset = 0 } = {}) {
    const { rows } = await this.pool.query(
      `SELECT t.id, t.subject, t.message, t.status, t.admin_reply, t.created_at, t.updated_at,
              u.id AS user_id, u.full_name AS user_name, u.email AS user_email
       FROM support_tickets t JOIN users u ON u.id = t.user_id
       ORDER BY t.updated_at DESC LIMIT $1 OFFSET $2`,
      [limit, offset],
    )
    return rows.map((row) => ({ ...mapSupportTicket(row), userId: row.user_id, userName: row.user_name, userEmail: row.user_email }))
  }

  async updateSupportTicket({ ticketId, adminId, status, reply }) {
    const { rows } = await this.pool.query(
      `UPDATE support_tickets
       SET status = COALESCE($2, status),
           admin_reply = CASE WHEN $3::boolean THEN $4 ELSE admin_reply END,
           replied_by = CASE WHEN $3::boolean THEN $5 ELSE replied_by END,
           replied_at = CASE WHEN $3::boolean THEN now() ELSE replied_at END,
           updated_at = now()
       WHERE id = $1
       RETURNING id, subject, message, status, admin_reply, created_at, updated_at`,
      [ticketId, status ?? null, reply !== undefined, reply ?? null, adminId],
    )
    if (!rows.length) throw httpError(404, "support_ticket_not_found")
    return mapSupportTicket(rows[0])
  }

  async sellerNotifications(userId) {
    const { rows } = await this.pool.query(
      `SELECT id, event_type, payload, created_at, read_at
       FROM supplier_notifications WHERE supplier_user_id = $1
       ORDER BY created_at DESC LIMIT 100`,
      [userId],
    )
    return rows.map((row) => ({ id: row.id, event: row.event_type, data: row.payload, createdAt: row.created_at, readAt: row.read_at }))
  }

  async setSellerTrusted(sellerUserId, verified) {
    const { rows } = await this.pool.query(
      `UPDATE supplier_profiles SET verified_at = CASE WHEN $2 THEN COALESCE(verified_at, now()) ELSE NULL END
       WHERE user_id = $1 RETURNING user_id, business_name, verified_at`,
      [sellerUserId, verified],
    )
    if (!rows.length) throw httpError(404, "seller_not_found")
    return { sellerUserId: rows[0].user_id, businessName: rows[0].business_name, verified: rows[0].verified_at !== null }
  }

  async buyerMemberships(userId) {
    const { rows } = await this.pool.query(
      `SELECT m.id AS membership_id, m.deal_id, m.quantity, m.unit_price_minor,
              m.buyer_total_minor, m.platform_subsidy_minor, m.coupon_discount_minor,
              m.loyalty_points_used, m.loyalty_discount_minor,
              m.status, m.created_at, m.reservation_expires_at, m.fulfillment_method, m.shipping_address,
              m.fulfillment_status, m.carrier_name, m.tracking_number, m.tracking_url,
              payment.status AS payment_status, payment.payment_method, payment.review_note AS payment_review_note,
              m.fulfillment_note, p.name, p.category, p.emoji, p.unit_label AS unit,
              d.ends_at, d.moq, d.pickup_label, sp.business_name AS seller_name
       FROM deal_memberships m
       JOIN deals d ON d.id = m.deal_id
        JOIN products p ON p.id = d.product_id
        JOIN supplier_profiles sp ON sp.id = d.supplier_id
        LEFT JOIN payments payment ON payment.membership_id = m.id
        WHERE m.buyer_id = $1
       ORDER BY m.created_at DESC`,
      [userId],
    )
    return rows.map(row => ({
      membershipId: row.membership_id,
      dealId: row.deal_id,
      quantity: row.quantity,
      unitPrice: Number(row.buyer_total_minor ?? (Number(row.unit_price_minor) * row.quantity)) / Number(row.quantity) / 100,
      total: Number(row.buyer_total_minor ?? (Number(row.unit_price_minor) * row.quantity)) / 100,
      platformSubsidy: Number(row.platform_subsidy_minor ?? 0) / 100,
      couponDiscount: Number(row.coupon_discount_minor ?? 0) / 100,
      loyaltyPointsUsed: Number(row.loyalty_points_used ?? 0),
       loyaltyDiscount: Number(row.loyalty_discount_minor ?? 0) / 100,
       status: row.status,
       paymentStatus: row.payment_status ?? null,
       paymentMethod: row.payment_method ?? null,
       paymentReviewNote: row.payment_review_note ?? null,
       createdAt: row.created_at,
      reservationExpiresAt: row.reservation_expires_at,
      name: row.name,
      category: row.category,
      emoji: row.emoji,
      unit: row.unit,
      endsAt: row.ends_at,
      moq: row.moq,
      sellerName: row.seller_name,
      fulfillmentMethod: row.fulfillment_method,
      shippingAddress: row.shipping_address,
      fulfillmentStatus: row.fulfillment_status,
      carrierName: row.carrier_name,
      trackingNumber: row.tracking_number,
      trackingUrl: row.tracking_url,
      fulfillmentNote: row.fulfillment_note,
    }))
  }

  async buyerCart(userId) {
    const { rows } = await this.pool.query(
      `SELECT c.deal_id, c.quantity, c.updated_at, d.status, d.ends_at,
              d.unit_price_minor, d.retail_price_minor, d.platform_subsidy_minor,
              COALESCE((SELECT enabled FROM app_settings WHERE setting_key = 'platform_subsidies_enabled'), false) AS platform_subsidies_enabled,
              d.moq, d.max_quantity,
              d.stock_quantity, d.accepts_shipping, d.accepts_pickup,
              COALESCE((SELECT SUM(m.quantity) FROM deal_memberships m
                        WHERE m.deal_id = d.id AND (m.status = 'held' OR
                          (m.status = 'pending_payment' AND
                            (m.reservation_expires_at IS NULL OR m.reservation_expires_at > now())))), 0)::bigint AS committed_quantity,
              p.name, p.category, p.emoji, p.unit_label AS unit,
              sp.business_name AS seller_name, d.pickup_label
       FROM cart_items c
       JOIN deals d ON d.id = c.deal_id
       JOIN products p ON p.id = d.product_id
       JOIN supplier_profiles sp ON sp.id = d.supplier_id
       WHERE c.buyer_id = $1
       ORDER BY c.updated_at DESC`,
      [userId],
    )
    return rows.map((row) => ({
      id: row.deal_id,
      dealId: row.deal_id,
      quantity: row.quantity,
      name: row.name,
      category: row.category,
      emoji: row.emoji,
      unit: row.unit,
      sellerName: row.seller_name,
      price: Math.max(1, Number(row.unit_price_minor) - (row.platform_subsidies_enabled ? Number(row.platform_subsidy_minor) : 0)) / 100,
      sellerPrice: Number(row.unit_price_minor) / 100,
      platformSubsidy: row.platform_subsidies_enabled ? Number(row.platform_subsidy_minor) / 100 : 0,
      retailPrice: Number(row.retail_price_minor) / 100,
      moq: row.moq,
      maxQuantity: row.max_quantity,
      stockQuantity: row.stock_quantity,
      committedQuantity: Number(row.committed_quantity),
      availableQuantity: Math.max(0, Math.min(Number(row.stock_quantity), row.max_quantity === null ? 1_000_000 : Number(row.max_quantity)) - Number(row.committed_quantity)),
      acceptsShipping: row.accepts_shipping,
      acceptsPickup: row.accepts_pickup,
      endsAt: row.ends_at,
      pickupLabel: row.pickup_label,
      status: row.status,
      updatedAt: row.updated_at,
    }))
  }

  async setCartItem({ buyerId, dealId, quantity }) {
    const client = await this.pool.connect()
    try {
      await client.query("BEGIN")
      const { rows } = await client.query(
        `SELECT d.id, d.status, d.ends_at, d.unit_price_minor, d.retail_price_minor,
                d.moq, d.max_quantity, d.stock_quantity, d.accepts_shipping, d.accepts_pickup,
                d.pickup_label, p.name, p.category, p.emoji, p.unit_label AS unit,
                sp.business_name AS seller_name,
                COALESCE((SELECT SUM(m.quantity) FROM deal_memberships m
                          WHERE m.deal_id = d.id AND (m.status = 'held' OR
                            (m.status = 'pending_payment' AND
                              (m.reservation_expires_at IS NULL OR m.reservation_expires_at > now())))), 0)::bigint AS committed_quantity
         FROM deals d
         JOIN products p ON p.id = d.product_id AND p.is_active
         JOIN supplier_profiles sp ON sp.id = d.supplier_id
         WHERE d.id = $1
         FOR UPDATE OF d`,
        [dealId],
      )
      const deal = rows[0]
      if (!deal || deal.status !== "active" || new Date(deal.ends_at) <= new Date()) throw httpError(404, "deal_not_available")
      const capacity = Math.min(Number(deal.stock_quantity), deal.max_quantity === null ? 1_000_000 : Number(deal.max_quantity))
      if (quantity > capacity - Number(deal.committed_quantity)) throw httpError(409, "insufficient_stock")
      await client.query(
        `INSERT INTO cart_items (buyer_id, deal_id, quantity)
         VALUES ($1, $2, $3)
         ON CONFLICT (buyer_id, deal_id) DO UPDATE
         SET quantity = EXCLUDED.quantity, updated_at = now()`,
        [buyerId, dealId, quantity],
      )
      await enqueueWhatsAppEvent(client, "cart.item_added", buyerId, {
        item: { dealId, name: deal.name, quantity, unit: deal.unit, unitPrice: Number(deal.unit_price_minor) / 100 },
      })
      await client.query("COMMIT")
      return { dealId, quantity, name: deal.name }
    } catch (error) {
      await client.query("ROLLBACK")
      throw error
    } finally {
      client.release()
    }
  }

  async removeCartItem(buyerId, dealId) {
    await this.pool.query("DELETE FROM cart_items WHERE buyer_id = $1 AND deal_id = $2", [buyerId, dealId])
    return { dealId, removed: true }
  }

  async sellerOrders(userId) {
    const { rows } = await this.pool.query(
      `SELECT m.id AS membership_id, m.deal_id, m.quantity, m.unit_price_minor,
              m.buyer_total_minor, m.platform_subsidy_minor, m.coupon_discount_minor,
              m.loyalty_points_used, m.loyalty_discount_minor,
              m.status, m.created_at, m.fulfillment_method, m.shipping_address,
              m.fulfillment_status, m.carrier_name, m.tracking_number, m.tracking_url,
              m.fulfillment_note, p.name, p.emoji, p.unit_label AS unit,
              buyer.full_name AS buyer_name, d.pickup_label
        FROM deal_memberships m
        JOIN deals d ON d.id = m.deal_id
       JOIN products p ON p.id = d.product_id
       JOIN supplier_profiles sp ON sp.id = d.supplier_id
       JOIN users buyer ON buyer.id = m.buyer_id
        LEFT JOIN payments payment ON payment.membership_id = m.id
        WHERE sp.user_id = $1 AND m.status = 'held' AND payment.status = 'paid'
       ORDER BY m.created_at DESC
       LIMIT 300`,
      [userId],
    )
    return rows.map(mapOrder)
  }

  async cancelBuyerMembership(userId, membershipId) {
    const client = await this.pool.connect()
    try {
      await client.query("BEGIN")
      const { rows } = await client.query(
        `UPDATE deal_memberships SET status = 'cancelled'
         WHERE id = $1 AND buyer_id = $2 AND status = 'pending_payment' AND fulfillment_status = 'not_started'
         RETURNING id`,
        [membershipId, userId],
      )
      if (!rows.length) throw httpError(404, "membership_not_cancellable")
      await client.query(
        `UPDATE payments SET status = 'cancelled', receipt_data = NULL, receipt_mime_type = NULL,
           transfer_reference = NULL, updated_at = now() WHERE membership_id = $1 AND status <> 'paid'`,
        [membershipId],
      )
      await releaseMembershipBenefits(client, [membershipId])
      await client.query("COMMIT")
      return { membershipId: rows[0].id, status: "cancelled" }
    } catch (error) {
      await client.query("ROLLBACK")
      throw error
    } finally {
      client.release()
    }
  }

  async expirePendingReservations(limit = 500) {
    const client = await this.pool.connect()
    try {
      await client.query("BEGIN")
      const { rows } = await client.query(
        `WITH expired AS (
           SELECT id FROM deal_memberships
           WHERE status = 'pending_payment' AND reservation_expires_at <= now()
           ORDER BY reservation_expires_at
           LIMIT $1
           FOR UPDATE SKIP LOCKED
         )
         UPDATE deal_memberships m SET status = 'cancelled'
         FROM expired WHERE m.id = expired.id
         RETURNING m.id`,
        [limit],
      )
      const expiredIds = rows.map((row) => row.id)
      if (expiredIds.length) {
        await client.query(
          `UPDATE payments SET status = 'cancelled', receipt_data = NULL, receipt_mime_type = NULL,
             transfer_reference = NULL, updated_at = now()
           WHERE membership_id = ANY($1::uuid[]) AND status <> 'paid'`,
          [expiredIds],
        )
      }
      await releaseMembershipBenefits(client, expiredIds)
      await client.query("COMMIT")
      return { expired: expiredIds.length }
    } catch (error) {
      await client.query("ROLLBACK")
      throw error
    } finally {
      client.release()
    }
  }

  async updateDealInventory({ dealId, ownerUserId, stockQuantity, maxQuantity, acceptsShipping, acceptsPickup }) {
    const client = await this.pool.connect()
    try {
      await client.query("BEGIN")
      const { rows } = await client.query(
        `SELECT d.id, d.moq, d.stock_quantity, d.max_quantity, d.accepts_shipping,
                d.accepts_pickup,
                COALESCE((SELECT SUM(m.quantity) FROM deal_memberships m
                          WHERE m.deal_id = d.id AND (m.status = 'held' OR
                            (m.status = 'pending_payment' AND
                              (m.reservation_expires_at IS NULL OR m.reservation_expires_at > now())))), 0)::bigint AS committed_quantity
         FROM deals d
         JOIN supplier_profiles sp ON sp.id = d.supplier_id
         WHERE d.id = $1 AND ($2::uuid IS NULL OR sp.user_id = $2)
         FOR UPDATE OF d`,
        [dealId, ownerUserId ?? null],
      )
      const deal = rows[0]
      if (!deal) throw httpError(404, "deal_not_found")
      const nextStock = stockQuantity ?? deal.stock_quantity
      const nextMax = maxQuantity === undefined ? deal.max_quantity : maxQuantity
      const nextShipping = acceptsShipping ?? deal.accepts_shipping
      const nextPickup = acceptsPickup ?? deal.accepts_pickup
      const committed = Number(deal.committed_quantity)
      if (nextStock < committed || (nextMax !== null && nextMax < committed)) {
        throw httpError(409, "inventory_below_reserved")
      }
      if (nextMax !== null && (nextMax < deal.moq || nextMax > 1_000_000)) throw httpError(400, "invalid_group_quantity")
      if (!nextShipping && !nextPickup) throw httpError(400, "fulfillment_option_required")
      const updated = await client.query(
        `UPDATE deals
         SET stock_quantity = $2, max_quantity = $3, accepts_shipping = $4, accepts_pickup = $5
         WHERE id = $1
         RETURNING id, stock_quantity, max_quantity, accepts_shipping, accepts_pickup`,
        [dealId, nextStock, nextMax, nextShipping, nextPickup],
      )
      await client.query("COMMIT")
      const row = updated.rows[0]
      return {
        id: row.id,
        stockQuantity: row.stock_quantity,
        maxQuantity: row.max_quantity,
        committedQuantity: committed,
        availableQuantity: Math.max(0, Math.min(Number(row.stock_quantity), row.max_quantity === null ? 1_000_000 : Number(row.max_quantity)) - committed),
        acceptsShipping: row.accepts_shipping,
        acceptsPickup: row.accepts_pickup,
      }
    } catch (error) {
      await client.query("ROLLBACK")
      throw error
    } finally {
      client.release()
    }
  }

  async setFulfillment({ membershipId, ownerUserId, status, carrierName, trackingNumber, trackingUrl, note }) {
    const client = await this.pool.connect()
    try {
      await client.query("BEGIN")
      const { rows } = await client.query(
        `SELECT m.id, m.status AS order_status, payment.status AS payment_status,
                m.fulfillment_method, m.buyer_id,
                m.fulfillment_status, m.buyer_total_minor,
                p.name,
                m.tracking_number, m.tracking_url
         FROM deal_memberships m
         LEFT JOIN payments payment ON payment.membership_id = m.id
         JOIN deals d ON d.id = m.deal_id
         JOIN products p ON p.id = d.product_id
         JOIN supplier_profiles sp ON sp.id = d.supplier_id
         WHERE m.id = $1 AND ($2::uuid IS NULL OR sp.user_id = $2)
         FOR UPDATE OF m`,
        [membershipId, ownerUserId ?? null],
      )
       const order = rows[0]
       if (!order) throw httpError(404, "order_not_found")
       if (!order.payment_status || order.payment_status === "not_configured") {
         throw httpError(409, "payment_provider_not_connected")
       }
       if (order.order_status !== "held" || order.payment_status !== "paid") throw httpError(409, "order_not_fulfillable")
      const previousStatus = order.fulfillment_status
      const shippingStatuses = new Set(["preparing", "shipped", "in_transit", "delivered"])
      const pickupStatuses = new Set(["preparing", "ready_for_pickup", "picked_up"])
      if (!(order.fulfillment_method === "merchant_shipping" ? shippingStatuses : pickupStatuses).has(status)) {
        throw httpError(400, "invalid_fulfillment_status")
      }
      if (previousStatus !== status && !canTransitionFulfillment(order.fulfillment_method, previousStatus, status)) {
        throw httpError(409, "invalid_fulfillment_transition")
      }
      if ((status === "shipped" || status === "in_transit") && !trackingNumber && !trackingUrl && !order.tracking_number && !order.tracking_url) {
        throw httpError(400, "tracking_details_required")
      }
      const { rows: updated } = await client.query(
        `UPDATE deal_memberships
         SET fulfillment_status = $2,
             carrier_name = COALESCE($3, carrier_name),
             tracking_number = COALESCE($4, tracking_number),
             tracking_url = COALESCE($5, tracking_url),
             fulfillment_note = COALESCE($6, fulfillment_note),
             fulfillment_updated_at = now()
         WHERE id = $1
         RETURNING id, fulfillment_status, carrier_name, tracking_number, tracking_url, fulfillment_note, fulfillment_updated_at`,
        [membershipId, status, carrierName ?? null, trackingNumber ?? null, trackingUrl ?? null, note ?? null],
      )
      if (order.buyer_id && previousStatus !== status) {
        await enqueueWhatsAppEvent(client, "order.fulfillment_updated", order.buyer_id, {
          order: { id: membershipId, productName: order.name, fulfillmentStatus: status },
        })
        await enqueuePushNotification(client, order.buyer_id, "order.fulfillment_updated", {
          title: "تحديث على طلبك",
          body: `${order.name}: ${fulfillmentLabel(status)}.`,
          data: { orderId: membershipId },
        })
      }
      if (order.buyer_id && (status === "delivered" || status === "picked_up")) {
        await client.query("UPDATE coupon_redemptions SET status = 'redeemed' WHERE membership_id = $1 AND status = 'reserved'", [membershipId])
        const { rows: loyaltyFlags } = await client.query(
          "SELECT enabled FROM app_settings WHERE setting_key = 'loyalty_enabled'",
        )
        if (loyaltyFlags[0]?.enabled) {
          const { rows: profiles } = await client.query(
            "SELECT loyalty_earn_points_per_egp FROM program_profile WHERE singleton = true",
          )
          const earned = Math.floor(Number(order.buyer_total_minor ?? 0) * Number(profiles[0]?.loyalty_earn_points_per_egp ?? 0) / 100)
          if (earned > 0) {
            await client.query(
              `INSERT INTO loyalty_ledger (buyer_id, membership_id, entry_type, points, status, note)
               VALUES ($1, $2, 'earned', $3, 'confirmed', 'Points earned after fulfillment')
               ON CONFLICT (membership_id, entry_type) WHERE membership_id IS NOT NULL DO NOTHING`,
              [order.buyer_id, membershipId, earned],
            )
          }
        }
      }
      await client.query("COMMIT")
      return {
        membershipId: updated[0].id,
        fulfillmentStatus: updated[0].fulfillment_status,
        carrierName: updated[0].carrier_name,
        trackingNumber: updated[0].tracking_number,
        trackingUrl: updated[0].tracking_url,
        fulfillmentNote: updated[0].fulfillment_note,
        updatedAt: updated[0].fulfillment_updated_at,
      }
    } catch (error) {
      await client.query("ROLLBACK")
      throw error
    } finally {
      client.release()
    }
  }

  async cancelAdminOrder(membershipId) {
    const client = await this.pool.connect()
    try {
      await client.query("BEGIN")
      const { rows } = await client.query(
        `UPDATE deal_memberships
         SET status = 'cancelled'
         WHERE id = $1 AND status = 'pending_payment' AND fulfillment_status = 'not_started'
         RETURNING id, status`,
        [membershipId],
      )
      if (!rows.length) throw httpError(404, "order_not_cancellable")
      await client.query(
        `UPDATE payments SET status = 'cancelled', receipt_data = NULL, receipt_mime_type = NULL,
           transfer_reference = NULL, updated_at = now() WHERE membership_id = $1 AND status <> 'paid'`,
        [membershipId],
      )
      await releaseMembershipBenefits(client, [membershipId])
      await client.query("COMMIT")
      return { membershipId: rows[0].id, status: rows[0].status }
    } catch (error) {
      await client.query("ROLLBACK")
      throw error
    } finally {
      client.release()
    }
  }

  async adminDashboard() {
    const [counts, deals, users] = await Promise.all([
      this.pool.query(
        `SELECT
           (SELECT count(*)::int FROM deals WHERE status = 'active' AND ends_at > now()) AS active_deals,
            (SELECT count(*)::int FROM deals WHERE status = 'draft') AS pending_deals,
            (SELECT count(*)::int FROM users WHERE role IN ('buyer', 'supplier') AND is_active) AS registered_users,
            (SELECT count(*)::int FROM deal_memberships WHERE status IN ('pending_payment', 'held')) AS memberships,
            (SELECT count(*)::int FROM deal_memberships WHERE status NOT IN ('cancelled', 'refunded')) AS orders_total,
            (SELECT count(*)::int FROM deal_memberships WHERE fulfillment_status IN ('shipped', 'in_transit')) AS shipments_in_transit`,
      ),
      this.adminDeals(),
      this.adminUsers(),
    ])
    return { summary: counts.rows[0], deals, users }
  }

  async adminDeals() {
    const { rows } = await this.pool.query(
      `SELECT d.id, p.name, p.category, p.emoji, p.unit_label AS unit,
              d.unit_price_minor, d.retail_price_minor, d.platform_subsidy_minor, d.moq, d.max_quantity,
              d.stock_quantity, d.accepts_shipping, d.accepts_pickup,
              COALESCE((SELECT SUM(m.quantity) FROM deal_memberships m
                        WHERE m.deal_id = d.id AND (m.status = 'held' OR
                          (m.status = 'pending_payment' AND
                            (m.reservation_expires_at IS NULL OR m.reservation_expires_at > now())))), 0)::bigint AS committed_quantity,
              d.ends_at, d.status, d.created_at, s.business_name AS seller_name,
              u.id AS seller_user_id, u.full_name AS seller_full_name, d.pickup_label
       FROM deals d
       JOIN products p ON p.id = d.product_id
       JOIN supplier_profiles s ON s.id = d.supplier_id
       JOIN users u ON u.id = s.user_id
       ORDER BY CASE WHEN d.status = 'draft' THEN 0 ELSE 1 END, d.created_at DESC
       LIMIT 300`,
    )
    return rows.map(row => ({
      id: row.id,
      name: row.name,
      category: row.category,
      emoji: row.emoji,
      unit: row.unit,
       price: Number(row.unit_price_minor) / 100,
       retailPrice: Number(row.retail_price_minor) / 100,
       platformSubsidy: Number(row.platform_subsidy_minor ?? 0) / 100,
      moq: row.moq,
      maxQuantity: row.max_quantity,
      stockQuantity: row.stock_quantity,
      availableQuantity: Math.max(0, Math.min(Number(row.stock_quantity), row.max_quantity === null ? 1_000_000 : Number(row.max_quantity)) - Number(row.committed_quantity)),
      committedQuantity: row.committed_quantity,
      acceptsShipping: row.accepts_shipping,
      acceptsPickup: row.accepts_pickup,
      endsAt: row.ends_at,
      status: row.status,
      reviewStatus: row.status === "draft" ? "pending" : row.status === "active" ? "approved" : "rejected",
      sellerId: row.seller_user_id,
      sellerName: row.seller_name,
      sellerFullName: row.seller_full_name,
      location: row.pickup_label,
      createdAt: row.created_at,
    }))
  }

  async adminOrders({ limit = 100, offset = 0 } = {}) {
    const { rows } = await this.pool.query(
      `SELECT m.id AS membership_id, m.deal_id, m.quantity, m.unit_price_minor,
              m.buyer_total_minor, m.platform_subsidy_minor, m.coupon_discount_minor,
              m.loyalty_points_used, m.loyalty_discount_minor,
              payment.status AS payment_status, payment.payment_method, payment.review_note AS payment_review_note,
              m.status, m.created_at, m.fulfillment_method, m.shipping_address,
              m.fulfillment_status, m.carrier_name, m.tracking_number, m.tracking_url,
              m.fulfillment_note, p.name, p.emoji, p.unit_label AS unit,
              buyer.full_name AS buyer_name, buyer.email AS buyer_email,
              seller.full_name AS seller_full_name, sp.business_name AS seller_name,
              d.pickup_label
       FROM deal_memberships m
       JOIN deals d ON d.id = m.deal_id
       JOIN products p ON p.id = d.product_id
        JOIN supplier_profiles sp ON sp.id = d.supplier_id
        JOIN users seller ON seller.id = sp.user_id
        JOIN users buyer ON buyer.id = m.buyer_id
        LEFT JOIN payments payment ON payment.membership_id = m.id
       ORDER BY m.created_at DESC
       LIMIT $1 OFFSET $2`,
      [limit, offset],
    )
    return rows.map(mapOrder)
  }

  async adminCustomers({ search = "", limit = 50, offset = 0 } = {}) {
    const searchTerm = search ? `%${search}%` : null
    const [count, result] = await Promise.all([
      this.pool.query(
        `SELECT count(*)::int AS total FROM users u
         WHERE u.role = 'buyer' AND ($1::text IS NULL OR u.full_name ILIKE $1 OR
           COALESCE(u.email, '') ILIKE $1 OR COALESCE(u.phone, '') ILIKE $1)`,
        [searchTerm],
      ),
      this.pool.query(
        `SELECT u.id, u.full_name, u.email, u.phone, u.is_active, u.whatsapp_opt_in, u.created_at,
                count(m.id)::int AS order_count,
                COALESCE(sum(COALESCE(m.buyer_total_minor, m.unit_price_minor * m.quantity)) FILTER (
                  WHERE m.status NOT IN ('cancelled', 'refunded')
                ), 0)::bigint AS order_total_minor
         FROM users u
         LEFT JOIN deal_memberships m ON m.buyer_id = u.id
         WHERE u.role = 'buyer' AND ($1::text IS NULL OR u.full_name ILIKE $1 OR
           COALESCE(u.email, '') ILIKE $1 OR COALESCE(u.phone, '') ILIKE $1)
         GROUP BY u.id
         ORDER BY u.created_at DESC
         LIMIT $2 OFFSET $3`,
        [searchTerm, limit, offset],
      ),
    ])
    return { customers: result.rows.map(mapCustomer), total: count.rows[0].total }
  }

  async adminCustomerDetails(customerId) {
    const { rows: customers } = await this.pool.query(
      `SELECT u.id, u.full_name, u.email, u.phone, u.is_active, u.whatsapp_opt_in, u.created_at,
              (SELECT count(*)::int FROM deal_memberships m WHERE m.buyer_id = u.id) AS order_count
       FROM users u WHERE u.id = $1 AND u.role = 'buyer'`,
      [customerId],
    )
    if (!customers.length) throw httpError(404, "customer_not_found")
    const { rows: orders } = await this.pool.query(
      `SELECT m.id AS membership_id, m.deal_id, m.quantity, m.unit_price_minor,
              m.status, m.created_at, m.fulfillment_method, m.shipping_address,
              m.fulfillment_status, m.carrier_name, m.tracking_number, m.tracking_url,
              m.fulfillment_note, m.buyer_total_minor, m.platform_subsidy_minor,
              m.coupon_discount_minor, m.loyalty_points_used, m.loyalty_discount_minor,
              p.name, p.emoji, p.unit_label AS unit,
              sp.business_name AS seller_name, d.pickup_label
       FROM deal_memberships m
       JOIN deals d ON d.id = m.deal_id
       JOIN products p ON p.id = d.product_id
       JOIN supplier_profiles sp ON sp.id = d.supplier_id
       WHERE m.buyer_id = $1
       ORDER BY m.created_at DESC
       LIMIT 500`,
      [customerId],
    )
    return { customer: mapCustomer(customers[0]), orders: orders.map(mapOrder) }
  }

  async adminCustomerExportRows({ search = "", limit = 50_001 } = {}) {
    const searchTerm = search ? `%${search}%` : null
    const { rows } = await this.pool.query(
      `SELECT u.id, u.full_name, u.email, u.phone, u.is_active, u.whatsapp_opt_in, u.created_at,
              count(m.id)::int AS order_count,
              COALESCE(sum(COALESCE(m.buyer_total_minor, m.unit_price_minor * m.quantity)) FILTER (
                WHERE m.status NOT IN ('cancelled', 'refunded')
              ), 0)::bigint AS order_total_minor
       FROM users u
       LEFT JOIN deal_memberships m ON m.buyer_id = u.id
       WHERE u.role = 'buyer' AND ($1::text IS NULL OR u.full_name ILIKE $1 OR
         COALESCE(u.email, '') ILIKE $1 OR COALESCE(u.phone, '') ILIKE $1)
       GROUP BY u.id
       ORDER BY u.created_at DESC
       LIMIT $2`,
      [searchTerm, limit],
    )
    return rows.map(mapCustomer)
  }

  async appSettings() {
    const { rows } = await this.pool.query("SELECT setting_key, enabled FROM app_settings ORDER BY setting_key")
    return Object.fromEntries(rows.map(row => [row.setting_key, row.enabled]))
  }

  async n8nWebhookConfig({ fallbackUrl = "", fallbackSecret = "", masterSecret }) {
    const { rows } = await this.pool.query(
      "SELECT webhook_url, webhook_secret_ciphertext, enabled FROM integration_settings WHERE integration_key = 'n8n'",
    )
    const saved = rows[0]
    if (!saved) return { webhookUrl: fallbackUrl, webhookSecret: fallbackSecret }
    if (!saved.enabled) return { webhookUrl: "", webhookSecret: "" }
    return {
      webhookUrl: saved.webhook_url,
      webhookSecret: decryptWebhookSecret(saved.webhook_secret_ciphertext, masterSecret),
    }
  }

  async saveN8nWebhookConfig({ webhookUrl, encryptedSecret, adminId }) {
    await this.pool.query(
      `INSERT INTO integration_settings (integration_key, webhook_url, webhook_secret_ciphertext, enabled, updated_by, updated_at)
       VALUES ('n8n', $1, $2, true, $3, now())
       ON CONFLICT (integration_key) DO UPDATE
       SET webhook_url = EXCLUDED.webhook_url,
           webhook_secret_ciphertext = EXCLUDED.webhook_secret_ciphertext,
           enabled = true, updated_by = EXCLUDED.updated_by, updated_at = now()`,
      [webhookUrl, encryptedSecret, adminId],
    )
  }

  async disableN8nWebhookConfig(adminId) {
    await this.pool.query(
      `INSERT INTO integration_settings (integration_key, webhook_url, webhook_secret_ciphertext, enabled, updated_by, updated_at)
       VALUES ('n8n', NULL, NULL, false, $1, now())
       ON CONFLICT (integration_key) DO UPDATE
       SET webhook_url = NULL, webhook_secret_ciphertext = NULL, enabled = false,
           updated_by = EXCLUDED.updated_by, updated_at = now()`,
      [adminId],
    )
  }

  async programProfile() {
    const { rows } = await this.pool.query(
      `SELECT brand_name, brand_tagline, brand_description,
              loyalty_earn_points_per_egp, loyalty_points_per_egp,
              brand_logo_url, brand_primary_color, brand_accent_color
       FROM program_profile WHERE singleton = true`,
    )
    return mapProgramProfile(rows[0])
  }

  async updateProgramProfile(profile, adminId) {
    const { rows } = await this.pool.query(
      `UPDATE program_profile
       SET brand_name = $1, brand_tagline = $2, brand_description = $3,
           loyalty_earn_points_per_egp = $4, loyalty_points_per_egp = $5,
           brand_logo_url = $6, brand_primary_color = $7, brand_accent_color = $8,
           updated_by = $9, updated_at = now()
        WHERE singleton = true
        RETURNING brand_name, brand_tagline, brand_description,
                  loyalty_earn_points_per_egp, loyalty_points_per_egp,
                  brand_logo_url, brand_primary_color, brand_accent_color`,
      [profile.brandName, profile.brandTagline, profile.brandDescription,
        profile.loyaltyEarnPointsPerEgp, profile.loyaltyPointsPerEgp,
        profile.brandLogoUrl, profile.brandPrimaryColor, profile.brandAccentColor, adminId],
    )
    return mapProgramProfile(rows[0])
  }

  async buyerLoyalty(userId) {
    const [balance, profile] = await Promise.all([
      this.pool.query(
        `SELECT COALESCE(sum(l.points) FILTER (
                  WHERE l.status = 'confirmed' AND (l.entry_type <> 'redeemed' OR m.id IS NULL OR
                    (m.status NOT IN ('cancelled', 'refunded') AND
                      (m.reservation_expires_at IS NULL OR m.reservation_expires_at > now())))
                ), 0)::int AS balance
         FROM loyalty_ledger l
         LEFT JOIN deal_memberships m ON m.id = l.membership_id
         WHERE l.buyer_id = $1`,
        [userId],
      ),
      this.programProfile(),
    ])
    return { points: balance.rows[0].balance, profile }
  }

  async adminCoupons() {
    const { rows } = await this.pool.query(
      `SELECT c.id, c.code, c.discount_type, c.value, c.min_order_minor,
              c.max_discount_minor, c.usage_limit, c.per_user_limit,
              c.starts_at, c.ends_at, c.enabled,
              count(r.id) FILTER (WHERE r.status = 'redeemed' OR
                (r.status = 'reserved' AND m.status NOT IN ('cancelled', 'refunded') AND
                  (m.reservation_expires_at IS NULL OR m.reservation_expires_at > now())))::int AS used_count
       FROM coupons c
       LEFT JOIN coupon_redemptions r ON r.coupon_id = c.id
       LEFT JOIN deal_memberships m ON m.id = r.membership_id
       GROUP BY c.id ORDER BY c.created_at DESC`,
    )
    return rows.map((row) => ({
      id: row.id,
      code: row.code,
      discountType: row.discount_type,
      value: row.value,
      minOrder: Number(row.min_order_minor) / 100,
      maxDiscount: row.max_discount_minor === null ? null : Number(row.max_discount_minor) / 100,
      usageLimit: row.usage_limit,
      perUserLimit: row.per_user_limit,
      startsAt: row.starts_at,
      endsAt: row.ends_at,
      enabled: row.enabled,
      usedCount: Number(row.used_count),
    }))
  }

  async createCoupon(coupon, adminId) {
    const { rows } = await this.pool.query(
      `INSERT INTO coupons (code, discount_type, value, min_order_minor, max_discount_minor,
                           usage_limit, per_user_limit, starts_at, ends_at, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
       RETURNING id, code, discount_type, value, min_order_minor, max_discount_minor,
                 usage_limit, per_user_limit, starts_at, ends_at, enabled`,
      [coupon.code, coupon.discountType, coupon.value, coupon.minOrderMinor,
        coupon.maxDiscountMinor, coupon.usageLimit, coupon.perUserLimit,
        coupon.startsAt, coupon.endsAt, adminId],
    )
    return mapCoupon(rows[0])
  }

  async setCouponEnabled(couponId, enabled) {
    const { rows } = await this.pool.query(
      "UPDATE coupons SET enabled = $2 WHERE id = $1 RETURNING id, code, enabled",
      [couponId, enabled],
    )
    if (!rows.length) throw httpError(404, "coupon_not_found")
    return { id: rows[0].id, code: rows[0].code, enabled: rows[0].enabled }
  }

  async setDealSubsidy(dealId, subsidyMinor) {
    const { rows } = await this.pool.query(
      `UPDATE deals SET platform_subsidy_minor = $2
       WHERE id = $1 AND $2 < unit_price_minor
       RETURNING id, platform_subsidy_minor`,
      [dealId, subsidyMinor],
    )
    if (!rows.length) throw httpError(400, "subsidy_must_be_below_seller_price")
    return { dealId: rows[0].id, subsidyPerUnit: Number(rows[0].platform_subsidy_minor) / 100 }
  }

  async updateAppSettings(settings, adminId) {
    const allowed = new Set([
      "buyer_registration_enabled", "seller_registration_enabled", "deal_creation_enabled",
      "orders_enabled", "merchant_shipping_enabled", "self_pickup_enabled", "maintenance_mode",
      "platform_subsidies_enabled", "coupons_enabled", "loyalty_enabled",
    ])
    const entries = Object.entries(settings ?? {})
    if (!entries.length || entries.some(([key, value]) => !allowed.has(key) || typeof value !== "boolean")) {
      throw httpError(400, "invalid_app_settings")
    }
    const client = await this.pool.connect()
    try {
      await client.query("BEGIN")
      for (const [key, enabled] of entries) {
        await client.query(
          `INSERT INTO app_settings (setting_key, enabled, updated_by, updated_at)
           VALUES ($1, $2, $3, now())
           ON CONFLICT (setting_key) DO UPDATE
           SET enabled = EXCLUDED.enabled, updated_by = EXCLUDED.updated_by, updated_at = now()`,
          [key, enabled, adminId],
        )
      }
      await client.query("COMMIT")
      return await this.appSettings()
    } catch (error) {
      await client.query("ROLLBACK")
      throw error
    } finally {
      client.release()
    }
  }

  async adminUsers() {
    const { rows } = await this.pool.query(
      `SELECT id, full_name, email, role, is_active, created_at
       FROM users
       WHERE role IN ('buyer', 'supplier', 'admin')
       ORDER BY created_at DESC
       LIMIT 500`,
    )
    return rows.map(row => ({
      id: row.id,
      name: row.full_name,
      email: row.email,
      role: row.role,
      isActive: row.is_active,
      createdAt: row.created_at,
    }))
  }

  async recordCustomerExport(adminId, filters, rowCount) {
    await this.pool.query(
      "INSERT INTO admin_customer_exports (admin_id, filters, row_count) VALUES ($1, $2::jsonb, $3)",
      [adminId, JSON.stringify(filters), rowCount],
    )
  }

  async setUserActive(userId, isActive, adminId) {
    const client = await this.pool.connect()
    try {
      await client.query("BEGIN")
      const { rows } = await client.query(
        "SELECT id, role FROM users WHERE id = $1 FOR UPDATE",
        [userId],
      )
      const user = rows[0]
      if (!user) throw httpError(404, "user_not_found")
      if (!isActive && user.id === adminId) throw httpError(409, "cannot_disable_own_admin_account")
      if (!isActive && user.role === "admin") {
        await client.query("SELECT pg_advisory_xact_lock(780214, 3)")
        const admins = await client.query(
          "SELECT count(*)::int AS count FROM users WHERE role = 'admin' AND is_active",
        )
        if (admins.rows[0].count <= 1) throw httpError(409, "cannot_disable_last_admin")
      }
      const updated = await client.query(
        "UPDATE users SET is_active = $2 WHERE id = $1 RETURNING id, full_name, email, role, is_active",
        [userId, isActive],
      )
      await client.query("COMMIT")
      const row = updated.rows[0]
      return { id: row.id, name: row.full_name, email: row.email, role: row.role, isActive: row.is_active }
    } catch (error) {
      await client.query("ROLLBACK")
      throw error
    } finally {
      client.release()
    }
  }

  async reviewDeal(dealId, action) {
    const status = action === "approve" || action === "activate" ? "active" : "cancelled"
    const client = await this.pool.connect()
    try {
      await client.query("BEGIN")
      const { rows: currentRows } = await client.query(
        `SELECT d.id, d.status, d.unit_price_minor, d.ends_at,
                p.name, p.category, p.unit_label AS unit
         FROM deals d JOIN products p ON p.id = d.product_id
         WHERE d.id = $1 FOR UPDATE OF d`,
        [dealId],
      )
      const current = currentRows[0]
      if (!current) throw httpError(404, "deal_not_found")
      const { rows } = await client.query(
        `UPDATE deals SET status = $2
         WHERE id = $1
         RETURNING id, product_id, status`,
        [dealId, status],
      )
      if (!rows.length) throw httpError(404, "deal_not_found")
      await client.query(
        "UPDATE products SET is_active = $2 WHERE id = $1",
        [rows[0].product_id, status === "active"],
      )
      if (status === "active" && current.status !== "active") {
        await enqueuePublishedDeal(client, { ...current, id: rows[0].id })
      }
      await client.query("COMMIT")
      return { id: rows[0].id, status: rows[0].status }
    } catch (error) {
      await client.query("ROLLBACK")
      throw error
    } finally {
      client.release()
    }
  }

  async join({ dealId, buyerId, quantity, requestKey, paymentMethod, fulfillmentMethod, shippingAddress, couponCode = null, loyaltyPointsToUse = 0, appSettings = {} }) {
    if (!Number.isSafeInteger(quantity) || quantity < 1 || quantity > 1_000_000) throw httpError(400, "invalid_quantity")
    if (!/^[A-Za-z0-9_-]{16,128}$/.test(requestKey ?? "")) throw httpError(400, "invalid_idempotency_key")
    if (!['vodafone_cash', 'instapay'].includes(paymentMethod)) throw httpError(400, "invalid_payment_method")
    if (!['merchant_shipping', 'self_pickup'].includes(fulfillmentMethod)) throw httpError(400, "invalid_fulfillment_method")
    if (fulfillmentMethod === "merchant_shipping" && (typeof shippingAddress !== "string" || shippingAddress.trim().length < 8 || shippingAddress.trim().length > 500)) {
      throw httpError(400, "invalid_shipping_address")
    }
    if (couponCode !== null && (typeof couponCode !== "string" || !/^[A-Za-z0-9_-]{3,40}$/.test(couponCode))) {
      throw httpError(400, "invalid_coupon_code")
    }
    if (!Number.isSafeInteger(loyaltyPointsToUse) || loyaltyPointsToUse < 0 || loyaltyPointsToUse > 1_000_000) {
      throw httpError(400, "invalid_loyalty_points")
    }
    const fingerprint = createHash("sha256").update(JSON.stringify({
      dealId, quantity, paymentMethod, fulfillmentMethod, shippingAddress: shippingAddress?.trim() ?? null,
      couponCode: couponCode?.trim().toUpperCase() ?? null, loyaltyPointsToUse,
    })).digest("hex")
    const client = await this.pool.connect()
    try {
      await client.query("BEGIN")
      const replay = await client.query(
        `SELECT m.id, m.status, m.buyer_total_minor, m.request_fingerprint, payment.status AS payment_status
         FROM deal_memberships m JOIN payments payment ON payment.membership_id = m.id
         WHERE m.buyer_id = $1 AND m.request_key = $2 FOR UPDATE OF m, payment`,
        [buyerId, requestKey],
      )
      if (replay.rows[0]) {
        const row = replay.rows[0]
        if (row.request_fingerprint !== fingerprint) throw httpError(409, "idempotency_key_reused")
        await client.query("COMMIT")
        return { membershipId: row.id, status: row.status, paymentStatus: row.payment_status, amountMinor: Number(row.buyer_total_minor), message: row.payment_status }
      }
      if (appSettings.maintenance_mode || appSettings.orders_enabled === false) throw httpError(403, "orders_paused")
      const { rows: dealRows } = await client.query(
        `SELECT d.id, d.status, d.ends_at, d.unit_price_minor, d.platform_subsidy_minor,
                d.moq, d.max_quantity, d.stock_quantity, d.accepts_shipping, d.accepts_pickup,
                p.name,
                COALESCE((SELECT enabled FROM app_settings WHERE setting_key = 'platform_subsidies_enabled'), false) AS subsidies_enabled,
                COALESCE((SELECT sum(m.quantity) FROM deal_memberships m
                  WHERE m.deal_id = d.id AND (m.status = 'held' OR
                    (m.status = 'pending_payment' AND m.reservation_expires_at > now()))), 0)::bigint AS committed_quantity
         FROM deals d JOIN products p ON p.id = d.product_id AND p.is_active
         WHERE d.id = $1 FOR UPDATE OF d`,
        [dealId],
      )
      const deal = dealRows[0]
      if (!deal || deal.status !== "active" || new Date(deal.ends_at) <= new Date()) throw httpError(404, "deal_not_available")
      if ((fulfillmentMethod === "merchant_shipping" && (!deal.accepts_shipping || appSettings.merchant_shipping_enabled === false)) ||
          (fulfillmentMethod === "self_pickup" && (!deal.accepts_pickup || appSettings.self_pickup_enabled === false))) {
        throw httpError(400, "fulfillment_option_unavailable")
      }
      const capacity = Math.min(Number(deal.stock_quantity), deal.max_quantity === null ? 1_000_000 : Number(deal.max_quantity))
      if (quantity > capacity - Number(deal.committed_quantity)) throw httpError(409, "insufficient_stock")
      const { rows: priorRows } = await client.query(
        `UPDATE deal_memberships SET status = 'cancelled'
         WHERE deal_id = $1 AND buyer_id = $2 AND status = 'pending_payment' AND reservation_expires_at <= now()
         RETURNING id`, [dealId, buyerId],
      )
      await releaseMembershipBenefits(client, priorRows.map((row) => row.id))
      const { rows: existingRows } = await client.query(
        "SELECT id FROM deal_memberships WHERE deal_id = $1 AND buyer_id = $2 AND status NOT IN ('cancelled', 'refunded') LIMIT 1",
        [dealId, buyerId],
      )
      if (existingRows.length) throw httpError(409, "already_joined")

      const sellerPriceMinor = Number(deal.unit_price_minor)
      const subsidyPerUnit = deal.subsidies_enabled ? Number(deal.platform_subsidy_minor) : 0
      const subtotalMinor = Math.max(1, sellerPriceMinor - subsidyPerUnit) * quantity
      let couponDiscountMinor = 0
      let coupon = null
      if (couponCode) {
        if (appSettings.coupons_enabled !== true) throw httpError(403, "coupons_disabled")
        const { rows } = await client.query(
          `SELECT id, discount_type, value, min_order_minor, max_discount_minor, usage_limit, per_user_limit
           FROM coupons WHERE code = $1 AND enabled AND starts_at <= now() AND (ends_at IS NULL OR ends_at > now()) FOR UPDATE`,
          [couponCode.trim().toUpperCase()],
        )
        coupon = rows[0]
        if (!coupon) throw httpError(400, "coupon_invalid_or_expired")
        if (subtotalMinor < Number(coupon.min_order_minor)) throw httpError(400, "coupon_minimum_not_met")
        const { rows: usageRows } = await client.query(
          `SELECT count(*)::int AS all_uses,
                  count(*) FILTER (WHERE r.buyer_id = $2)::int AS buyer_uses
           FROM coupon_redemptions r JOIN deal_memberships m ON m.id = r.membership_id
           WHERE r.coupon_id = $1 AND (r.status = 'redeemed' OR
             (r.status = 'reserved' AND m.status NOT IN ('cancelled', 'refunded') AND
              (m.reservation_expires_at IS NULL OR m.reservation_expires_at > now())))`,
          [coupon.id, buyerId],
        )
        const usage = usageRows[0]
        if (coupon.usage_limit !== null && Number(usage.all_uses) >= Number(coupon.usage_limit)) throw httpError(409, "coupon_usage_limit_reached")
        if (Number(usage.buyer_uses) >= Number(coupon.per_user_limit)) throw httpError(409, "coupon_user_limit_reached")
        couponDiscountMinor = coupon.discount_type === "percent"
          ? Math.round(subtotalMinor * Number(coupon.value) / 10_000)
          : Number(coupon.value)
        if (coupon.max_discount_minor !== null) couponDiscountMinor = Math.min(couponDiscountMinor, Number(coupon.max_discount_minor))
        couponDiscountMinor = Math.min(couponDiscountMinor, subtotalMinor - 1)
      }
      let loyaltyDiscountMinor = 0
      if (loyaltyPointsToUse > 0) {
        if (appSettings.loyalty_enabled !== true) throw httpError(403, "loyalty_disabled")
        const { rows: balanceRows } = await client.query(
          `SELECT COALESCE(sum(l.points) FILTER (WHERE l.status = 'confirmed' AND
            (l.entry_type <> 'redeemed' OR m.id IS NULL OR (m.status NOT IN ('cancelled', 'refunded') AND
              (m.reservation_expires_at IS NULL OR m.reservation_expires_at > now())))), 0)::int AS balance
           FROM loyalty_ledger l LEFT JOIN deal_memberships m ON m.id = l.membership_id WHERE l.buyer_id = $1`,
          [buyerId],
        )
        if (loyaltyPointsToUse > Number(balanceRows[0].balance)) throw httpError(409, "insufficient_loyalty_points")
        const { rows: profileRows } = await client.query("SELECT loyalty_points_per_egp FROM program_profile WHERE singleton = true")
        const pointsPerEgp = Number(profileRows[0]?.loyalty_points_per_egp ?? 100)
        loyaltyDiscountMinor = Math.floor(loyaltyPointsToUse * 100 / pointsPerEgp)
      }
      if (couponDiscountMinor + loyaltyDiscountMinor >= subtotalMinor) throw httpError(400, "discount_exceeds_order_total")
      const buyerTotalMinor = subtotalMinor - couponDiscountMinor - loyaltyDiscountMinor
      const { rows: membershipRows } = await client.query(
        `INSERT INTO deal_memberships (
           deal_id, buyer_id, quantity, unit_price_minor, buyer_total_minor, platform_subsidy_minor,
           coupon_discount_minor, loyalty_points_used, loyalty_discount_minor, status, request_key,
           request_fingerprint, reservation_expires_at, fulfillment_method, shipping_address
         ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, 'pending_payment', $10, $11,
                   now() + make_interval(mins => $12), $13, $14)
         RETURNING id, status, reservation_expires_at`,
        [dealId, buyerId, quantity, sellerPriceMinor, buyerTotalMinor, subsidyPerUnit * quantity,
          couponDiscountMinor, loyaltyPointsToUse, loyaltyDiscountMinor, requestKey, fingerprint,
          this.reservationTtlMinutes, fulfillmentMethod, fulfillmentMethod === "merchant_shipping" ? shippingAddress.trim() : null],
      )
      const membership = membershipRows[0]
      if (coupon && couponDiscountMinor > 0) {
        await client.query(
          "INSERT INTO coupon_redemptions (coupon_id, buyer_id, membership_id, discount_minor) VALUES ($1, $2, $3, $4)",
          [coupon.id, buyerId, membership.id, couponDiscountMinor],
        )
      }
      if (loyaltyPointsToUse > 0) {
        await client.query(
          `INSERT INTO loyalty_ledger (buyer_id, membership_id, entry_type, points, status, note)
           VALUES ($1, $2, 'redeemed', $3, 'confirmed', 'Used for manual-transfer order')`,
          [buyerId, membership.id, -loyaltyPointsToUse],
        )
      }
      await client.query(
        `INSERT INTO payments (membership_id, amount_minor, currency, status, payment_method)
         VALUES ($1, $2, 'EGP', 'awaiting_transfer', $3)`,
        [membership.id, buyerTotalMinor, paymentMethod],
      )
      await client.query("COMMIT")
      return { membershipId: membership.id, status: membership.status, paymentStatus: "awaiting_transfer", amountMinor: buyerTotalMinor, reservationExpiresAt: membership.reservation_expires_at, message: "awaiting_transfer" }
    } catch (error) {
      await client.query("ROLLBACK")
      if (error.code === "23505") throw httpError(409, "already_joined")
      throw error
    } finally {
      client.release()
    }
  }

  async submitPaymentReceipt({ membershipId, buyerId, receipt, paymentReference = null }) {
    const client = await this.pool.connect()
    try {
      await client.query("BEGIN")
      const { rows } = await client.query(
        `SELECT m.id, m.status, m.reservation_expires_at, payment.status AS payment_status
         FROM deal_memberships m JOIN payments payment ON payment.membership_id = m.id
         WHERE m.id = $1 AND m.buyer_id = $2 FOR UPDATE OF m, payment`,
        [membershipId, buyerId],
      )
      const order = rows[0]
      if (!order) throw httpError(404, "order_not_found")
      if (order.status !== "pending_payment" || new Date(order.reservation_expires_at) <= new Date()) throw httpError(409, "order_reservation_expired")
      if (!['awaiting_transfer', 'rejected'].includes(order.payment_status)) throw httpError(409, "receipt_already_submitted")
      const { rows: updated } = await client.query(
        `UPDATE payments SET status = 'submitted', transfer_reference = $2,
             receipt_data = $3, receipt_mime_type = $4, submitted_at = now(),
             reviewed_by = NULL, reviewed_at = NULL, review_note = NULL, updated_at = now()
         WHERE membership_id = $1 RETURNING membership_id, status, payment_method, submitted_at`,
        [membershipId, paymentReference, receipt.bytes, receipt.mimeType],
      )
      await client.query("UPDATE deal_memberships SET reservation_expires_at = now() + interval '24 hours' WHERE id = $1", [membershipId])
      await client.query("COMMIT")
      return { membershipId, paymentStatus: updated[0].status, paymentMethod: updated[0].payment_method, submittedAt: updated[0].submitted_at }
    } catch (error) {
      await client.query("ROLLBACK")
      throw error
    } finally {
      client.release()
    }
  }

  async adminPendingPayments({ limit = 100, offset = 0 } = {}) {
    const { rows } = await this.pool.query(
      `SELECT m.id AS membership_id, m.quantity, m.buyer_total_minor, m.created_at,
              p.name, p.emoji, p.unit_label AS unit, buyer.full_name AS buyer_name,
              buyer.email AS buyer_email, buyer.phone AS buyer_phone,
              payment.payment_method, payment.transfer_reference, payment.submitted_at,
              payment.review_note, payment.receipt_mime_type
       FROM payments payment JOIN deal_memberships m ON m.id = payment.membership_id
       JOIN deals d ON d.id = m.deal_id JOIN products p ON p.id = d.product_id
       JOIN users buyer ON buyer.id = m.buyer_id
       WHERE payment.status = 'submitted' AND m.status = 'pending_payment'
       ORDER BY payment.submitted_at ASC LIMIT $1 OFFSET $2`,
      [limit, offset],
    )
    return rows.map((row) => ({
      membershipId: row.membership_id, quantity: row.quantity, total: Number(row.buyer_total_minor) / 100,
      createdAt: row.created_at, name: row.name, emoji: row.emoji, unit: row.unit,
      buyerName: row.buyer_name, buyerEmail: row.buyer_email, buyerPhone: row.buyer_phone,
      paymentMethod: row.payment_method, transferReference: row.transfer_reference,
      submittedAt: row.submitted_at, reviewNote: row.review_note, receiptMimeType: row.receipt_mime_type,
      receiptUrl: `/api/v1/admin/payments/${row.membership_id}/receipt`,
    }))
  }

  async adminPaymentReceipt(membershipId) {
    const { rows } = await this.pool.query(
      `SELECT payment.receipt_data, payment.receipt_mime_type
       FROM payments payment JOIN deal_memberships m ON m.id = payment.membership_id
       WHERE payment.membership_id = $1 AND payment.receipt_data IS NOT NULL AND payment.status IN ('submitted', 'rejected')`,
      [membershipId],
    )
    return rows[0] ? { bytes: rows[0].receipt_data, mimeType: rows[0].receipt_mime_type } : null
  }

  async reviewManualPayment({ membershipId, adminId, action, note = null }) {
    const client = await this.pool.connect()
    try {
      await client.query("BEGIN")
      const { rows } = await client.query(
        `SELECT m.id, m.status AS membership_status, m.buyer_id, m.reservation_expires_at,
                payment.status AS payment_status, payment.receipt_data, p.name
         FROM deal_memberships m JOIN payments payment ON payment.membership_id = m.id
         JOIN deals d ON d.id = m.deal_id JOIN products p ON p.id = d.product_id
         WHERE m.id = $1 FOR UPDATE OF m, payment`,
        [membershipId],
      )
      const order = rows[0]
      if (!order) throw httpError(404, "payment_not_found")
      if (order.payment_status !== "submitted" || order.membership_status !== "pending_payment" || !order.receipt_data) {
        throw httpError(409, "payment_not_pending_review")
      }
      if (new Date(order.reservation_expires_at) <= new Date()) throw httpError(409, "payment_review_window_expired")
      if (action === "approve") {
        await client.query(
          `UPDATE payments SET status = 'paid', reviewed_by = $2, reviewed_at = now(), review_note = NULL, updated_at = now()
           WHERE membership_id = $1`, [membershipId, adminId],
        )
        await client.query(
          "UPDATE deal_memberships SET status = 'held', reservation_expires_at = NULL WHERE id = $1", [membershipId],
        )
        await enqueueWhatsAppEvent(client, "order.payment_approved", order.buyer_id, {
          order: { id: membershipId, productName: order.name, paymentStatus: "paid" },
        })
        await enqueuePushNotification(client, order.buyer_id, "order.payment_approved", {
          title: "تم تأكيد التحويل", body: `${order.name}: تم اعتماد إيصال التحويل.`, data: { orderId: membershipId },
        })
      } else if (action === "reject") {
        if (typeof note !== "string" || note.trim().length < 3 || note.trim().length > 300) throw httpError(400, "payment_rejection_note_required")
        await client.query(
          `UPDATE payments SET status = 'rejected', reviewed_by = $2, reviewed_at = now(), review_note = $3, updated_at = now()
           WHERE membership_id = $1`, [membershipId, adminId, note.trim()],
        )
        await client.query("UPDATE deal_memberships SET reservation_expires_at = now() + interval '24 hours' WHERE id = $1", [membershipId])
        await enqueueWhatsAppEvent(client, "order.payment_rejected", order.buyer_id, {
          order: { id: membershipId, productName: order.name, paymentStatus: "rejected", reason: note.trim() },
        })
        await enqueuePushNotification(client, order.buyer_id, "order.payment_rejected", {
          title: "مطلوب مراجعة إيصال التحويل", body: `${order.name}: ${note.trim()}`, data: { orderId: membershipId },
        })
      } else {
        throw httpError(400, "invalid_payment_review_action")
      }
      await client.query("COMMIT")
      return { membershipId, paymentStatus: action === "approve" ? "paid" : "rejected", orderStatus: action === "approve" ? "held" : "pending_payment" }
    } catch (error) {
      await client.query("ROLLBACK")
      throw error
    } finally {
      client.release()
    }
  }
}

function mapOrder(row) {
  return {
    membershipId: row.membership_id,
    dealId: row.deal_id,
    quantity: row.quantity,
    unitPrice: Number(row.unit_price_minor) / 100,
      total: Number(row.buyer_total_minor ?? (Number(row.unit_price_minor) * Number(row.quantity))) / 100,
    buyerTotal: Number(row.buyer_total_minor ?? (Number(row.unit_price_minor) * Number(row.quantity))) / 100,
    platformSubsidy: Number(row.platform_subsidy_minor ?? 0) / 100,
    couponDiscount: Number(row.coupon_discount_minor ?? 0) / 100,
    loyaltyPointsUsed: Number(row.loyalty_points_used ?? 0),
    loyaltyDiscount: Number(row.loyalty_discount_minor ?? 0) / 100,
    paymentStatus: row.payment_status ?? null,
    paymentMethod: row.payment_method ?? null,
    paymentReviewNote: row.payment_review_note ?? null,
    status: row.status,
    createdAt: row.created_at,
    fulfillmentMethod: row.fulfillment_method,
    shippingAddress: row.shipping_address,
    fulfillmentStatus: row.fulfillment_status,
    carrierName: row.carrier_name,
    trackingNumber: row.tracking_number,
    trackingUrl: row.tracking_url,
    fulfillmentNote: row.fulfillment_note,
    name: row.name,
    emoji: row.emoji,
    unit: row.unit,
    buyerName: row.buyer_name ?? null,
    buyerEmail: row.buyer_email ?? null,
    sellerFullName: row.seller_full_name ?? null,
    sellerName: row.seller_name ?? null,
    pickupLabel: row.pickup_label ?? null,
  }
}

function mapCustomer(row) {
  return {
    id: row.id,
    name: row.full_name,
    email: row.email,
    phone: row.phone,
    role: "buyer",
    isActive: row.is_active,
    whatsappOptIn: row.whatsapp_opt_in,
    createdAt: row.created_at,
    orderCount: Number(row.order_count ?? 0),
    orderTotal: Number(row.order_total_minor ?? 0) / 100,
  }
}

function mapProgramProfile(row = {}) {
  return {
    brandName: row.brand_name ?? "نشتري سوا",
    brandTagline: row.brand_tagline ?? "سوق جماعي من قلب الحي",
    brandDescription: row.brand_description ?? "كوّن مجموعة مع جيرانك ووصلوا لسعر أفضل.",
    loyaltyEarnPointsPerEgp: Number(row.loyalty_earn_points_per_egp ?? 1),
    loyaltyPointsPerEgp: Number(row.loyalty_points_per_egp ?? 100),
    brandLogoUrl: row.brand_logo_url ?? null,
    brandPrimaryColor: row.brand_primary_color ?? "#0B7A75",
    brandAccentColor: row.brand_accent_color ?? "#E97845",
  }
}

function mapHighlightDeal(row) {
  const sellerPriceMinor = Number(row.unit_price_minor)
  const subsidyMinor = row.subsidies_enabled ? Number(row.platform_subsidy_minor) : 0
  const availableQuantity = Math.max(0, Math.min(Number(row.stock_quantity), row.max_quantity === null ? 1_000_000 : Number(row.max_quantity)) - Number(row.committed_quantity))
  return {
    id: row.id,
    name: row.name,
    category: row.category,
    emoji: row.emoji,
    imageUrl: row.has_image ? `/api/v1/deals/${row.id}/image` : null,
    sellerName: row.seller_name,
    sellerId: row.seller_user_id,
    sellerVerified: row.verified_at !== null,
    sellerRating: row.seller_rating === null ? null : Number(row.seller_rating),
    sellerReviewCount: Number(row.review_count),
    sellerCompletedQuantity: Number(row.seller_completed_quantity),
    unit: row.unit,
    price: Math.max(1, sellerPriceMinor - subsidyMinor) / 100,
    sellerPrice: sellerPriceMinor / 100,
    retailPrice: Number(row.retail_price_minor) / 100,
    moq: row.moq,
    maxQuantity: row.max_quantity,
    stockQuantity: row.stock_quantity,
    availableQuantity,
    acceptsShipping: row.accepts_shipping,
    acceptsPickup: row.accepts_pickup,
    distanceKm: Number(row.distance_km),
    endsAt: row.ends_at,
  }
}

function mapReview(row) {
  return {
    id: row.id,
    membershipId: row.membership_id,
    dealId: row.deal_id,
    rating: Number(row.rating),
    comment: row.comment,
    reviewerName: row.reviewer_name,
    ...(row.product_name ? { productName: row.product_name } : {}),
    createdAt: row.created_at,
  }
}

function mapReviewList(rows) {
  const reviews = rows.map(mapReview)
  return {
    reviews,
    total: reviews.length,
    averageRating: reviews.length ? Math.round(reviews.reduce((total, review) => total + review.rating, 0) / reviews.length * 10) / 10 : null,
  }
}

function mapSupportTicket(row) {
  return {
    id: row.id,
    subject: row.subject,
    message: row.message,
    status: row.status,
    reply: row.admin_reply,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  }
}

function mapCoupon(row) {
  return {
    id: row.id,
    code: row.code,
    discountType: row.discount_type,
    value: Number(row.value),
    minOrder: Number(row.min_order_minor) / 100,
    maxDiscount: row.max_discount_minor === null ? null : Number(row.max_discount_minor) / 100,
    usageLimit: row.usage_limit,
    perUserLimit: row.per_user_limit,
    startsAt: row.starts_at,
    endsAt: row.ends_at,
    enabled: row.enabled,
  }
}

function fulfillmentLabel(status) {
  return ({
    preparing: "قيد التجهيز",
    shipped: "تم الشحن",
    in_transit: "في الطريق",
    ready_for_pickup: "جاهز للاستلام",
    delivered: "تم التوصيل",
    picked_up: "تم الاستلام",
  })[status] ?? status
}

function canTransitionFulfillment(method, from, to) {
  const transitions = method === "merchant_shipping"
    ? {
        not_started: ["preparing"],
        preparing: ["shipped"],
        shipped: ["in_transit", "delivered"],
        in_transit: ["delivered"],
      }
    : {
        not_started: ["preparing"],
        preparing: ["ready_for_pickup"],
        ready_for_pickup: ["picked_up"],
      }
  return transitions[from]?.includes(to) ?? false
}

async function releaseMembershipBenefits(client, membershipIds) {
  if (!membershipIds.length) return
  await client.query(
    "UPDATE coupon_redemptions SET status = 'released' WHERE membership_id = ANY($1::uuid[]) AND status IN ('reserved', 'redeemed')",
    [membershipIds],
  )
  await client.query(
    "UPDATE loyalty_ledger SET status = 'reversed' WHERE membership_id = ANY($1::uuid[]) AND entry_type IN ('redeemed', 'earned') AND status = 'confirmed'",
    [membershipIds],
  )
}

function httpError(statusCode, code) {
  return Object.assign(new Error(code), { statusCode, code })
}
