export const EGYPTIAN_GOVERNORATES = [
  "القاهرة", "الجيزة", "الإسكندرية", "الدقهلية", "البحر الأحمر", "البحيرة", "الفيوم",
  "الغربية", "الإسماعيلية", "المنوفية", "المنيا", "القليوبية", "الوادي الجديد", "السويس",
  "أسوان", "أسيوط", "بني سويف", "بورسعيد", "دمياط", "الشرقية", "جنوب سيناء", "كفر الشيخ",
  "مطروح", "الأقصر", "قنا", "شمال سيناء", "سوهاج",
]

export const PRODUCT_CATEGORIES = [
  { id: "grocery", name: "سوبرماركت وبقالة" },
  { id: "sweets", name: "حلويات" },
  { id: "electronics", name: "إلكترونيات" },
  { id: "produce", name: "خضروات وفاكهة" },
  { id: "bakery", name: "مخبوزات" },
  { id: "dairy", name: "ألبان" },
  { id: "home", name: "المنزل" },
  { id: "personal_care", name: "العناية الشخصية" },
  { id: "cleaning", name: "منظفات" },
  { id: "other", name: "أخرى" },
]

const categoryAliases = new Map([
  ["supermarket", "grocery"], ["supermarket/grocery", "grocery"], ["groceries", "grocery"],
  ["grocery", "grocery"], ["سوبرماركت", "grocery"], ["بقالة", "grocery"],
  ["sweets", "sweets"], ["candy", "sweets"], ["حلويات", "sweets"],
  ["electronics", "electronics"], ["إلكترونيات", "electronics"],
  ["produce", "produce"], ["fruit", "produce"], ["fruits", "produce"], ["vegetables", "produce"],
  ["produce & fruit", "produce"], ["خضروات وفاكهة", "produce"], ["فاكهة", "produce"],
  ["bakery", "bakery"], ["مخبوزات", "bakery"],
  ["dairy", "dairy"], ["ألبان", "dairy"],
  ["home", "home"], ["household", "home"], ["المنزل", "home"],
  ["personal care", "personal_care"], ["personal_care", "personal_care"], ["العناية الشخصية", "personal_care"],
  ["cleaning", "cleaning"], ["cleaning products", "cleaning"], ["منظفات", "cleaning"],
  ["other", "other"], ["أخرى", "other"],
])

const categoryNames = new Map(PRODUCT_CATEGORIES.map(({ id, name }) => [name, id]))

export function normalizeProductCategory(value) {
  if (typeof value !== "string") return null
  const normalized = value.trim().toLocaleLowerCase("en-US")
  return categoryNames.get(value.trim()) ?? categoryAliases.get(normalized) ?? null
}

export function parseEgyptianLocation(input, { partial = false } = {}) {
  const result = {}
  const fields = ["governorate", "city", "address", "latitude", "longitude"]
  for (const field of fields) {
    if (partial && !Object.hasOwn(input ?? {}, field)) continue
    result[field] = input?.[field]
  }

  if (result.governorate !== undefined && result.governorate !== null && result.governorate !== "") {
    if (typeof result.governorate !== "string" || !EGYPTIAN_GOVERNORATES.includes(result.governorate.trim())) {
      return { error: "invalid_egyptian_governorate" }
    }
    result.governorate = result.governorate.trim()
  } else if (result.governorate !== undefined) {
    result.governorate = null
  }

  for (const field of ["city", "address"]) {
    const max = field === "city" ? 100 : 300
    const value = result[field]
    if (value === undefined) continue
    if (value === null || value === "") {
      result[field] = null
    } else if (typeof value !== "string" || !value.trim() || value.trim().length > max) {
      return { error: `invalid_${field}` }
    } else {
      result[field] = value.trim()
    }
  }

  if (result.latitude === undefined && result.longitude === undefined) return { location: result }
  const latitudeMissing = result.latitude === undefined || result.latitude === null || result.latitude === ""
  const longitudeMissing = result.longitude === undefined || result.longitude === null || result.longitude === ""
  if (latitudeMissing !== longitudeMissing) return { error: "coordinate_pair_required" }
  if (latitudeMissing) {
    result.latitude = null
    result.longitude = null
    return { location: result }
  }
  const latitude = finiteCoordinate(result.latitude)
  const longitude = finiteCoordinate(result.longitude)
  if (latitude === null || longitude === null || latitude < -90 || latitude > 90 || longitude < -180 || longitude > 180) {
    return { error: "invalid_coordinates" }
  }
  if (latitude < 21.7 || latitude > 31.8 || longitude < 24.5 || longitude > 37.0) {
    return { error: "coordinates_outside_egypt" }
  }
  result.latitude = latitude
  result.longitude = longitude
  return { location: result }
}

export function parseProductImageDataUrl(value, { maxBytes = 350 * 1024 } = {}) {
  if (typeof value !== "string" || value.length > Math.ceil(maxBytes * 4 / 3) + 100) return { error: "invalid_product_image" }
  const match = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/]+={0,2})$/.exec(value)
  if (!match) return { error: "invalid_product_image" }
  const [, mimeType, encoded] = match
  const bytes = Buffer.from(encoded, "base64")
  if (!bytes.length || bytes.length > maxBytes || bytes.toString("base64") !== encoded) {
    return { error: "invalid_product_image" }
  }
  const validSignature = mimeType === "image/jpeg"
    ? bytes.length >= 12 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff && bytes.at(-2) === 0xff && bytes.at(-1) === 0xd9
    : mimeType === "image/png"
      ? bytes.length >= 33 && bytes.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])) &&
        bytes.readUInt32BE(8) === 13 && bytes.toString("ascii", 12, 16) === "IHDR" &&
        bytes.readUInt32BE(16) > 0 && bytes.readUInt32BE(20) > 0
      : bytes.length >= 12 && bytes.toString("ascii", 0, 4) === "RIFF" &&
        bytes.readUInt32LE(4) === bytes.length - 8 && bytes.toString("ascii", 8, 12) === "WEBP"
  if (!validSignature) return { error: "invalid_product_image" }
  return { image: { mimeType, bytes } }
}

export function isHttpsUrl(value, maxLength = 2048) {
  if (typeof value !== "string" || value.length > maxLength) return false
  try {
    const url = new URL(value)
    return url.protocol === "https:" && Boolean(url.hostname) && !url.username && !url.password
  } catch {
    return false
  }
}

function finiteCoordinate(value) {
  if (typeof value === "number") return Number.isFinite(value) ? value : null
  if (typeof value !== "string" || !value.trim()) return null
  const number = Number(value)
  return Number.isFinite(number) ? number : null
}
