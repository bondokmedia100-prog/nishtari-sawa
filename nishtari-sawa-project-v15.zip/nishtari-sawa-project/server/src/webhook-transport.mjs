import { resolve4 } from "node:dns/promises"
import { request as httpsRequest } from "node:https"
import { isIP } from "node:net"
import { isPublicIPv4, isValidWebhookUrl } from "./integration-secrets.mjs"

export async function postPublicWebhook(urlValue, options, { resolver = resolve4, request = httpsRequest } = {}) {
  if (!isValidWebhookUrl(urlValue)) throw new Error("invalid_n8n_webhook_url")
  const url = new URL(urlValue)
  const hostname = url.hostname.replace(/^\[|\]$/g, "").replace(/\.$/, "").toLowerCase()
  const literal = isIP(hostname)
  const addresses = literal ? [hostname] : await resolver(hostname)
  if (!addresses.length || addresses.some((address) => !isPublicIPv4(address))) {
    throw new Error("n8n_webhook_destination_not_public")
  }
  const address = addresses[0]

  return new Promise((resolve, reject) => {
    const req = request(url, {
      method: options.method ?? "POST",
      headers: options.headers ?? {},
      family: 4,
      servername: hostname,
      lookup: (_host, _lookupOptions, callback) => callback(null, address, 4),
    }, (response) => {
      response.resume()
      response.on("end", () => {
        const status = response.statusCode ?? 0
        resolve({ ok: status >= 200 && status < 300, status })
      })
      response.on("error", reject)
    })
    req.on("error", reject)
    req.setTimeout?.(8000, () => req.destroy(new Error("n8n_webhook_timeout")))
    req.end(options.body ?? "")
  })
}
