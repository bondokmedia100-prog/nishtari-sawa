import assert from "node:assert/strict"
import { EventEmitter } from "node:events"
import test from "node:test"
import { decryptWebhookSecret, encryptWebhookSecret, isValidWebhookSecret, isValidWebhookUrl } from "../src/integration-secrets.mjs"
import { postPublicWebhook } from "../src/webhook-transport.mjs"

const masterSecret = "a-long-test-secret-that-is-not-used-in-production"
const webhookSecret = "a-webhook-secret-long-enough-for-this-test"

test("n8n webhook secrets are encrypted and decrypt only with the same key", () => {
  const envelope = encryptWebhookSecret(webhookSecret, masterSecret)
  assert.equal(envelope.includes(webhookSecret), false)
  assert.equal(decryptWebhookSecret(envelope, masterSecret), webhookSecret)
  assert.throws(() => decryptWebhookSecret(envelope, `${masterSecret}-different`))
})

test("webhook URLs require public HTTPS destinations", () => {
  assert.equal(isValidWebhookUrl("https://n8n.example.org/webhook/abc"), true)
  assert.equal(isValidWebhookUrl("http://n8n.example.org/webhook/abc"), false)
  assert.equal(isValidWebhookUrl("https://127.0.0.1/webhook/abc"), false)
  assert.equal(isValidWebhookUrl("https://192.168.1.10/webhook/abc"), false)
  assert.equal(isValidWebhookUrl("https://localhost/webhook/abc"), false)
  assert.equal(isValidWebhookUrl("https://user:pass@n8n.example.org/webhook/abc"), false)
})

test("webhook secrets have a minimum size and reject control characters", () => {
  assert.equal(isValidWebhookSecret(webhookSecret), true)
  assert.equal(isValidWebhookSecret("too-short"), false)
  assert.equal(isValidWebhookSecret(`${webhookSecret}\n`), false)
})

test("webhook transport resolves and pins only public IPv4 destinations", async () => {
  let requestInfo
  const response = await postPublicWebhook("https://n8n.example.org/hook", {
    method: "POST",
    headers: { Authorization: `Bearer ${webhookSecret}` },
    body: "{}",
  }, {
    async resolver(hostname) {
      assert.equal(hostname, "n8n.example.org")
      return ["8.8.8.8"]
    },
    request(url, options, onResponse) {
      requestInfo = { url, options }
      const req = new EventEmitter()
      req.setTimeout = () => {}
      req.end = (body) => {
        requestInfo.body = body
        const res = new EventEmitter()
        res.statusCode = 202
        res.resume = () => {}
        onResponse(res)
        queueMicrotask(() => res.emit("end"))
      }
      return req
    },
  })

  let pinnedAddress
  requestInfo.options.lookup("n8n.example.org", {}, (_error, address) => { pinnedAddress = address })
  assert.equal(requestInfo.url.hostname, "n8n.example.org")
  assert.equal(requestInfo.options.servername, "n8n.example.org")
  assert.equal(pinnedAddress, "8.8.8.8")
  assert.equal(requestInfo.body, "{}")
  assert.equal(response.ok, true)
})

test("webhook transport rejects mixed public and private DNS answers", async () => {
  let requested = false
  await assert.rejects(
    postPublicWebhook("https://n8n.example.org/hook", { body: "{}" }, {
      async resolver() { return ["8.8.8.8", "10.0.0.4"] },
      request() { requested = true },
    }),
    /n8n_webhook_destination_not_public/,
  )
  assert.equal(requested, false)
})
