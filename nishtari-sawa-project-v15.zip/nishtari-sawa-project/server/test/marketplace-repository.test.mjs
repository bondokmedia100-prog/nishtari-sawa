import assert from "node:assert/strict"
import { readFile } from "node:fs/promises"
import test from "node:test"
import { DealRepository } from "../src/deal-repository.mjs"

const sellerId = "65000000-0000-4000-8000-000000000001"
const buyerId = "66000000-0000-4000-8000-000000000001"
const dealId = "55000000-0000-4000-8000-000000000001"
const membershipId = "77000000-0000-4000-8000-000000000001"

test("review creation requires the caller's paid, delivered membership and is one-per-order", async () => {
  const statements = []
  let eligible = false
  const client = {
    async query(sql) {
      statements.push(sql)
      if (["BEGIN", "COMMIT", "ROLLBACK"].includes(sql)) return { rows: [], rowCount: 0 }
      if (sql.includes("FROM deal_memberships m") && sql.includes("FOR UPDATE OF m")) {
        return { rows: eligible ? [{ id: membershipId }] : [], rowCount: eligible ? 1 : 0 }
      }
      if (sql.includes("INSERT INTO product_reviews")) {
        return { rows: eligible ? [{ id: "88000000-0000-4000-8000-000000000001", membership_id: membershipId, deal_id: dealId, rating: 5, comment: "Excellent", created_at: new Date() }] : [], rowCount: eligible ? 1 : 0 }
      }
      throw new Error(`Unexpected query: ${sql}`)
    },
    release() {},
  }
  const repository = new DealRepository({ async connect() { return client } })
  await assert.rejects(
    repository.createReview({ buyerId, membershipId, rating: 5, comment: "Excellent" }),
    { statusCode: 409, code: "order_not_reviewable" },
  )
  const eligibilityQuery = statements.find((sql) => sql.includes("FROM deal_memberships m"))
  assert.match(eligibilityQuery, /m\.buyer_id = \$2/)
  assert.match(eligibilityQuery, /m\.fulfillment_status IN \('delivered', 'picked_up'\)/)
  assert.match(eligibilityQuery, /payment\.status = 'paid'/)
  assert.ok(!statements.some((sql) => sql.includes("INSERT INTO product_reviews")))

  eligible = true
  const review = await repository.createReview({ buyerId, membershipId, rating: 5, comment: "Excellent" })
  assert.equal(review.rating, 5)
  assert.equal(review.membershipId, membershipId)
  assert.match(statements.find((sql) => sql.includes("INSERT INTO product_reviews")), /ON CONFLICT \(membership_id\) DO NOTHING/)
})

test("support ticket listing is scoped to the signed-in owner", async () => {
  let query
  const repository = new DealRepository({
    async query(sql, params) {
      query = { sql, params }
      return { rows: [{ id: "99000000-0000-4000-8000-000000000001", subject: "Help", message: "Need help", status: "open", admin_reply: null }] }
    },
  })
  const tickets = await repository.supportTickets(buyerId)
  assert.equal(query.params[0], buyerId)
  assert.match(query.sql, /WHERE user_id = \$1/)
  assert.equal(tickets[0].status, "open")
})

test("profile updates reject clearing a contact needed for WhatsApp consent", async () => {
  const statements = []
  const client = {
    async query(sql) {
      statements.push(sql)
      if (sql === "BEGIN" || sql === "ROLLBACK") return { rows: [], rowCount: 0 }
      if (sql.includes("SELECT role, whatsapp_opt_in")) return { rows: [{ role: "buyer", whatsapp_opt_in: true }], rowCount: 1 }
      throw new Error(`Unexpected query: ${sql}`)
    },
    release() {},
  }
  const repository = new DealRepository({ async connect() { return client } })
  await assert.rejects(
    repository.updateMyProfile(buyerId, { phone: null }),
    { statusCode: 400, code: "phone_required_for_whatsapp" },
  )
  assert.ok(!statements.some((sql) => sql.includes("UPDATE users")))
  assert.ok(statements.includes("ROLLBACK"))
})

test("trust updates target a supplier profile and preserve explicit verification state", async () => {
  let call
  const repository = new DealRepository({
    async query(sql, params) {
      call = { sql, params }
      return { rows: [{ user_id: sellerId, business_name: "Shop", verified_at: new Date() }] }
    },
  })
  const result = await repository.setSellerTrusted(sellerId, true)
  assert.equal(result.verified, true)
  assert.equal(call.params[0], sellerId)
  assert.equal(call.params[1], true)
  assert.match(call.sql, /WHERE user_id = \$1/)
})

test("deal image writes are scoped to the owning supplier", async () => {
  let call
  const repository = new DealRepository({
    async query(sql, params) {
      call = { sql, params }
      return { rows: [{ id: "product-id" }] }
    },
  })
  const bytes = Buffer.from([0x89, 0x50, 0x4e, 0x47])
  const result = await repository.updateDealImage({ dealId, ownerUserId: sellerId, image: { mimeType: "image/png", bytes } })
  assert.equal(result.imageUrl, `/api/v1/deals/${dealId}/image`)
  assert.match(call.sql, /sp\.user_id = \$2/)
  assert.deepEqual(call.params, [dealId, sellerId, bytes, "image/png"])
})

test("highlights rank paid completed seller quantities and include trust and ratings", async () => {
  let query
  const rows = [
    { id: "deal-cheapest", name: "Cheap", seller_user_id: sellerId, seller_name: "Seller", verified_at: null, unit_price_minor: 200, retail_price_minor: 300, platform_subsidy_minor: 0, subsidies_enabled: false, stock_quantity: 10, max_quantity: null, committed_quantity: 0, seller_completed_quantity: 0, seller_rating: null, review_count: 0, distance_km: 1, ends_at: new Date("2030-01-01"), has_image: false },
    { id: "deal-best", name: "Popular", seller_user_id: "65000000-0000-4000-8000-000000000002", seller_name: "Trusted Shop", verified_at: new Date(), unit_price_minor: 500, retail_price_minor: 700, platform_subsidy_minor: 0, subsidies_enabled: false, stock_quantity: 10, max_quantity: null, committed_quantity: 0, seller_completed_quantity: 45, seller_rating: "4.8", review_count: 9, distance_km: 2, ends_at: new Date("2030-01-02"), has_image: true },
  ].map((row) => ({
    category: "produce", emoji: "🍎", unit: "kg", moq: 5, accepts_shipping: true, accepts_pickup: true,
    ...row,
  }))
  const repository = new DealRepository({
    async query(sql, params) {
      query = { sql, params }
      return { rows }
    },
  })
  const highlights = await repository.highlights({ latitude: 30, longitude: 31, radiusKm: 3 })
  assert.equal(highlights.cheapest[0].id, "deal-cheapest")
  assert.equal(highlights.bestSellers[0].id, "deal-best")
  assert.equal(highlights.trustedSellers[0].sellerVerified, true)
  assert.equal(highlights.bestSellers[0].sellerRating, 4.8)
  assert.equal(highlights.bestSellers[0].sellerReviewCount, 9)
  assert.equal(highlights.bestSellers[0].imageUrl, "/api/v1/deals/deal-best/image")
  assert.match(query.sql, /payment\.status = 'paid'/)
  assert.match(query.sql, /m\.fulfillment_status IN \('delivered', 'picked_up'\)/)
  assert.deepEqual(query.params, [30, 31, 3])
})

test("membership trigger stores seller notifications and remaining MOQ without messaging claims", async () => {
  const migration = await readFile(new URL("../sql/012_marketplace_mvp.sql", import.meta.url), "utf8")
  const paymentMigration = await readFile(new URL("../sql/013_manual_transfers.sql", import.meta.url), "utf8")
  assert.match(migration, /CREATE TRIGGER deal_membership_supplier_notification/)
  assert.match(migration, /INSERT INTO supplier_notifications/)
  assert.match(migration, /'remainingToMoq', remaining/)
  assert.match(migration, /INSERT INTO notification_outbox/)
  assert.doesNotMatch(migration, /whatsapp|sms/i)
  assert.match(paymentMigration, /AFTER UPDATE OF status ON deal_memberships/)
  assert.match(paymentMigration, /OLD\.status = 'pending_payment' AND NEW\.status = 'held'/)
})
