import assert from "node:assert/strict"
import { readFile } from "node:fs/promises"
import test from "node:test"

test("starter n8n workflow rejects events until a durable consumer is configured", async () => {
  const workflow = JSON.parse(await readFile(new URL("../../../nishtari-sawa-n8n-workflow.json", import.meta.url), "utf8"))
  const response = workflow.nodes.find((node) => node.name === "Acknowledge Accepted Event")
  const validator = workflow.nodes.find((node) => node.name === "Validate Event Envelope")

  assert.equal(response.parameters.options.responseCode, 503)
  assert.match(validator.parameters.jsCode, /downstream_processor_not_configured/)
  assert.equal(workflow.active, false)
})
