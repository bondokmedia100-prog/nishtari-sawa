import assert from "node:assert/strict"
import test from "node:test"
import { DealRepository } from "../src/deal-repository.mjs"

const dealId = "50000000-0000-4000-8000-000000000001"
const buyerId = "65000000-0000-4000-8000-000000000001"

function createJoinPool({ committed = 0, stock = 20, existing = [], replay = null, deal = {} } = {}) {
  const statements = []
  const client = {
    async query(sql, params = []) {
      statements.push({ sql, params })
      if (["BEGIN", "COMMIT", "ROLLBACK"].includes(sql)) return { rows: [], rowCount: 0 }
      if (sql.includes("SELECT m.id, m.status, m.buyer_total_minor")) return { rows: replay ? [replay] : [], rowCount: replay ? 1 : 0 }
      if (sql.includes("SELECT d.id, d.status, d.ends_at, d.unit_price_minor")) return { rows: [{
        id: dealId, status: "active", ends_at: new Date(Date.now() + 60_000), unit_price_minor: 850,
        platform_subsidy_minor: 0, moq: 10, max_quantity: null, stock_quantity: stock,
        accepts_shipping: true, accepts_pickup: true, name: "Test product", subsidies_enabled: false,
        committed_quantity: String(committed), ...deal,
      }] }
      if (sql.includes("UPDATE deal_memberships SET status = 'cancelled'")) return { rows: [], rowCount: 0 }
      if (sql.includes("SELECT id FROM deal_memberships")) return { rows: existing, rowCount: existing.length }
      if (sql.includes("INSERT INTO deal_memberships")) return { rows: [{
        id: "66000000-0000-4000-8000-000000000101", status: "pending_payment",
        reservation_expires_at: new Date(Date.now() + 15 * 60_000),
      }], rowCount: 1 }
      if (sql.includes("INSERT INTO payments")) return { rows: [], rowCount: 1 }
      throw new Error(`Unexpected query: ${sql}`)
    },
    release() {},
  }
  return { pool: { async connect() { return client } }, client, statements }
}

const joinPayload = {
  dealId, buyerId, quantity: 2, requestKey: "request-key-manual-123",
  paymentMethod: "vodafone_cash", fulfillmentMethod: "self_pickup", appSettings: { orders_enabled: true },
}

test("manual-payment join reserves stock but never marks the transfer as paid", async () => {
  const { pool, statements } = createJoinPool()
  const repository = new DealRepository(pool)
  const order = await repository.join(joinPayload)
  assert.equal(order.status, "pending_payment")
  assert.equal(order.paymentStatus, "awaiting_transfer")
  assert.equal(order.amountMinor, 1700)
  const paymentInsert = statements.find(({ sql }) => sql.includes("INSERT INTO payments"))
  assert.match(paymentInsert.sql, /'awaiting_transfer'/)
  assert.doesNotMatch(paymentInsert.sql, /'paid'/)
  assert.equal(paymentInsert.params[2], "vodafone_cash")
  assert.equal(statements.at(-1).sql, "COMMIT")
})

test("idempotent retries return the existing manual-payment order", async () => {
  const replay = {
    id: "66000000-0000-4000-8000-000000000102", status: "pending_payment", buyer_total_minor: 1700,
    payment_status: "submitted",
    request_fingerprint: "e4315d3a0dd1c6d3b86f5b2850d4a29f639bf92a7cfa82d17d351c765c1d6764",
  }
  const { pool, statements } = createJoinPool({ replay })
  const repository = new DealRepository(pool)
  const expectedFingerprint = (await import("node:crypto")).createHash("sha256").update(JSON.stringify({
    dealId, quantity: 2, paymentMethod: "vodafone_cash", fulfillmentMethod: "self_pickup", shippingAddress: null,
    couponCode: null, loyaltyPointsToUse: 0,
  })).digest("hex")
  replay.request_fingerprint = expectedFingerprint
  const result = await repository.join(joinPayload)
  assert.equal(result.membershipId, replay.id)
  assert.equal(result.paymentStatus, "submitted")
  assert.ok(!statements.some(({ sql }) => sql.includes("INSERT INTO deal_memberships")))
})

test("unavailable stock is rejected before creating a payment or order", async () => {
  const { pool, statements } = createJoinPool({ committed: 19, stock: 20 })
  const repository = new DealRepository(pool)
  await assert.rejects(repository.join({ ...joinPayload, quantity: 2 }), { statusCode: 409, code: "insufficient_stock" })
  assert.ok(!statements.some(({ sql }) => sql.includes("INSERT INTO payments") || sql.includes("INSERT INTO deal_memberships")))
  assert.equal(statements.at(-1).sql, "ROLLBACK")
})

test("join rejects replaying an idempotency key with changed input", async () => {
  const { pool } = createJoinPool({ replay: {
    id: "66000000-0000-4000-8000-000000000103", status: "pending_payment", buyer_total_minor: 1700,
    payment_status: "awaiting_transfer", request_fingerprint: "different-fingerprint",
  } })
  const repository = new DealRepository(pool)
  await assert.rejects(repository.join(joinPayload), { statusCode: 409, code: "idempotency_key_reused" })
})

test("receipt submission stores proof and extends the review reservation", async () => {
  const statements = []
  const client = {
    async query(sql, params = []) {
      statements.push({ sql, params })
      if (["BEGIN", "COMMIT", "ROLLBACK"].includes(sql)) return { rows: [], rowCount: 0 }
      if (sql.includes("SELECT m.id, m.status, m.reservation_expires_at")) return { rows: [{
        id: "66000000-0000-4000-8000-000000000104", status: "pending_payment",
        reservation_expires_at: new Date(Date.now() + 10 * 60_000), payment_status: "awaiting_transfer",
      }] }
      if (sql.includes("UPDATE payments SET status = 'submitted'")) return { rows: [{
        membership_id: "66000000-0000-4000-8000-000000000104", status: "submitted",
        payment_method: "vodafone_cash", submitted_at: new Date(),
      }] }
      if (sql.includes("UPDATE deal_memberships SET reservation_expires_at")) return { rows: [], rowCount: 1 }
      throw new Error(`Unexpected query: ${sql}`)
    },
    release() {},
  }
  const repository = new DealRepository({ async connect() { return client } })
  const receipt = { bytes: Buffer.from([1, 2, 3]), mimeType: "image/jpeg" }
  const result = await repository.submitPaymentReceipt({
    membershipId: "66000000-0000-4000-8000-000000000104", buyerId, receipt, paymentReference: "TX-123",
  })
  assert.equal(result.paymentStatus, "submitted")
  assert.deepEqual(statements.find(({ sql }) => sql.includes("UPDATE payments SET status = 'submitted'")).params.slice(1), ["TX-123", receipt.bytes, "image/jpeg"])
  assert.ok(statements.some(({ sql }) => sql.includes("interval '24 hours'")))
  assert.equal(statements.at(-1).sql, "COMMIT")
})

test("admin approval marks payment paid before releasing the order to the seller", async () => {
  const statements = []
  const client = {
    async query(sql, params = []) {
      statements.push({ sql, params })
      if (["BEGIN", "COMMIT", "ROLLBACK"].includes(sql)) return { rows: [], rowCount: 0 }
      if (sql.includes("SELECT m.id, m.status AS membership_status")) return { rows: [{
        id: "66000000-0000-4000-8000-000000000105", membership_status: "pending_payment",
        buyer_id: buyerId, payment_status: "submitted", receipt_data: Buffer.from([1]), name: "Test product",
      }] }
      if (sql.includes("UPDATE payments SET status = 'paid'")) return { rows: [], rowCount: 1 }
      if (sql.includes("UPDATE deal_memberships SET status = 'held'")) return { rows: [], rowCount: 1 }
      if (sql.includes("SELECT id, full_name, phone, whatsapp_opt_in")) return { rows: [] }
      if (sql.includes("INSERT INTO notification_outbox")) return { rows: [], rowCount: 0 }
      throw new Error(`Unexpected query: ${sql}`)
    },
    release() {},
  }
  const repository = new DealRepository({ async connect() { return client } })
  const result = await repository.reviewManualPayment({
    membershipId: "66000000-0000-4000-8000-000000000105", adminId: "75000000-0000-4000-8000-000000000001", action: "approve",
  })
  assert.equal(result.paymentStatus, "paid")
  assert.equal(result.orderStatus, "held")
  const paidIndex = statements.findIndex(({ sql }) => sql.includes("UPDATE payments SET status = 'paid'"))
  const heldIndex = statements.findIndex(({ sql }) => sql.includes("UPDATE deal_memberships SET status = 'held'"))
  assert.ok(paidIndex < heldIndex)
  assert.equal(statements.at(-1).sql, "COMMIT")
})

test("admin rejection leaves the order pending and stores a correction note", async () => {
  const statements = []
  const client = {
    async query(sql, params = []) {
      statements.push({ sql, params })
      if (["BEGIN", "COMMIT", "ROLLBACK"].includes(sql)) return { rows: [], rowCount: 0 }
      if (sql.includes("SELECT m.id, m.status AS membership_status")) return { rows: [{
        id: "66000000-0000-4000-8000-000000000106", membership_status: "pending_payment",
        buyer_id: buyerId, payment_status: "submitted", receipt_data: Buffer.from([1]), name: "Test product",
      }] }
      if (sql.includes("UPDATE payments SET status = 'rejected'")) return { rows: [], rowCount: 1 }
      if (sql.includes("UPDATE deal_memberships SET reservation_expires_at")) return { rows: [], rowCount: 1 }
      if (sql.includes("SELECT id, full_name, phone, whatsapp_opt_in")) return { rows: [] }
      if (sql.includes("INSERT INTO notification_outbox")) return { rows: [], rowCount: 0 }
      throw new Error(`Unexpected query: ${sql}`)
    },
    release() {},
  }
  const repository = new DealRepository({ async connect() { return client } })
  const result = await repository.reviewManualPayment({
    membershipId: "66000000-0000-4000-8000-000000000106", adminId: "75000000-0000-4000-8000-000000000001",
    action: "reject", note: "الصورة لا توضح رقم التحويل.",
  })
  assert.equal(result.paymentStatus, "rejected")
  assert.equal(result.orderStatus, "pending_payment")
  assert.ok(statements.some(({ sql, params }) => sql.includes("UPDATE payments SET status = 'rejected'") && params[2] === "الصورة لا توضح رقم التحويل."))
})

test("expired reservations are cancelled and their benefits released atomically", async () => {
  const statements = []
  const client = {
    async query(sql, params = []) {
      statements.push({ sql, params })
      if (["BEGIN", "COMMIT", "ROLLBACK"].includes(sql)) return { rows: [], rowCount: 0 }
      if (sql.includes("WITH expired AS")) return { rows: [{ id: "66000000-0000-4000-8000-000000000010" }], rowCount: 1 }
      if (sql.includes("UPDATE payments")) return { rows: [], rowCount: 1 }
      if (sql.includes("UPDATE coupon_redemptions")) return { rows: [], rowCount: 1 }
      if (sql.includes("UPDATE loyalty_ledger")) return { rows: [], rowCount: 1 }
      throw new Error(`Unexpected query: ${sql}`)
    },
    release() {},
  }
  const repository = new DealRepository({ async connect() { return client } })
  const result = await repository.expirePendingReservations()
  assert.deepEqual(result, { expired: 1 })
  assert.equal(statements.find((entry) => entry.sql.includes("WITH expired AS")).params[0], 500)
  assert.ok(statements.some((entry) => entry.sql.includes("UPDATE coupon_redemptions")))
  assert.ok(statements.some((entry) => entry.sql.includes("UPDATE loyalty_ledger")))
  assert.ok(statements.some((entry) => entry.sql === "COMMIT"))
})

test("inventory cannot be reduced below reserved orders", async () => {
  const statements = []
  const client = {
    async query(sql) {
      statements.push(sql)
      if (["BEGIN", "COMMIT", "ROLLBACK"].includes(sql)) return { rows: [], rowCount: 0 }
      if (sql.includes("SELECT d.id, d.moq, d.stock_quantity")) {
        return { rows: [{ id: dealId, moq: 10, stock_quantity: 50, max_quantity: 100, accepts_shipping: true, accepts_pickup: true, committed_quantity: "15" }] }
      }
      if (sql.includes("UPDATE deals")) {
        return { rows: [{ id: dealId, stock_quantity: 30, max_quantity: null, accepts_shipping: false, accepts_pickup: true }] }
      }
      throw new Error(`Unexpected query: ${sql}`)
    },
    release() {},
  }
  const repository = new DealRepository({ async connect() { return client } })
  await assert.rejects(
    repository.updateDealInventory({ dealId, ownerUserId: buyerId, stockQuantity: 14 }),
    { statusCode: 409, code: "inventory_below_reserved" },
  )
  assert.ok(statements.includes("ROLLBACK"))

  const result = await repository.updateDealInventory({ dealId, ownerUserId: buyerId, stockQuantity: 30, maxQuantity: null, acceptsShipping: false, acceptsPickup: true })
  assert.equal(result.availableQuantity, 15)
  assert.equal(result.acceptsPickup, true)
})

test("shipping cannot be marked as dispatched without tracking details", async () => {
  const statements = []
  const client = {
    async query(sql) {
      statements.push(sql)
      if (["BEGIN", "COMMIT", "ROLLBACK"].includes(sql)) return { rows: [], rowCount: 0 }
      if (sql.includes("SELECT m.id, m.status AS order_status")) {
        return { rows: [{ id: "66000000-0000-4000-8000-000000000001", order_status: "held", payment_status: "paid", fulfillment_method: "merchant_shipping", fulfillment_status: "preparing", tracking_number: null, tracking_url: null, buyer_id: buyerId, buyer_total_minor: 850, name: "Test product" }] }
      }
      if (sql.includes("UPDATE deal_memberships")) {
        return { rows: [{ id: "66000000-0000-4000-8000-000000000001", fulfillment_status: "shipped", carrier_name: "Local Courier", tracking_number: "NS123", tracking_url: null, fulfillment_note: null, fulfillment_updated_at: new Date() }] }
      }
      if (sql.includes("SELECT id, full_name, phone, whatsapp_opt_in")) return { rows: [{ id: buyerId, full_name: "Test Buyer", phone: null, whatsapp_opt_in: false }] }
      if (sql.includes("INSERT INTO notification_outbox")) return { rows: [], rowCount: 0 }
      throw new Error(`Unexpected query: ${sql}`)
    },
    release() {},
  }
  const repository = new DealRepository({ async connect() { return client } })
  await assert.rejects(
    repository.setFulfillment({ membershipId: "66000000-0000-4000-8000-000000000001", status: "shipped" }),
    { statusCode: 400, code: "tracking_details_required" },
  )
  const updated = await repository.setFulfillment({
    membershipId: "66000000-0000-4000-8000-000000000001",
    status: "shipped",
    carrierName: "Local Courier",
    trackingNumber: "NS123",
  })
  assert.equal(updated.fulfillmentStatus, "shipped")
  assert.equal(updated.trackingNumber, "NS123")
  assert.ok(statements.includes("COMMIT"))
})

test("fulfillment distinguishes missing payment setup from other unpaid orders", async () => {
  const statements = []
  let lookup = 0
  const client = {
    async query(sql) {
      statements.push(sql)
      if (["BEGIN", "COMMIT", "ROLLBACK"].includes(sql)) return { rows: [], rowCount: 0 }
      if (sql.includes("SELECT m.id, m.status AS order_status")) {
        lookup += 1
        return { rows: [{
          id: "66000000-0000-4000-8000-000000000002",
          order_status: lookup === 1 ? "pending_payment" : "held",
          payment_status: lookup < 3 ? "not_configured" : "failed",
          fulfillment_method: "merchant_shipping",
          fulfillment_status: "not_started",
        }] }
      }
      throw new Error(`Unexpected query: ${sql}`)
    },
    release() {},
  }
  const repository = new DealRepository({ async connect() { return client } })
  await assert.rejects(
    repository.setFulfillment({ membershipId: "66000000-0000-4000-8000-000000000002", status: "preparing" }),
    { statusCode: 409, code: "payment_provider_not_connected" },
  )
  await assert.rejects(
    repository.setFulfillment({ membershipId: "66000000-0000-4000-8000-000000000002", status: "preparing" }),
    { statusCode: 409, code: "payment_provider_not_connected" },
  )
  await assert.rejects(
    repository.setFulfillment({ membershipId: "66000000-0000-4000-8000-000000000002", status: "preparing" }),
    { statusCode: 409, code: "order_not_fulfillable" },
  )
  assert.ok(!statements.some((sql) => sql.includes("UPDATE deal_memberships")))
})

test("fulfillment cannot move backwards", async () => {
  const client = {
    async query(sql) {
      if (["BEGIN", "COMMIT", "ROLLBACK"].includes(sql)) return { rows: [], rowCount: 0 }
      if (sql.includes("SELECT m.id, m.status AS order_status")) {
        return { rows: [{ id: "66000000-0000-4000-8000-000000000003", order_status: "held", payment_status: "paid", fulfillment_method: "merchant_shipping", fulfillment_status: "shipped" }] }
      }
      throw new Error(`Unexpected query: ${sql}`)
    },
    release() {},
  }
  const repository = new DealRepository({ async connect() { return client } })
  await assert.rejects(
    repository.setFulfillment({ membershipId: "66000000-0000-4000-8000-000000000003", status: "preparing" }),
    { statusCode: 409, code: "invalid_fulfillment_transition" },
  )
})

test("admin cancellation rejects progressed orders and preserves fulfillment history", async () => {
  const statements = []
  let cancellations = 0
  const client = {
    async query(sql) {
      statements.push(sql)
      if (["BEGIN", "COMMIT", "ROLLBACK"].includes(sql)) return { rows: [], rowCount: 0 }
      if (sql.includes("UPDATE deal_memberships") && sql.includes("fulfillment_status = 'not_started'")) {
        cancellations += 1
        return cancellations === 1 ? { rows: [], rowCount: 0 } : { rows: [{ id: "66000000-0000-4000-8000-000000000004", status: "cancelled" }], rowCount: 1 }
      }
      if (sql.includes("UPDATE payments") || sql.includes("UPDATE coupon_redemptions") || sql.includes("UPDATE loyalty_ledger")) return { rows: [], rowCount: 1 }
      throw new Error(`Unexpected query: ${sql}`)
    },
    release() {},
  }
  const repository = new DealRepository({ async connect() { return client } })
  await assert.rejects(repository.cancelAdminOrder("66000000-0000-4000-8000-000000000004"), { statusCode: 404, code: "order_not_cancellable" })
  assert.deepEqual(await repository.cancelAdminOrder("66000000-0000-4000-8000-000000000004"), {
    membershipId: "66000000-0000-4000-8000-000000000004",
    status: "cancelled",
  })
  assert.ok(statements.filter((sql) => sql.includes("UPDATE deal_memberships")).every((sql) => !sql.includes("SET status = 'cancelled', fulfillment_status")))
})

test("a new offer keeps its pickup point without moving the seller's existing offers", async () => {
  const statements = []
  const client = {
    async query(sql, params = []) {
      statements.push({ sql, params })
      if (["BEGIN", "COMMIT", "ROLLBACK"].includes(sql)) return { rows: [], rowCount: 0 }
      if (sql.includes("SELECT id, business_name FROM supplier_profiles")) {
        return { rows: [{ id: "20000000-0000-4000-8000-000000000001", business_name: "Local Shop" }] }
      }
      if (sql.includes("INSERT INTO leader_profiles")) return { rows: [] }
      if (sql.includes("SELECT id FROM leader_profiles")) {
        return { rows: [{ id: "30000000-0000-4000-8000-000000000001" }] }
      }
      if (sql.includes("INSERT INTO products")) {
        return { rows: [{ id: "40000000-0000-4000-8000-000000000001" }] }
      }
      if (sql.includes("INSERT INTO deals")) {
        return { rows: [{ id: dealId, ends_at: new Date("2030-01-01T00:00:00Z"), status: "draft", created_at: new Date() }] }
      }
      throw new Error(`Unexpected query: ${sql}`)
    },
    release() {},
  }
  const repository = new DealRepository({ async connect() { return client } })
  const deal = await repository.createOffer({
    userId: "65000000-0000-4000-8000-000000000002",
    name: "Apples",
    category: "produce",
    emoji: "🍎",
    unit: "kg",
    price: 8,
    retailPrice: 12,
    moq: 10,
    maxQuantity: 80,
    stockQuantity: 80,
    acceptsShipping: true,
    acceptsPickup: true,
    latitude: 31.2,
    longitude: 29.9,
    pickupLabel: "Alexandria pickup point",
    endsAt: new Date("2030-01-01T00:00:00Z"),
    image: { mimeType: "image/jpeg", bytes: Buffer.from([0xff, 0xd8, 0xff, 0xe0]) },
  })

  const leaderInsert = statements.find(({ sql }) => sql.includes("INSERT INTO leader_profiles"))
  const dealInsert = statements.find(({ sql }) => sql.includes("INSERT INTO deals"))
  assert.match(leaderInsert.sql, /ON CONFLICT \(user_id\) DO NOTHING/)
  assert.match(dealInsert.sql, /pickup_location, pickup_label/)
  assert.deepEqual(dealInsert.params.slice(3, 6), [29.9, 31.2, "Alexandria pickup point"])
  const productInsert = statements.find(({ sql }) => sql.includes("INSERT INTO products"))
  assert.equal(productInsert.params[5].toString("hex"), "ffd8ffe0")
  assert.equal(productInsert.params[6], "image/jpeg")
  assert.equal(deal.imageUrl, `/api/v1/deals/${dealId}/image`)
  assert.equal(deal.location, "Alexandria pickup point")
})
