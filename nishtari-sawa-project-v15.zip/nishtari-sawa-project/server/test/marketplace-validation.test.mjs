import assert from "node:assert/strict"
import test from "node:test"
import {
  EGYPTIAN_GOVERNORATES,
  PRODUCT_CATEGORIES,
  isHttpsUrl,
  normalizeProductCategory,
  parseEgyptianLocation,
  parseProductImageDataUrl,
} from "../src/marketplace-validation.mjs"

test("governorates and marketplace categories are stable and canonical", () => {
  assert.equal(EGYPTIAN_GOVERNORATES.length, 27)
  assert.equal(PRODUCT_CATEGORIES.length, 10)
  assert.deepEqual(
    PRODUCT_CATEGORIES.map(({ id }) => id),
    ["grocery", "sweets", "electronics", "produce", "bakery", "dairy", "home", "personal_care", "cleaning", "other"],
  )
  assert.equal(normalizeProductCategory(" Fruit "), "produce")
  assert.equal(normalizeProductCategory("سوبرماركت وبقالة"), "grocery")
  assert.equal(normalizeProductCategory("unknown historic input"), null)
})

test("profile coordinates require an in-bounds Egyptian pair", () => {
  assert.deepEqual(parseEgyptianLocation({
    governorate: " القاهرة ", city: "Nasr City", address: "Street 1", latitude: 30.05, longitude: 31.2,
  }).location, {
    governorate: "القاهرة", city: "Nasr City", address: "Street 1", latitude: 30.05, longitude: 31.2,
  })
  assert.equal(parseEgyptianLocation({ governorate: "Dubai" }).error, "invalid_egyptian_governorate")
  assert.equal(parseEgyptianLocation({ latitude: 30.05 }).error, "coordinate_pair_required")
  assert.equal(parseEgyptianLocation({ latitude: 30.05, longitude: 31.2 }).error, undefined)
  assert.equal(parseEgyptianLocation({ latitude: 30.05, longitude: 40 }).error, "coordinates_outside_egypt")
  assert.equal(parseEgyptianLocation({ latitude: 91, longitude: 31 }).error, "invalid_coordinates")
})

test("image data URLs enforce allowlisted MIME, matching signatures, and decoded size", () => {
  const jpeg = Buffer.from([0xff, 0xd8, 0xff, 0xe0, ...Array(6).fill(0), 0xff, 0xd9])
  const jpegUrl = `data:image/jpeg;base64,${jpeg.toString("base64")}`
  assert.equal(parseProductImageDataUrl(jpegUrl).image.mimeType, "image/jpeg")
  assert.equal(parseProductImageDataUrl(`data:image/png;base64,${jpeg.toString("base64")}`).error, "invalid_product_image")
  assert.equal(parseProductImageDataUrl(`data:image/svg+xml;base64,${jpeg.toString("base64")}`).error, "invalid_product_image")

  const png = Buffer.alloc(33)
  Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]).copy(png)
  png.writeUInt32BE(13, 8)
  png.write("IHDR", 12, "ascii")
  png.writeUInt32BE(1, 16)
  png.writeUInt32BE(1, 20)
  assert.equal(parseProductImageDataUrl(`data:image/png;base64,${png.toString("base64")}`).image.mimeType, "image/png")

  const oversized = Buffer.alloc(350 * 1024 + 1)
  jpeg.copy(oversized)
  oversized[0] = 0xff
  oversized[1] = 0xd8
  oversized[2] = 0xff
  oversized[3] = 0xe0
  oversized[oversized.length - 2] = 0xff
  oversized[oversized.length - 1] = 0xd9
  assert.equal(parseProductImageDataUrl(`data:image/jpeg;base64,${oversized.toString("base64")}`).error, "invalid_product_image")
  assert.equal(parseProductImageDataUrl(`data:image/jpeg;base64,${oversized.toString("base64")}`, { maxBytes: 1024 * 1024 }).image.bytes.length, oversized.length)
})

test("brand logos require credential-free HTTPS URLs", () => {
  assert.equal(isHttpsUrl("https://cdn.example.com/logo.png"), true)
  assert.equal(isHttpsUrl("http://cdn.example.com/logo.png"), false)
  assert.equal(isHttpsUrl("https://user:pass@example.com/logo.png"), false)
})
