import assert from "node:assert/strict"
import test from "node:test"
import { runMigrations } from "../src/migrate.mjs"

function migrationPool() {
  const applied = new Set()
  const pool = {
    async connect() {
      return {
        async query(sql, params = []) {
          if (sql.startsWith("SELECT 1 FROM schema_migrations")) {
            return { rows: applied.has(params[0]) ? [{}] : [], rowCount: applied.has(params[0]) ? 1 : 0 }
          }
          if (sql.startsWith("INSERT INTO schema_migrations")) {
            applied.add(params[0])
            return { rows: [], rowCount: 1 }
          }
          return { rows: [], rowCount: 0 }
        },
        release() {},
      }
    },
  }
  return { pool, applied }
}

test("demo seed and demo-window migrations are skipped by default", async () => {
  const { pool, applied } = migrationPool()
  await runMigrations(pool, { seedDemoData: false })
  assert.ok(!applied.has("002-seed.sql"))
  assert.ok(!applied.has("003-demo-deal-window.sql"))
  assert.ok(applied.has("011_order_safety.sql"))
  assert.ok(applied.has("012_marketplace_mvp.sql"))
})

test("demo data migrations can be explicitly enabled for local testing", async () => {
  const { pool, applied } = migrationPool()
  await runMigrations(pool, { seedDemoData: true })
  assert.ok(applied.has("002-seed.sql"))
  assert.ok(applied.has("003-demo-deal-window.sql"))
})
