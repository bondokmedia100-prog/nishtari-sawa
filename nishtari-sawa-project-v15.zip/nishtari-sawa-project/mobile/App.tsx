import React, { useEffect, useState } from "react"
import { ActivityIndicator, Alert, FlatList, Image, Linking, Modal, Platform, SafeAreaView, ScrollView, StatusBar, StyleSheet, Switch, Text, TextInput, TouchableOpacity, View } from "react-native"
import * as AppleAuthentication from "expo-apple-authentication"
import * as Crypto from "expo-crypto"
import * as Google from "expo-auth-session/providers/google"
import * as Location from "expo-location"
import * as Device from "expo-device"
import * as Notifications from "expo-notifications"
import * as ImagePicker from "expo-image-picker"
import Constants from "expo-constants"
import * as WebBrowser from "expo-web-browser"
import { Account, CartItem, Category, Deal, DealHighlights, Membership, PaymentConfig, PlatformSettings, SupportTicket, cancelMembership, createOAuthNonce, createSupportTicket, deleteCartItem, getBuyerCart, getBuyerLoyalty, getBuyerMemberships, getCategories, getDealHighlights, getNearbyDeals, getPublicConfig, getSavedAccount, getSupportTickets, loginAccount, loginWithSocial, logoutAccount, registerBuyer, registerPushDevice, requestToJoin, saveCartItem, submitBuyerReview, submitPaymentReceipt, unregisterPushDevice, updateBuyerProfile, updateWhatsAppConsent } from "./src/api"

WebBrowser.maybeCompleteAuthSession()
Notifications.setNotificationHandler({
  handleNotification: async () => ({ shouldShowAlert: true, shouldPlaySound: true, shouldSetBadge: false }),
})

const ORANGE = "#FF6F00"
const GREEN = "#2E7D32"
const GOOGLE_IOS_CLIENT_ID = process.env.EXPO_PUBLIC_GOOGLE_IOS_CLIENT_ID ?? ""
const GOOGLE_ANDROID_CLIENT_ID = process.env.EXPO_PUBLIC_GOOGLE_ANDROID_CLIENT_ID ?? ""
const GOOGLE_WEB_CLIENT_ID = process.env.EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID ?? ""
const GOVERNORATES = ["القاهرة", "الجيزة", "الإسكندرية", "القليوبية", "الشرقية", "الدقهلية", "الغربية", "المنوفية", "كفر الشيخ", "دمياط", "بورسعيد", "الإسماعيلية", "السويس", "الفيوم", "بني سويف", "المنيا", "أسيوط", "سوهاج", "قنا", "الأقصر", "أسوان", "البحر الأحمر", "الوادي الجديد", "مطروح", "شمال سيناء", "جنوب سيناء"]
const CITIES: Record<string, string[]> = {
  "القاهرة": ["مدينة نصر", "مصر الجديدة", "المعادي", "شبرا", "التجمع الخامس"],
  "الجيزة": ["الدقي", "المهندسين", "٦ أكتوبر", "الشيخ زايد", "فيصل", "الهرم"],
  "الإسكندرية": ["سيدي جابر", "العجمي", "المنتزه", "محرم بك"],
  "القليوبية": ["بنها", "شبرا الخيمة", "قليوب"], "الشرقية": ["الزقازيق", "العاشر من رمضان", "بلبيس"],
  "الدقهلية": ["المنصورة", "ميت غمر", "طلخا"], "الغربية": ["طنطا", "المحلة الكبرى"],
  "المنوفية": ["شبين الكوم", "منوف"], "كفر الشيخ": ["كفر الشيخ", "دسوق"], "دمياط": ["دمياط", "رأس البر"],
  "بورسعيد": ["بورسعيد"], "الإسماعيلية": ["الإسماعيلية", "فايد"], "السويس": ["السويس"],
  "الفيوم": ["الفيوم", "سنورس"], "بني سويف": ["بني سويف"], "المنيا": ["المنيا", "ملوي"],
  "أسيوط": ["أسيوط"], "سوهاج": ["سوهاج"], "قنا": ["قنا", "نجع حمادي"], "الأقصر": ["الأقصر"],
  "أسوان": ["أسوان"], "البحر الأحمر": ["الغردقة"], "الوادي الجديد": ["الخارجة"],
  "مطروح": ["مرسى مطروح", "العلمين"], "شمال سيناء": ["العريش"], "جنوب سيناء": ["شرم الشيخ", "الطور"],
}

function Countdown({ endsAt }: { endsAt: string }) {
  const [now, setNow] = useState(Date.now())
  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1000)
    return () => clearInterval(timer)
  }, [])
  const seconds = Math.max(0, Math.floor((new Date(endsAt).getTime() - now) / 1000))
  return <Text style={styles.timer}>{Math.floor(seconds / 3600)}س {Math.floor(seconds % 3600 / 60)}د {String(seconds % 60).padStart(2, "0")}ث</Text>
}

function fulfillmentLabel(status: string) {
  return ({ not_started: "بانتظار تجهيز التاجر", preparing: "قيد التجهيز", shipped: "تم الشحن", in_transit: "في الطريق", ready_for_pickup: "جاهز للاستلام", delivered: "تم التوصيل", picked_up: "تم الاستلام" } as Record<string, string>)[status] ?? status
}

function orderStatusLabel(status: string) {
  return ({ pending_payment: "بانتظار الدفع", pending: "قيد المراجعة", confirmed: "مؤكد", active: "نشط", completed: "مكتمل", cancelled: "ملغي", canceled: "ملغي", failed: "لم يكتمل" } as Record<string, string>)[status] ?? status
}

function ticketStatusLabel(status: string) {
  return ({ open: "مفتوحة", in_progress: "قيد المتابعة", resolved: "تم الحل", closed: "مغلقة" } as Record<string, string>)[status] ?? status
}

function paymentLabel(status?: string) {
  if (!status) return "غير متاحة"
  if (status === "awaiting_transfer" || status === "pending" || status === "pending_payment") return "بانتظار التحويل"
  if (status === "submitted") return "الإيصال قيد المراجعة"
  if (status === "rejected") return "مطلوب إيصال جديد"
  if (["paid", "succeeded", "completed"].includes(status)) return "تم الدفع"
  if (["failed", "cancelled", "refunded"].includes(status)) return status === "refunded" ? "تم رد المبلغ" : "لم يكتمل الدفع"
  return status
}

function paymentMethodName(method?: string | null) {
  return method === "instapay" ? "إنستا باي" : method === "vodafone_cash" ? "فودافون كاش" : "تحويل يدوي"
}

function ProductArt({ imageUrl, emoji, compact = false }: { imageUrl?: string | null; emoji: string; compact?: boolean }) {
  const [failed, setFailed] = useState(false)
  useEffect(() => setFailed(false), [imageUrl])
  return <View style={[styles.art, compact && styles.highlightArt]}>
    {imageUrl && !failed ? <Image source={{ uri: imageUrl }} style={styles.artImage} resizeMode="cover" onError={() => setFailed(true)} /> : <Text style={styles.emoji}>{emoji || "🛍️"}</Text>}
  </View>
}

function socialError(error: unknown) {
  const code = error instanceof Error ? error.message : ""
  return ({
    identity_provider_not_configured: "لم تُضبط بيانات مزوّد الدخول على الخادم بعد.",
    identity_provider_unavailable: "تعذر التحقق من Google أو Apple الآن. حاول مرة أخرى.",
    invalid_identity_token: "لم نتمكن من تأكيد هوية الحساب. أعد المحاولة.",
    invalid_or_expired_nonce: "انتهت جلسة الدخول الآمنة. حاول مرة أخرى.",
    verified_email_required: "يحتاج الحساب إلى بريد إلكتروني مؤكّد.",
    buyer_registration_paused: "تسجيل المشترين متوقف مؤقتًا.",
    account_disabled: "هذا الحساب موقوف. تواصل مع الإدارة.",
    admin_social_login_must_be_linked: "حساب الإدارة يحتاج إلى تسجيل الدخول بالطريقة المعتمدة له.",
  } as Record<string, string>)[code] ?? "تحقق من الاتصال وإعدادات الدخول، ثم حاول مرة أخرى."
}

export default function App() {
  const [account, setAccount] = useState<Account | null>(null)
  const [authReady, setAuthReady] = useState(false)
  const [authMode, setAuthMode] = useState<"login" | "register">("login")
  const [fullName, setFullName] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [phone, setPhone] = useState("")
  const [governorate, setGovernorate] = useState("")
  const [city, setCity] = useState("")
  const [address, setAddress] = useState("")
  const [registrationCoordinates, setRegistrationCoordinates] = useState<{ latitude: number; longitude: number } | null>(null)
  const [locationBusy, setLocationBusy] = useState(false)
  const [showGovernorates, setShowGovernorates] = useState(false)
  const [authValidation, setAuthValidation] = useState("")
  const [whatsappOptIn, setWhatsappOptIn] = useState(false)
  const [whatsappPhone, setWhatsappPhone] = useState("")
  const [whatsappAllowed, setWhatsappAllowed] = useState(false)
  const [pushToken, setPushToken] = useState("")
  const [authBusy, setAuthBusy] = useState(false)
  const [googleNonce, setGoogleNonce] = useState("")
  const [appleAvailable, setAppleAvailable] = useState(false)
  const [socialAuthConfig, setSocialAuthConfig] = useState({ google: false, apple: false })
  const [googleRequest, , promptGoogle] = Google.useIdTokenAuthRequest({
    iosClientId: GOOGLE_IOS_CLIENT_ID || undefined,
    androidClientId: GOOGLE_ANDROID_CLIENT_ID || undefined,
    webClientId: GOOGLE_WEB_CLIENT_ID || undefined,
    extraParams: googleNonce ? { nonce: googleNonce } : {},
    scopes: ["openid", "profile", "email"],
  })
  const [selectedDeal, setSelectedDeal] = useState<Deal | CartItem | null>(null)
  const [joinQuantity, setJoinQuantity] = useState("1")
  const [fulfillmentMethod, setFulfillmentMethod] = useState<"merchant_shipping" | "self_pickup">("self_pickup")
  const [shippingAddress, setShippingAddress] = useState("")
  const [couponCode, setCouponCode] = useState("")
  const [loyaltyPointsToUse, setLoyaltyPointsToUse] = useState("")
  const [loyaltyPoints, setLoyaltyPoints] = useState(0)
  const [joinBusy, setJoinBusy] = useState(false)
  const [activeTab, setActiveTab] = useState<"deals" | "cart" | "orders" | "account">("deals")
  const [memberships, setMemberships] = useState<Membership[]>([])
  const [cartItems, setCartItems] = useState<CartItem[]>([])
  const [deals, setDeals] = useState<Deal[]>([])
  const [platformSettings, setPlatformSettings] = useState<PlatformSettings>({})
  const [paymentConfig, setPaymentConfig] = useState<PaymentConfig>({ configured: false, methods: [] })
  const [paymentMethod, setPaymentMethod] = useState<"vodafone_cash" | "instapay">("vodafone_cash")
  const [receiptOrder, setReceiptOrder] = useState<{ membershipId: string; amountMinor: number; paymentMethod: string; name: string } | null>(null)
  const [receiptDataUrl, setReceiptDataUrl] = useState("")
  const [transferReference, setTransferReference] = useState("")
  const [receiptBusy, setReceiptBusy] = useState(false)
  const [programName, setProgramName] = useState("نشتري سوا")
  const [highlights, setHighlights] = useState<DealHighlights>({ cheapest: [], bestSellers: [], trustedSellers: [] })
  const [categories, setCategories] = useState<Category[]>([])
  const [selectedCategory, setSelectedCategory] = useState("")
  const [loading, setLoading] = useState(true)
  const [locationMessage, setLocationMessage] = useState("بنحدد مكانك...")
  const [error, setError] = useState("")
  const [profilePhone, setProfilePhone] = useState("")
  const [profileGovernorate, setProfileGovernorate] = useState("")
  const [profileCity, setProfileCity] = useState("")
  const [profileAddress, setProfileAddress] = useState("")
  const [profileBusy, setProfileBusy] = useState(false)
  const [tickets, setTickets] = useState<SupportTicket[]>([])
  const [ticketSubject, setTicketSubject] = useState("")
  const [ticketMessage, setTicketMessage] = useState("")
  const [ticketBusy, setTicketBusy] = useState(false)
  const [selectedReview, setSelectedReview] = useState<Membership | null>(null)
  const [reviewRating, setReviewRating] = useState(5)
  const [reviewComment, setReviewComment] = useState("")
  const [reviewBusy, setReviewBusy] = useState(false)

  async function loadDeals() {
    setLoading(true)
    setError("")
    try {
      const permission = await Location.requestForegroundPermissionsAsync()
      if (permission.status !== "granted") throw new Error("اسمحلنا بالموقع عشان نجيبلك صفقات قريبة.")
      const position = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced })
      setLocationMessage("صفقات قريبة منك · في نطاق ٢ كم")
      const [nearby, featured] = await Promise.all([
        getNearbyDeals(position.coords.latitude, position.coords.longitude),
        getDealHighlights(position.coords.latitude, position.coords.longitude).catch(() => ({ cheapest: [], bestSellers: [], trustedSellers: [] })),
      ])
      setDeals(nearby)
      setHighlights(featured)
    } catch (err) {
      setError(err instanceof Error ? err.message : "حصلت مشكلة وإحنا بنجيب الصفقات.")
    } finally {
      setLoading(false)
    }
  }

  async function loadCategories() {
    try {
      setCategories(await getCategories())
    } catch {
      setCategories([])
    }
  }

  async function restoreSession() {
    try {
      const [config, saved] = await Promise.all([getPublicConfig().catch(() => null), getSavedAccount()])
      if (config) {
        setPlatformSettings(config.settings ?? {})
        setPaymentConfig(config.payment ?? { configured: false, methods: [] })
        setSocialAuthConfig({ google: config.authProviders?.google?.enabled === true, apple: config.authProviders?.apple?.enabled === true })
        const branding = config.programProfile?.branding
        const name = branding?.displayName ?? branding?.appName ?? branding?.name ?? config.programProfile?.displayName ?? config.programProfile?.brandName ?? config.programProfile?.name
        if (typeof name === "string" && name.trim()) setProgramName(name.trim())
      }
      if (saved?.role === "buyer") setAccount(saved)
    } catch {
      setError("تعذر الاتصال بالخادم. احتفظنا ببيانات الدخول؛ حاول مرة أخرى.")
    } finally {
      setAuthReady(true)
    }
  }

  useEffect(() => { void restoreSession() }, [])
  useEffect(() => {
    if (!account) return
    setWhatsappPhone(account.phone ?? "")
    setWhatsappAllowed(account.whatsappOptIn === true)
    setProfilePhone(account.phone ?? "")
    setProfileGovernorate(account.governorate ?? "")
    setProfileCity(account.city ?? "")
    setProfileAddress(account.address ?? "")
    void loadDeals()
    void loadCategories()
    void loadMemberships()
    void loadCart()
    void loadLoyalty()
    void enablePushNotifications().catch(() => {})
  }, [account?.id])
  useEffect(() => {
    let active = true
    if (GOOGLE_IOS_CLIENT_ID || GOOGLE_ANDROID_CLIENT_ID || GOOGLE_WEB_CLIENT_ID) {
      void createOAuthNonce("google").then((nonce) => { if (active) setGoogleNonce(nonce) }).catch(() => {})
    }
    void AppleAuthentication.isAvailableAsync().then((available) => { if (active) setAppleAvailable(available) }).catch(() => {})
    return () => { active = false }
  }, [])

  async function loadMemberships() {
    try {
      setMemberships(await getBuyerMemberships())
    } catch (err) {
      setError(err instanceof Error ? err.message : "تعذر تحميل انضماماتك.")
    }
  }

  async function loadCart() {
    try {
      setCartItems(await getBuyerCart())
    } catch {
      setCartItems([])
    }
  }

  async function loadLoyalty() {
    try {
      const loyalty = await getBuyerLoyalty()
      setLoyaltyPoints(loyalty.points)
    } catch {
      setLoyaltyPoints(0)
    }
  }

  async function loadSupportTickets() {
    try {
      setTickets(await getSupportTickets())
    } catch (err) {
      Alert.alert("تعذر تحميل تذاكر الدعم", err instanceof Error ? err.message : "حاول مرة أخرى.")
    }
  }

  async function enablePushNotifications() {
    if (!Device.isDevice) return
    let permission = await Notifications.getPermissionsAsync()
    if (permission.status !== "granted") permission = await Notifications.requestPermissionsAsync()
    if (permission.status !== "granted") return
    if (Platform.OS === "android") {
      await Notifications.setNotificationChannelAsync("default", {
        name: "إشعارات نشتري سوا",
        importance: Notifications.AndroidImportance.MAX,
      })
    }
    const easProjectId = process.env.EXPO_PUBLIC_EAS_PROJECT_ID ||
      (Constants as unknown as { easConfig?: { projectId?: string } }).easConfig?.projectId ||
      (Constants.expoConfig?.extra as { eas?: { projectId?: string } } | undefined)?.eas?.projectId
    if (!easProjectId) return
    const token = (await Notifications.getExpoPushTokenAsync({ projectId: easProjectId })).data
    await registerPushDevice(token, Platform.OS === "ios" ? "ios" : "android")
    setPushToken(token)
  }

  async function addDealToCart(deal: Deal) {
    try {
      const current = cartItems.find((item) => item.dealId === deal.id)?.quantity ?? 0
      await saveCartItem(deal.id, current + 1)
      await loadCart()
      Alert.alert("اتضاف للسلة", `${deal.name} · الكمية ${current + 1}`)
    } catch (err) {
      Alert.alert("تعذر الإضافة للسلة", err instanceof Error ? err.message : "حاول مرة أخرى.")
    }
  }

  async function saveWhatsAppPreferences() {
    try {
      await updateWhatsAppConsent(whatsappPhone.trim(), whatsappAllowed)
      setAccount((current) => current ? { ...current, phone: whatsappPhone.trim(), whatsappOptIn: whatsappAllowed } : current)
      setProfilePhone(whatsappPhone.trim())
      Alert.alert("تم حفظ التفضيل", whatsappAllowed ? "سنستخدم رقمك لإشعارات واتساب التي وافقت عليها." : "تم إيقاف إشعارات واتساب.")
    } catch (err) {
      Alert.alert("تعذر حفظ التفضيل", err instanceof Error ? err.message : "تحقق من رقم الهاتف.")
    }
  }

  async function saveProfile() {
    if (!profilePhone.trim() || !profileGovernorate || !profileCity.trim() || profileAddress.trim().length < 6) {
      Alert.alert("أكمل بياناتك", "رقم الهاتف والمحافظة والمدينة والعنوان الواضح مطلوبة.")
      return
    }
    setProfileBusy(true)
    try {
      await updateBuyerProfile({
        phone: profilePhone.trim(),
        governorate: profileGovernorate,
        city: profileCity.trim(),
        address: profileAddress.trim(),
        latitude: account?.latitude ?? null,
        longitude: account?.longitude ?? null,
      })
      setAccount((current) => current ? { ...current, phone: profilePhone.trim(), governorate: profileGovernorate, city: profileCity.trim(), address: profileAddress.trim() } : current)
      Alert.alert("تم تحديث الحساب", "حُفظت بيانات التواصل والعنوان.")
    } catch (err) {
      Alert.alert("تعذر حفظ بياناتك", err instanceof Error ? err.message : "حاول مرة أخرى.")
    } finally {
      setProfileBusy(false)
    }
  }

  async function sendSupportTicket() {
    if (ticketSubject.trim().length < 3 || ticketMessage.trim().length < 8) {
      Alert.alert("أكمل رسالة الدعم", "اكتب عنوانًا من 3 أحرف ورسالة من 8 أحرف على الأقل.")
      return
    }
    setTicketBusy(true)
    try {
      await createSupportTicket(ticketSubject.trim(), ticketMessage.trim())
      setTicketSubject("")
      setTicketMessage("")
      await loadSupportTickets()
      Alert.alert("وصلت رسالتك", "أُضيفت تذكرة الدعم إلى سجل حسابك.")
    } catch (err) {
      Alert.alert("تعذر إرسال الرسالة", err instanceof Error ? err.message : "حاول مرة أخرى.")
    } finally {
      setTicketBusy(false)
    }
  }

  async function sendReview() {
    if (!selectedReview) return
    setReviewBusy(true)
    try {
      await submitBuyerReview(selectedReview.membershipId, reviewRating, reviewComment.trim())
      setSelectedReview(null)
      setReviewComment("")
      await loadMemberships()
      Alert.alert("شكرًا لتقييمك", "ساعد تقييمك المشترين الآخرين.")
    } catch (err) {
      Alert.alert("تعذر إرسال التقييم", err instanceof Error ? err.message : "حاول مرة أخرى.")
    } finally {
      setReviewBusy(false)
    }
  }

  async function captureRegistrationLocation() {
    setLocationBusy(true)
    setAuthValidation("")
    try {
      const permission = await Location.requestForegroundPermissionsAsync()
      if (permission.status !== "granted") throw new Error("اسمح باستخدام الموقع أو أكمل التسجيل بدونه.")
      const position = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced })
      setRegistrationCoordinates({ latitude: position.coords.latitude, longitude: position.coords.longitude })
    } catch (err) {
      setAuthValidation(err instanceof Error ? err.message : "تعذر تحديد موقعك. يمكنك إكمال التسجيل بدونه.")
    } finally {
      setLocationBusy(false)
    }
  }

  async function submitAuth() {
    if (authMode === "register" && platformSettings.buyer_registration_enabled === false) {
      Alert.alert("التسجيل متوقف مؤقتًا", "أوقف المسؤول إنشاء حسابات جديدة مؤقتًا.")
      return
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      setAuthValidation("أدخل بريدًا إلكترونيًا صحيحًا.")
      return
    }
    if (!password || (authMode === "register" && password.length < 12)) {
      setAuthValidation(authMode === "register" ? "كلمة المرور يجب أن تكون 12 حرفًا على الأقل." : "أدخل كلمة المرور.")
      return
    }
    if (authMode === "register" && !fullName.trim()) {
      setAuthValidation("اكتب الاسم بالكامل.")
      return
    }
    if (authMode === "register" && (phone.replace(/\D/g, "").length < 10 || phone.replace(/\D/g, "").length > 15)) {
      setAuthValidation("أدخل رقم هاتف صحيحًا من 10 إلى 15 رقمًا.")
      return
    }
    if (authMode === "register" && (!governorate || !city.trim() || address.trim().length < 6)) {
      setAuthValidation("اختر المحافظة، واكتب المدينة وعنوانًا واضحًا لا يقل عن 6 أحرف.")
      return
    }
    setAuthValidation("")
    setAuthBusy(true)
    try {
      const user = authMode === "register"
        ? await registerBuyer(fullName.trim(), email.trim().toLowerCase(), password, phone.trim(), whatsappOptIn, {
          governorate,
          city: city.trim(),
          address: address.trim(),
          latitude: registrationCoordinates?.latitude ?? null,
          longitude: registrationCoordinates?.longitude ?? null,
        })
        : await loginAccount(email.trim().toLowerCase(), password)
      if (user.role !== "buyer") {
        await logoutAccount()
        Alert.alert("حساب غير مخصص للمشتري", "استخدم لوحة الويب لإدارة حساب البائع أو الإدارة.")
        return
      }
      setAccount(user)
      setPassword("")
      setPhone("")
      setWhatsappOptIn(false)
      setError("")
    } catch (err) {
      const status = (err as Error & { status?: number }).status
      const message = status === 404
        ? "تسجيل الدخول يحتاج نشر تحديث الخادم أولًا. لم يتم إنشاء الحساب."
        : err instanceof Error && err.message === "invalid_credentials"
          ? "البريد أو كلمة المرور غير صحيحين."
        : err instanceof Error && err.message === "email_already_registered"
            ? "هذا البريد مسجل بالفعل. سجّل الدخول بدلًا من إنشاء حساب جديد."
        : err instanceof Error && err.message === "buyer_registration_paused"
              ? "تسجيل المشترين متوقف مؤقتًا."
              : err instanceof Error && err.message === "valid_phone_required_for_whatsapp"
                ? "أدخل رقمًا دوليًا صحيحًا قبل الموافقة على رسائل واتساب."
            : err instanceof Error && err.message.includes("password_must_be")
              ? "كلمة المرور يجب أن تكون 12 حرفًا على الأقل."
              : "تعذر إكمال الطلب. تحقق من الاتصال وحاول مرة أخرى."
      setAuthValidation(message)
    } finally {
      setAuthBusy(false)
    }
  }

  async function acceptSocialAccount(user: Account) {
    if (user.role !== "buyer") {
      await logoutAccount()
      Alert.alert("حساب غير مخصص للمشتري", "استخدم لوحة الويب لإدارة حساب البائع أو الإدارة.")
      return
    }
    setAccount(user)
    setPassword("")
    setError("")
  }

  async function signInWithGoogle() {
    if (authBusy) return
    if (!googleRequest || !googleNonce) {
      Alert.alert("Google غير جاهز", "تحقق من إعداد معرّف Google في إعدادات التطبيق والخادم.")
      return
    }
    setAuthBusy(true)
    try {
      const result = await promptGoogle()
      if (result.type === "success") {
        const idToken = result.params.id_token
        if (!idToken) throw new Error("identity_token_missing")
        await acceptSocialAccount(await loginWithSocial("google", idToken, googleNonce))
      }
    } catch (err) {
      Alert.alert("تعذر الدخول بـ Google", socialError(err))
    } finally {
      try { setGoogleNonce(await createOAuthNonce("google")) } catch { setGoogleNonce("") }
      setAuthBusy(false)
    }
  }

  async function signInWithApple() {
    if (authBusy) return
    setAuthBusy(true)
    try {
      const nonce = await createOAuthNonce("apple")
      const appleNonce = await Crypto.digestStringAsync(Crypto.CryptoDigestAlgorithm.SHA256, nonce)
      const credential = await AppleAuthentication.signInAsync({
        requestedScopes: [AppleAuthentication.AppleAuthenticationScope.FULL_NAME, AppleAuthentication.AppleAuthenticationScope.EMAIL],
        nonce: appleNonce,
      })
      if (!credential.identityToken) throw new Error("identity_token_missing")
      const name = [credential.fullName?.givenName, credential.fullName?.familyName].filter(Boolean).join(" ")
      await acceptSocialAccount(await loginWithSocial("apple", credential.identityToken, nonce, name))
    } catch (err) {
      if ((err as Error & { code?: string }).code !== "ERR_REQUEST_CANCELED") Alert.alert("تعذر الدخول بـ Apple", socialError(err))
    } finally {
      setAuthBusy(false)
    }
  }

  async function signOut() {
    if (pushToken) await unregisterPushDevice(pushToken).catch(() => {})
    await logoutAccount()
    setAccount(null)
    setDeals([])
    setError("")
    setMemberships([])
    setCartItems([])
    setPushToken("")
    setLoyaltyPoints(0)
    setHighlights({ cheapest: [], bestSellers: [], trustedSellers: [] })
    setSelectedCategory("")
    setActiveTab("deals")
  }

  const paymentReady = paymentConfig.configured && paymentConfig.methods.length > 0
  const visibleDeals = selectedCategory
    ? deals.filter((deal) => deal.category === selectedCategory || categories.find((category) => category.id === selectedCategory)?.name === deal.category)
    : deals

  function renderHighlightSection(title: string, emptyText: string, items: Deal[]) {
    return <View style={styles.highlightSection}>
      <View style={styles.highlightHeading}><Text style={styles.highlightCount}>{items.length ? `${Math.min(items.length, 5)} عروض` : ""}</Text><Text style={styles.highlightTitle}>{title}</Text></View>
      {items.length ? <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.highlightRow}>
        {items.slice(0, 5).map((item) => <TouchableOpacity key={item.id} style={styles.highlightCard} onPress={() => join(item)}>
          <View style={styles.highlightProduct}><ProductArt compact imageUrl={item.imageUrl} emoji={item.emoji} /><View style={styles.highlightInfo}><Text style={styles.highlightName} numberOfLines={1}>{item.name}</Text><Text style={styles.highlightPrice}>{item.price.toFixed(2)} جنيه / {item.unit}</Text><Text style={styles.highlightSeller} numberOfLines={1}>{item.sellerName || item.category}{item.sellerVerified ? " · موثّق" : ""}{item.sellerRating ? ` · ★ ${item.sellerRating.toFixed(1)}` : ""}</Text></View></View>
        </TouchableOpacity>)}
      </ScrollView> : <Text style={styles.highlightEmpty}>{emptyText}</Text>}
    </View>
  }

  function join(deal: Deal | CartItem, quantity = 1) {
    if (platformSettings.orders_enabled === false) {
      Alert.alert("الطلبات متوقفة مؤقتًا", "أوقف المسؤول استقبال الطلبات مؤقتًا.")
      return
    }
    const canPickup = deal.acceptsPickup && platformSettings.self_pickup_enabled !== false
    const canShip = deal.acceptsShipping && platformSettings.merchant_shipping_enabled !== false
    if (!canPickup && !canShip) {
      Alert.alert("التسليم غير متاح", "طرق التسليم لهذا العرض متوقفة حاليًا.")
      return
    }
    setJoinQuantity(String(quantity))
    setFulfillmentMethod(canPickup ? "self_pickup" : "merchant_shipping")
    setShippingAddress("")
    setCouponCode("")
    setLoyaltyPointsToUse("")
    setSelectedDeal(deal)
  }

  async function confirmJoin() {
    const deal = selectedDeal
    if (!paymentConfig.configured || paymentConfig.methods.length === 0) {
      Alert.alert("الحجز غير متاح الآن", "لم يربط صاحب المنصة مزوّد دفع حقيقيًا بعد. لم يتم إنشاء طلب أو حجز كمية.")
      return
    }
    const quantity = Number(joinQuantity)
    const maximum = deal?.availableQuantity ?? (deal?.maxQuantity == null ? 1_000_000 : deal.maxQuantity - deal.committedQuantity)
    if (!deal || !Number.isSafeInteger(quantity) || quantity < 1 || quantity > maximum) {
      Alert.alert("راجع الكمية", `أدخل كمية من 1 إلى ${Math.max(0, maximum)}.`)
      return
    }
    if (fulfillmentMethod === "merchant_shipping" && (!deal.acceptsShipping || platformSettings.merchant_shipping_enabled === false || shippingAddress.trim().length < 8)) {
      Alert.alert("أكمل عنوان التوصيل", "أدخل عنوانًا واضحًا لا يقل عن 8 أحرف.")
      return
    }
    if (fulfillmentMethod === "self_pickup" && (!deal.acceptsPickup || platformSettings.self_pickup_enabled === false)) {
      Alert.alert("الاستلام غير متاح", "اختر الشحن من التاجر لهذا العرض.")
      return
    }
    setJoinBusy(true)
    try {
      const points = Number(loyaltyPointsToUse || 0)
      if (!Number.isSafeInteger(points) || points < 0 || points > loyaltyPoints) {
        Alert.alert("راجع النقاط", `رصيدك المتاح ${loyaltyPoints} نقطة.`)
        return
      }
      const result = await requestToJoin(deal.id, quantity, paymentMethod, fulfillmentMethod, shippingAddress.trim(), couponCode.trim(), points)
      setReceiptOrder({ membershipId: result.membershipId, amountMinor: result.amountMinor, paymentMethod, name: deal.name })
      setReceiptDataUrl("")
      setTransferReference("")
      await loadMemberships()
      await loadLoyalty()
      await deleteCartItem(deal.id).catch(() => {})
      await loadCart()
      setJoinBusy(false)
    } catch (err) {
      const message = err instanceof Error ? err.message : "جرّب تاني كمان شوية."
      Alert.alert("محتاجين نكمّل خطوة", message)
    } finally {
      setJoinBusy(false)
    }
  }

  async function pickPaymentReceipt() {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync()
    if (!permission.granted) {
      Alert.alert("إذن الصور مطلوب", "اسمح بالوصول للصور لاختيار لقطة إيصال التحويل.")
      return
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      quality: 0.65,
      base64: true,
    })
    const asset = result.canceled ? null : result.assets[0]
    if (!asset?.base64) return
    const mimeType = asset.mimeType === "image/png" || asset.mimeType === "image/webp" ? asset.mimeType : "image/jpeg"
    setReceiptDataUrl(`data:${mimeType};base64,${asset.base64}`)
  }

  async function sendPaymentReceipt() {
    if (!receiptOrder || !receiptDataUrl) {
      Alert.alert("أرفق الإيصال أولًا", "اختر صورة واضحة لتحويلك من معرض الصور.")
      return
    }
    setReceiptBusy(true)
    try {
      await submitPaymentReceipt(receiptOrder.membershipId, receiptDataUrl, transferReference)
      await loadMemberships()
      setReceiptOrder(null)
      setSelectedDeal(null)
      setReceiptDataUrl("")
      setTransferReference("")
      Alert.alert("وصل الإيصال", "حالة الطلب الآن قيد مراجعة الإدارة. لن نؤكد الدفع أو نرسل الطلب للبائع قبل الاعتماد.")
    } catch (err) {
      Alert.alert("تعذر إرسال الإيصال", err instanceof Error ? err.message : "تحقق من الصورة وحاول مرة أخرى.")
    } finally {
      setReceiptBusy(false)
    }
  }

  function resumePaymentReceipt(item: Membership) {
    setPaymentMethod(item.paymentMethod === "instapay" ? "instapay" : "vodafone_cash")
    setReceiptOrder({ membershipId: item.membershipId, amountMinor: Math.round(item.total * 100), paymentMethod: item.paymentMethod ?? "vodafone_cash", name: item.name })
    setReceiptDataUrl("")
    setTransferReference("")
  }

  async function cancelOrder(item: Membership) {
    try {
      await cancelMembership(item.membershipId)
      await loadMemberships()
      Alert.alert("تم الإلغاء", "أُلغي انضمامك للمجموعة.")
    } catch (err) {
      Alert.alert("تعذر الإلغاء", err instanceof Error ? err.message : "حاول مرة أخرى.")
    }
  }

  function share(deal: Deal) {
    const message = `يلا نشتري سوا ${deal.name} بسعر ${deal.price.toFixed(2)} جنيه! فاضل ${Math.max(0, deal.moq - deal.committedQuantity)} وحدة ونوصل لسعر الجملة.`
    void Linking.openURL(`https://wa.me/?text=${encodeURIComponent(message)}`)
  }

  if (!authReady) return <SafeAreaView style={styles.safe}><View style={styles.center}><ActivityIndicator color={ORANGE} size="large" /><Text style={styles.emptyText}>بنتأكد من حسابك...</Text></View></SafeAreaView>

  if (!account) return (
    <SafeAreaView style={styles.authSafe}>
      <StatusBar barStyle="dark-content" backgroundColor="#F5F5F5" />
      <ScrollView contentContainerStyle={styles.authContent} keyboardShouldPersistTaps="handled">
        <View style={styles.authBrand}><Text style={styles.brandMark}>↗</Text><Text style={styles.authBrandText}>{programName}</Text></View>
        <Text style={styles.authEyebrow}>سوق جماعي من قلب الحي</Text>
        <Text style={styles.authTitle}>{authMode === "register" ? "حسابك يبدأ من هنا" : "أهلاً بيك"}</Text>
        <Text style={styles.authIntro}>سجّل الدخول لعرض الصفقات القريبة وأفضل البائعين. التسجيل متاح للمشترين فقط.</Text>
        {authMode === "register" && <TextInput value={fullName} onChangeText={setFullName} style={styles.authInput} placeholder="الاسم بالكامل" placeholderTextColor="#849088" autoComplete="name" textAlign="right" />}
        {authMode === "register" && <TextInput value={phone} onChangeText={setPhone} style={styles.authInput} placeholder="رقم الهاتف" placeholderTextColor="#849088" keyboardType="phone-pad" autoComplete="tel" textAlign="right" />}
        {authMode === "register" && <>
          <TouchableOpacity onPress={() => setShowGovernorates((open) => !open)} style={styles.selectField}><Text style={styles.selectFieldText}>{governorate || "اختر المحافظة"}</Text><Text style={styles.selectHint}>المحافظة</Text></TouchableOpacity>
          {showGovernorates && <ScrollView style={styles.optionPicker} nestedScrollEnabled><View style={styles.choiceWrap}>{GOVERNORATES.map((name) => <TouchableOpacity key={name} onPress={() => { setGovernorate(name); setCity(""); setShowGovernorates(false) }} style={[styles.choiceChip, governorate === name && styles.choiceChipActive]}><Text style={[styles.choiceChipText, governorate === name && styles.choiceChipTextActive]}>{name}</Text></TouchableOpacity>)}</View></ScrollView>}
          <TextInput editable={Boolean(governorate)} value={city} onChangeText={setCity} style={styles.authInput} placeholder={governorate ? `المدينة في ${governorate}` : "اختر المحافظة أولًا ثم اكتب المدينة"} placeholderTextColor="#849088" textAlign="right" />
          {governorate && <View style={styles.choiceWrap}>{(CITIES[governorate] ?? []).map((name) => <TouchableOpacity key={name} onPress={() => setCity(name)} style={[styles.choiceChip, city === name && styles.choiceChipActive]}><Text style={[styles.choiceChipText, city === name && styles.choiceChipTextActive]}>{name}</Text></TouchableOpacity>)}</View>}
          <TextInput value={address} onChangeText={setAddress} style={[styles.authInput, styles.addressInput]} placeholder="العنوان بالتفصيل: المنطقة والشارع وعلامة مميزة" placeholderTextColor="#849088" multiline textAlign="right" />
          <TouchableOpacity disabled={locationBusy} onPress={() => void captureRegistrationLocation()} style={styles.locationButton}>{locationBusy ? <ActivityIndicator color={GREEN} /> : <Text style={styles.locationButtonText}>{registrationCoordinates ? "تم تحديد موقعك ✓" : "إضافة موقعي الحالي (اختياري)"}</Text>}</TouchableOpacity>
          <View style={styles.consentRow}><Text style={styles.consentText}>أوافق على رسائل واتساب عن حسابي وطلباتي وعروض جديدة.</Text><Switch value={whatsappOptIn} onValueChange={setWhatsappOptIn} trackColor={{ true: GREEN }} /></View>
        </>}
        <TextInput value={email} onChangeText={setEmail} style={styles.authInput} placeholder="البريد الإلكتروني" placeholderTextColor="#849088" keyboardType="email-address" autoCapitalize="none" autoComplete="email" textAlign="right" />
        <TextInput value={password} onChangeText={setPassword} style={styles.authInput} placeholder="كلمة المرور (12 حرفًا على الأقل)" placeholderTextColor="#849088" secureTextEntry autoComplete={authMode === "register" ? "new-password" : "current-password"} textAlign="right" />
        {authValidation ? <Text style={styles.validationText}>{authValidation}</Text> : null}
        <TouchableOpacity disabled={authBusy || (authMode === "register" && platformSettings.buyer_registration_enabled === false)} onPress={() => void submitAuth()} style={[styles.authButton, (authBusy || (authMode === "register" && platformSettings.buyer_registration_enabled === false)) && styles.disabledButton]}>
          {authBusy ? <ActivityIndicator color="white" /> : <Text style={styles.authButtonText}>{authMode === "register" ? "إنشاء حساب مشتري" : "تسجيل الدخول"}</Text>}
        </TouchableOpacity>
        {authMode === "login" && socialAuthConfig.google && (GOOGLE_IOS_CLIENT_ID || GOOGLE_ANDROID_CLIENT_ID || GOOGLE_WEB_CLIENT_ID) && <TouchableOpacity disabled={authBusy || !googleRequest || !googleNonce} onPress={() => void signInWithGoogle()} style={[styles.googleButton, (authBusy || !googleRequest || !googleNonce) && styles.disabledButton]}><Text style={styles.googleMark}>G</Text><Text style={styles.googleButtonText}>متابعة باستخدام Google</Text></TouchableOpacity>}
        {authMode === "login" && socialAuthConfig.apple && Platform.OS === "ios" && appleAvailable && <AppleAuthentication.AppleAuthenticationButton buttonType={AppleAuthentication.AppleAuthenticationButtonType.SIGN_IN} buttonStyle={AppleAuthentication.AppleAuthenticationButtonStyle.BLACK} cornerRadius={12} style={styles.appleButton} onPress={() => void signInWithApple()} />}
        <TouchableOpacity onPress={() => { setAuthMode(authMode === "register" ? "login" : "register"); setAuthValidation(""); setShowGovernorates(false) }} style={styles.authToggle}>
          <Text style={styles.authToggleText}>{authMode === "register" ? "لديك حساب؟ سجّل الدخول" : "مستخدم جديد؟ أنشئ حسابًا"}</Text>
        </TouchableOpacity>
        <Text style={styles.authNote}>تظهر خيارات Google وApple بعد تفعيلها في إعدادات التطبيق والخادم. كلمة المرور لا تُحفظ في التطبيق.</Text>
      </ScrollView>
    </SafeAreaView>
  )

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="dark-content" backgroundColor="#F5F5F5" />
        <View style={styles.header}>
        <View><Text style={styles.greeting}>أهلاً {account.name.split(" ")[0]} 👋</Text><Text style={styles.location}>{locationMessage}</Text></View>
        <View style={styles.brand}><Text style={styles.brandMark}>↗</Text></View>
      </View>
      <View style={styles.titleRow}><View><Text style={styles.title}>{programName}</Text><Text style={styles.subtitle}>كل ما العدد يكمل، التوفير يزيد 🤝</Text></View><TouchableOpacity onPress={() => void signOut()}><Text style={styles.logout}>خروج</Text></TouchableOpacity></View>
      {error ? <View style={styles.center}><Text style={styles.emptyIcon}>📍</Text><Text style={styles.emptyTitle}>مش قادرين نجيب البيانات</Text><Text style={styles.emptyText}>{error}</Text><TouchableOpacity onPress={() => { setError(""); void loadDeals(); void loadMemberships() }} style={styles.retry}><Text style={styles.joinText}>جرّب تاني</Text></TouchableOpacity></View> : activeTab === "deals" && loading ? <View style={styles.center}><ActivityIndicator color={ORANGE} size="large" /><Text style={styles.emptyText}>بنلفّ على صفقات قريبة منك...</Text></View> : activeTab === "deals" ? (
        <FlatList
          data={visibleDeals}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.list}
          refreshing={loading}
          onRefresh={() => void loadDeals()}
          ListHeaderComponent={<View>
            {renderHighlightSection("أقل الأسعار", "لسه مفيش عروض مميزة قريبة.", highlights.cheapest)}
            {renderHighlightSection("الأكثر مبيعًا", "العروض الأكثر طلبًا هتظهر هنا.", highlights.bestSellers)}
            {renderHighlightSection("بائعون موثوقون", "لسه مفيش بائعين موثوقين في النطاق.", highlights.trustedSellers)}
            <View style={styles.categoryHeader}><Text style={styles.sectionLabel}>تصفح حسب الفئة</Text><ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.categoryRow}>
              <TouchableOpacity onPress={() => setSelectedCategory("")} style={[styles.choiceChip, !selectedCategory && styles.choiceChipActive]}><Text style={[styles.choiceChipText, !selectedCategory && styles.choiceChipTextActive]}>الكل</Text></TouchableOpacity>
              {categories.map((category) => <TouchableOpacity key={category.id} onPress={() => setSelectedCategory(category.id)} style={[styles.choiceChip, selectedCategory === category.id && styles.choiceChipActive]}><Text style={[styles.choiceChipText, selectedCategory === category.id && styles.choiceChipTextActive]}>{category.emoji ? `${category.emoji} ` : ""}{category.name}</Text></TouchableOpacity>)}
            </ScrollView></View>
            <Text style={styles.sectionLabel}>صفقات قريبة منك</Text>
          </View>}
          ListEmptyComponent={<View style={styles.center}><Text style={styles.emptyIcon}>🧭</Text><Text style={styles.emptyTitle}>{selectedCategory ? "مفيش صفقات في الفئة دي" : "مفيش صفقات جنبك دلوقتي"}</Text><Text style={styles.emptyText}>{selectedCategory ? "جرّب فئة تانية أو اعرض كل الصفقات." : "هنعرضلك الجديد أول ما يفتح في منطقتك."}</Text></View>}
          renderItem={({ item }) => {
            const progress = Math.min(100, Math.round(item.committedQuantity / item.moq * 100))
            const savings = Math.max(0, Math.round((1 - item.price / item.retailPrice) * 100))
            return <View style={styles.card}>
              <View style={styles.productRow}>
                <ProductArt imageUrl={item.imageUrl} emoji={item.emoji} />
                <View style={styles.productInfo}><Text style={styles.category}>{categories.find((category) => category.id === item.category)?.name ?? item.category} · {item.distanceKm.toFixed(1)} كم</Text><Text style={styles.name}>{item.name}</Text><Text style={styles.pickup}>📍 استلام من نقطة قريبة</Text>{item.sellerName ? <Text style={styles.pickup}>{item.sellerName}{item.sellerVerified ? " · بائع موثّق" : ""}{item.sellerRating ? ` · ★ ${item.sellerRating.toFixed(1)} (${item.reviewCount ?? 0})` : ""}</Text> : null}</View>
                <Text style={styles.discount}>وفر {savings}٪</Text>
              </View>
              <View style={styles.priceRow}><Text style={styles.price}>{item.price.toFixed(2)} <Text style={styles.currency}>جنيه / {item.unit}</Text></Text><Text style={styles.oldPrice}>{item.retailPrice.toFixed(2)} جنيه</Text></View>
              <View style={styles.progressLabels}><Text style={styles.progressCount}>{item.committedQuantity} من {item.moq} وحدة</Text><Text style={styles.progressHint}>لسعر الجملة</Text></View>
              <View style={styles.track}><View style={[styles.fill, { width: `${progress}%` }]} /></View>
              <View style={styles.availabilityRow}><Text style={styles.availability}>المتاح من التاجر: {item.availableQuantity} {item.unit}</Text><Text style={styles.availability}>{[item.acceptsShipping && platformSettings.merchant_shipping_enabled !== false && "شحن", item.acceptsPickup && platformSettings.self_pickup_enabled !== false && "استلام ذاتي"].filter(Boolean).join(" · ")}</Text></View>
              <View style={styles.footer}><View><Text style={styles.timerLabel}>العرض هيخلص كمان</Text><Countdown endsAt={item.endsAt} /></View><View style={styles.actions}><TouchableOpacity style={styles.shareButton} onPress={() => share(item)}><Text style={styles.shareText}>شارك</Text></TouchableOpacity><TouchableOpacity disabled={item.availableQuantity < 1 || platformSettings.orders_enabled === false} style={[styles.cartButton, (item.availableQuantity < 1 || platformSettings.orders_enabled === false) && styles.disabledButton]} onPress={() => void addDealToCart(item)}><Text style={styles.cartButtonText}>+ للسلة</Text></TouchableOpacity><TouchableOpacity disabled={item.availableQuantity < 1 || platformSettings.orders_enabled === false || (!(item.acceptsShipping && platformSettings.merchant_shipping_enabled !== false) && !(item.acceptsPickup && platformSettings.self_pickup_enabled !== false))} style={[styles.joinButton, (item.availableQuantity < 1 || platformSettings.orders_enabled === false) && styles.disabledButton]} onPress={() => void join(item)}><Text style={styles.joinText}>{platformSettings.orders_enabled === false ? "الطلبات متوقفة" : item.availableQuantity < 1 ? "نفدت الكمية" : "اطلب"}</Text></TouchableOpacity></View></View>
            </View>
          }}
        />
      ) : activeTab === "cart" ? (
        <FlatList
          data={cartItems}
          keyExtractor={(item) => item.dealId}
          contentContainerStyle={styles.list}
          onRefresh={() => void loadCart()}
          refreshing={false}
          ListHeaderComponent={<Text style={styles.ordersTitle}>اختياراتك قبل تأكيد الطلب</Text>}
          ListEmptyComponent={<View style={styles.center}><Text style={styles.emptyIcon}>🛒</Text><Text style={styles.emptyTitle}>السلة فاضية</Text><Text style={styles.emptyText}>أضف منتجًا من الصفقات القريبة وسيظهر هنا.</Text></View>}
          renderItem={({ item }) => <View style={styles.card}><View style={styles.productRow}><ProductArt imageUrl={item.imageUrl} emoji={item.emoji} /><View style={styles.productInfo}><Text style={styles.name}>{item.name}</Text><Text style={styles.category}>{item.quantity} {item.unit} · {item.price.toFixed(2)} جنيه للوحدة</Text><Text style={styles.pickup}>المتاح الآن: {item.availableQuantity} · {item.status === "active" ? "العرض متاح" : "العرض غير متاح"}</Text></View></View><View style={styles.priceRow}><Text style={styles.progressCount}>إجمالي تقريبي {(item.price * item.quantity).toFixed(2)} جنيه</Text><View style={styles.actions}><TouchableOpacity disabled={item.status !== "active" || item.availableQuantity < item.quantity} style={[styles.joinButton, (item.status !== "active" || item.availableQuantity < item.quantity) && styles.disabledButton]} onPress={() => join(item, item.quantity)}><Text style={styles.joinText}>عرض تفاصيل الطلب</Text></TouchableOpacity><TouchableOpacity style={styles.cancelButton} onPress={() => void deleteCartItem(item.dealId).then(loadCart)}><Text style={styles.cancelText}>حذف</Text></TouchableOpacity></View></View></View>}
        />
      ) : activeTab === "orders" ? (
        <FlatList
          data={memberships}
          keyExtractor={(item) => item.membershipId}
          contentContainerStyle={styles.list}
          onRefresh={() => void loadMemberships()}
          refreshing={false}
          ListHeaderComponent={<Text style={styles.ordersTitle}>مجموعاتي المحفوظة على حسابك</Text>}
          ListEmptyComponent={<View style={styles.center}><Text style={styles.emptyIcon}>🧺</Text><Text style={styles.emptyTitle}>لسه ما انضمتش لمجموعة</Text><Text style={styles.emptyText}>اختار صفقة من الرئيسية وابدأ بكمية تناسبك.</Text></View>}
          renderItem={({ item }) => {
            const linkedDeal = deals.find((deal) => deal.id === item.dealId)
            const remaining = item.remainingGroupQuantity ?? (item.moq != null && item.committedQuantity != null
              ? Math.max(0, item.moq - item.committedQuantity)
              : linkedDeal ? Math.max(0, linkedDeal.moq - linkedDeal.committedQuantity) : null)
            const reviewAllowed = ["delivered", "picked_up"].includes(item.fulfillmentStatus) && !item.reviewed
            return <View style={styles.card}>
              <View style={styles.productRow}><ProductArt imageUrl={item.imageUrl ?? linkedDeal?.imageUrl} emoji={item.emoji} /><View style={styles.productInfo}>
                <Text style={styles.name}>{item.name}</Text>
                <Text style={styles.category}>{item.quantity} {item.unit} · {item.unitPrice.toFixed(2)} جنيه للوحدة</Text>
                <Text style={styles.orderDetail}>حالة الطلب: {orderStatusLabel(item.status)}</Text>
                <Text style={styles.orderDetail}>الدفع: {paymentLabel(item.paymentStatus ?? (item.status === "pending_payment" ? "pending_payment" : undefined))}{item.paymentMethod ? ` · ${paymentMethodName(item.paymentMethod)}` : ""}</Text>
                {item.paymentStatus === "rejected" && item.paymentReviewNote ? <Text style={styles.paymentText}>ملاحظة الإدارة: {item.paymentReviewNote}</Text> : null}
                <Text style={styles.orderDetail}>التسليم: {fulfillmentLabel(item.fulfillmentStatus)}</Text>
                <Text style={styles.orderDetail}>{remaining == null ? "كمية المجموعة ستظهر عند توفر تحديث العرض" : remaining === 0 ? "اكتملت الكمية المطلوبة للمجموعة" : `متبقي ${remaining} ${item.unit} لاكتمال المجموعة`}</Text>
                <Text style={styles.pickup}>{item.fulfillmentMethod === "merchant_shipping" ? `عنوان التوصيل: ${item.shippingAddress || "غير مسجل"}` : `استلام ذاتي · ${item.pickupLabel || "نقطة التاجر"}`}</Text>
                {item.carrierName || item.trackingNumber ? <Text style={styles.pickup}>{item.carrierName || "شركة الشحن"} · رقم التتبع {item.trackingNumber || "لم يضف بعد"}</Text> : null}
                {item.fulfillmentNote ? <Text style={styles.pickup}>ملاحظة التاجر: {item.fulfillmentNote}</Text> : null}
                {item.trackingUrl ? <TouchableOpacity onPress={() => void Linking.openURL(item.trackingUrl!)}><Text style={styles.trackLink}>فتح تتبع الشحنة ←</Text></TouchableOpacity> : null}
              </View></View>
              <View style={styles.priceRow}><Text style={styles.progressCount}>الإجمالي {item.total.toFixed(2)} جنيه</Text><View style={styles.actions}>
                {reviewAllowed && <TouchableOpacity style={styles.reviewButton} onPress={() => { setSelectedReview(item); setReviewRating(5); setReviewComment("") }}><Text style={styles.reviewButtonText}>قيّم الطلب</Text></TouchableOpacity>}
                {item.status === "pending_payment" && ["awaiting_transfer", "rejected"].includes(item.paymentStatus ?? "") && <TouchableOpacity style={styles.reviewButton} onPress={() => resumePaymentReceipt(item)}><Text style={styles.reviewButtonText}>{item.paymentStatus === "rejected" ? "إعادة رفع الإيصال" : "إرفاق إيصال التحويل"}</Text></TouchableOpacity>}
                {item.status === "pending_payment" && <TouchableOpacity style={styles.cancelButton} onPress={() => void cancelOrder(item)}><Text style={styles.cancelText}>إلغاء الطلب</Text></TouchableOpacity>}
              </View></View>
            </View>
          }}
        />
      ) : (
        <ScrollView contentContainerStyle={styles.accountPanel} keyboardShouldPersistTaps="handled">
          <Text style={styles.emptyIcon}>👤</Text><Text style={styles.emptyTitle}>{account.name}</Text><Text style={styles.emptyText}>{account.email}</Text>
          <Text style={styles.accountSectionTitle}>بيانات التواصل والعنوان</Text>
          <TextInput value={profilePhone} onChangeText={setProfilePhone} style={styles.authInput} placeholder="رقم الهاتف" placeholderTextColor="#849088" keyboardType="phone-pad" textAlign="right" />
          <TouchableOpacity onPress={() => setShowGovernorates((open) => !open)} style={styles.selectField}><Text style={styles.selectFieldText}>{profileGovernorate || "اختر المحافظة"}</Text><Text style={styles.selectHint}>المحافظة</Text></TouchableOpacity>
          {showGovernorates && <ScrollView style={styles.optionPicker} nestedScrollEnabled><View style={styles.choiceWrap}>{GOVERNORATES.map((name) => <TouchableOpacity key={name} onPress={() => { setProfileGovernorate(name); setProfileCity(""); setShowGovernorates(false) }} style={[styles.choiceChip, profileGovernorate === name && styles.choiceChipActive]}><Text style={[styles.choiceChipText, profileGovernorate === name && styles.choiceChipTextActive]}>{name}</Text></TouchableOpacity>)}</View></ScrollView>}
          <TextInput value={profileCity} onChangeText={setProfileCity} style={styles.authInput} placeholder="المدينة" placeholderTextColor="#849088" textAlign="right" />
          {profileGovernorate && <View style={styles.choiceWrap}>{(CITIES[profileGovernorate] ?? []).map((name) => <TouchableOpacity key={name} onPress={() => setProfileCity(name)} style={[styles.choiceChip, profileCity === name && styles.choiceChipActive]}><Text style={[styles.choiceChipText, profileCity === name && styles.choiceChipTextActive]}>{name}</Text></TouchableOpacity>)}</View>}
          <TextInput value={profileAddress} onChangeText={setProfileAddress} style={[styles.authInput, styles.addressInput]} placeholder="العنوان بالتفصيل" placeholderTextColor="#849088" multiline textAlign="right" />
          <TouchableOpacity disabled={profileBusy} onPress={() => void saveProfile()} style={styles.retry}>{profileBusy ? <ActivityIndicator color="white" /> : <Text style={styles.joinText}>حفظ بيانات الحساب</Text>}</TouchableOpacity>
          <Text style={styles.accountSectionTitle}>تفضيلات واتساب</Text>
          <TextInput value={whatsappPhone} onChangeText={setWhatsappPhone} style={styles.authInput} placeholder="رقم الهاتف لواتساب" placeholderTextColor="#849088" keyboardType="phone-pad" textAlign="right" />
          <View style={styles.consentRow}><Text style={styles.consentText}>موافق على رسائل واتساب للطلبات والعروض</Text><Switch value={whatsappAllowed} onValueChange={setWhatsappAllowed} trackColor={{ true: GREEN }} /></View>
          <TouchableOpacity onPress={() => void saveWhatsAppPreferences()} style={styles.secondaryAction}><Text style={styles.secondaryActionText}>حفظ تفضيلات واتساب</Text></TouchableOpacity>
          <Text style={styles.accountSectionTitle}>تواصل مع الدعم</Text>
          <TextInput value={ticketSubject} onChangeText={setTicketSubject} style={styles.authInput} placeholder="عنوان المشكلة أو الاستفسار" placeholderTextColor="#849088" textAlign="right" maxLength={120} />
          <TextInput value={ticketMessage} onChangeText={setTicketMessage} style={[styles.authInput, styles.addressInput]} placeholder="اكتب رسالتك للدعم" placeholderTextColor="#849088" multiline textAlign="right" maxLength={2000} />
          <TouchableOpacity disabled={ticketBusy} onPress={() => void sendSupportTicket()} style={styles.retry}>{ticketBusy ? <ActivityIndicator color="white" /> : <Text style={styles.joinText}>إرسال للدعم</Text>}</TouchableOpacity>
          <View style={styles.ticketHeading}><TouchableOpacity onPress={() => void loadSupportTickets()}><Text style={styles.trackLink}>تحديث</Text></TouchableOpacity><Text style={styles.accountSectionTitle}>سجل تذاكر الدعم</Text></View>
          {tickets.length ? tickets.map((ticket) => <View key={ticket.id} style={styles.ticketCard}><Text style={styles.ticketSubject}>{ticket.subject}</Text><Text style={styles.pickup}>{ticket.message}</Text><Text style={styles.ticketStatus}>{ticketStatusLabel(ticket.status)}{ticket.createdAt ? ` · ${ticket.createdAt}` : ""}</Text></View>) : <Text style={styles.accountNote}>لا توجد تذاكر بعد. أرسل استفسارك وسيظهر هنا.</Text>}
          <TouchableOpacity onPress={() => void signOut()} style={styles.secondaryAction}><Text style={styles.secondaryActionText}>تسجيل الخروج</Text></TouchableOpacity>
        </ScrollView>
      )}
      <View style={styles.tabs}>
        <TouchableOpacity onPress={() => setActiveTab("deals")}><Text style={activeTab === "deals" ? styles.activeTab : styles.tab}>⌂  الرئيسية</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => { setActiveTab("cart"); void loadCart() }}><Text style={activeTab === "cart" ? styles.activeTab : styles.tab}>🛒 السلة {cartItems.length ? `(${cartItems.length})` : ""}</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => { setActiveTab("orders"); void loadMemberships() }}><Text style={activeTab === "orders" ? styles.activeTab : styles.tab}>♡  مجموعاتي</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => { setActiveTab("account"); void loadSupportTickets() }}><Text style={activeTab === "account" ? styles.activeTab : styles.tab}>♙  حسابي</Text></TouchableOpacity>
      </View>
      <Modal visible={selectedDeal !== null || receiptOrder !== null} transparent animationType="slide" onRequestClose={() => { setReceiptOrder(null); setSelectedDeal(null) }}>
        <View style={styles.modalBackdrop}><ScrollView style={styles.joinScroll} contentContainerStyle={styles.joinModal} keyboardShouldPersistTaps="handled">
          {receiptOrder ? <>
            <Text style={styles.authEyebrow}>إثبات التحويل اليدوي</Text>
            <Text style={styles.emptyTitle}>{receiptOrder.name}</Text>
            <Text style={styles.emptyText}>حوّل { (receiptOrder.amountMinor / 100).toFixed(2) } جنيه، ثم ارفع صورة الإيصال.</Text>
            <View style={styles.paymentNotice}>
              <Text style={styles.paymentTitle}>التحويل إلى الرقم 01018040600</Text>
              <Text style={styles.paymentMethod}>وسيلة التحويل: {paymentMethodName(receiptOrder.paymentMethod)}</Text>
              <Text style={styles.paymentText}>بعد التحويل، أرفق لقطة الإيصال. سيظل الطلب بانتظار مراجعة الإدارة، ولن يظهر للبائع كطلب مؤكد قبل اعتماد الدفع.</Text>
            </View>
            <TextInput value={transferReference} onChangeText={setTransferReference} style={styles.authInput} maxLength={80} placeholder="رقم العملية (اختياري)" textAlign="right" />
            <TouchableOpacity onPress={() => void pickPaymentReceipt()} style={styles.receiptPicker}><Text style={styles.receiptPickerText}>{receiptDataUrl ? "اختيار صورة أخرى" : "اختيار صورة الإيصال من الهاتف"}</Text></TouchableOpacity>
            {receiptDataUrl ? <Image source={{ uri: receiptDataUrl }} style={styles.receiptPreview} resizeMode="contain" /> : null}
            <TouchableOpacity disabled={receiptBusy || !receiptDataUrl} onPress={() => void sendPaymentReceipt()} style={[styles.authButton, (receiptBusy || !receiptDataUrl) && styles.disabledButton]}>{receiptBusy ? <ActivityIndicator color="white" /> : <Text style={styles.authButtonText}>إرسال الإيصال للمراجعة</Text>}</TouchableOpacity>
            <TouchableOpacity onPress={() => { setReceiptOrder(null); setSelectedDeal(null) }} style={styles.authToggle}><Text style={styles.authToggleText}>أكمل لاحقًا من صفحة مجموعاتي</Text></TouchableOpacity>
          </> : <>
            <Text style={styles.authEyebrow}>طلب كمية من التاجر</Text>
            <Text style={styles.emptyTitle}>{selectedDeal?.name}</Text>
            <Text style={styles.emptyText}>{selectedDeal?.price.toFixed(2)} جنيه للوحدة</Text>
            <View style={styles.paymentNotice}>
              <Text style={styles.paymentTitle}>اختر وسيلة التحويل</Text>
              {paymentConfig.methods.filter((method) => typeof method !== "string").map((method, index) => {
                const option = method as { id?: string; label?: string; name?: string; accountNumber?: string }
                return <TouchableOpacity key={option.id ?? index} onPress={() => { if (option.id === "vodafone_cash" || option.id === "instapay") setPaymentMethod(option.id) }} style={[styles.paymentChoice, paymentMethod === option.id && styles.paymentChoiceActive]}>
                  <Text style={styles.paymentMethod}>{option.label ?? option.name} · {option.accountNumber ?? "01018040600"}</Text>
                </TouchableOpacity>
              })}
              <Text style={styles.paymentText}>التحويل يدوي إلى 01018040600. بعد إنشاء الطلب ارفع صورة الإيصال؛ لن يتم تأكيد الدفع آليًا.</Text>
            </View>
            <TextInput value={joinQuantity} onChangeText={setJoinQuantity} style={styles.authInput} keyboardType="number-pad" maxLength={7} placeholder="الكمية" textAlign="right" />
            {platformSettings.coupons_enabled && <TextInput value={couponCode} onChangeText={setCouponCode} style={styles.authInput} autoCapitalize="characters" maxLength={40} placeholder="كود الخصم (اختياري)" textAlign="right" />}
            {platformSettings.loyalty_enabled && <><Text style={styles.authNote}>رصيدك: {loyaltyPoints} نقطة</Text><TextInput value={loyaltyPointsToUse} onChangeText={setLoyaltyPointsToUse} style={styles.authInput} keyboardType="number-pad" maxLength={7} placeholder="نقاط تستخدمها (اختياري)" textAlign="right" /></>}
            <Text style={styles.authNote}>المتاح الآن: {selectedDeal?.availableQuantity} {selectedDeal?.unit}</Text>
            {selectedDeal?.acceptsShipping && platformSettings.merchant_shipping_enabled !== false && selectedDeal.acceptsPickup && platformSettings.self_pickup_enabled !== false ? <View style={styles.fulfillmentChoices}>
              <TouchableOpacity onPress={() => setFulfillmentMethod("self_pickup")} style={[styles.fulfillmentChoice, fulfillmentMethod === "self_pickup" && styles.fulfillmentSelected]}><Text style={styles.fulfillmentChoiceTitle}>بدون توصيل</Text><Text style={styles.fulfillmentChoiceText}>استلام من نقطة التاجر</Text></TouchableOpacity>
              <TouchableOpacity onPress={() => setFulfillmentMethod("merchant_shipping")} style={[styles.fulfillmentChoice, fulfillmentMethod === "merchant_shipping" && styles.fulfillmentSelected]}><Text style={styles.fulfillmentChoiceTitle}>شحن من التاجر</Text><Text style={styles.fulfillmentChoiceText}>أدخل عنوان التوصيل</Text></TouchableOpacity>
            </View> : <Text style={styles.authNote}>{fulfillmentMethod === "merchant_shipping" ? "التوصيل من التاجر" : "بدون توصيل · استلام ذاتي"}</Text>}
            {fulfillmentMethod === "merchant_shipping" && <TextInput value={shippingAddress} onChangeText={setShippingAddress} style={[styles.authInput, styles.addressInput]} multiline maxLength={500} placeholder="المنطقة، الشارع، وعلامة مميزة" textAlign="right" />}
            {fulfillmentMethod === "self_pickup" && <Text style={styles.authNote}>نقطة الاستلام: {selectedDeal?.pickupLabel || "عنوان التاجر"}</Text>}
            <Text style={styles.authNote}>{fulfillmentMethod === "merchant_shipping" ? "العنوان يرسل للتاجر لتنفيذ التسليم بعد اعتماد الدفع." : "طريقة التسليم: استلام ذاتي من نقطة التاجر."}</Text>
            <TouchableOpacity disabled={joinBusy || !paymentReady || (selectedDeal?.availableQuantity ?? 0) < 1 || platformSettings.orders_enabled === false} onPress={() => void confirmJoin()} style={[styles.authButton, (joinBusy || !paymentReady || (selectedDeal?.availableQuantity ?? 0) < 1 || platformSettings.orders_enabled === false) && styles.disabledButton]}>{joinBusy ? <ActivityIndicator color="white" /> : <Text style={styles.authButtonText}>{!paymentReady ? "خيارات التحويل غير متاحة" : platformSettings.orders_enabled === false ? "الطلبات متوقفة" : "تأكيد الطلب ومتابعة التحويل"}</Text>}</TouchableOpacity>
            <TouchableOpacity onPress={() => setSelectedDeal(null)} style={styles.authToggle}><Text style={styles.authToggleText}>رجوع</Text></TouchableOpacity>
          </>}
        </ScrollView></View>
      </Modal>
      <Modal visible={selectedReview !== null} transparent animationType="slide" onRequestClose={() => setSelectedReview(null)}>
        <View style={styles.modalBackdrop}><View style={styles.reviewModal}>
          <Text style={styles.authEyebrow}>تقييم بعد استلام الطلب</Text><Text style={styles.emptyTitle}>{selectedReview?.name}</Text>
          <View style={styles.ratingRow}>{[1, 2, 3, 4, 5].map((rating) => <TouchableOpacity key={rating} onPress={() => setReviewRating(rating)}><Text style={[styles.ratingStar, rating <= reviewRating && styles.ratingStarActive]}>★</Text></TouchableOpacity>)}</View>
          <TextInput value={reviewComment} onChangeText={setReviewComment} style={[styles.authInput, styles.addressInput]} placeholder="تعليقك (اختياري)" placeholderTextColor="#849088" multiline maxLength={1000} textAlign="right" />
          <TouchableOpacity disabled={reviewBusy} onPress={() => void sendReview()} style={styles.authButton}>{reviewBusy ? <ActivityIndicator color="white" /> : <Text style={styles.authButtonText}>إرسال التقييم</Text>}</TouchableOpacity>
          <TouchableOpacity onPress={() => setSelectedReview(null)} style={styles.authToggle}><Text style={styles.authToggleText}>إلغاء</Text></TouchableOpacity>
        </View></View>
      </Modal>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#F5F5F5" },
  authSafe: { flex: 1, backgroundColor: "#F5F5F5" },
  authContent: { flexGrow: 1, justifyContent: "center", padding: 24, paddingTop: 40, paddingBottom: 40 },
  authBrand: { flexDirection: "row", alignItems: "center", justifyContent: "flex-end", gap: 10, marginBottom: 38 },
  authBrandText: { color: GREEN, fontWeight: "900", fontSize: 20 },
  authEyebrow: { color: GREEN, fontSize: 12, fontWeight: "800", textAlign: "right", marginBottom: 8 },
  authTitle: { color: "#202925", fontSize: 30, fontWeight: "900", textAlign: "right" },
  authIntro: { color: "#68736E", fontSize: 13, lineHeight: 22, textAlign: "right", marginTop: 9, marginBottom: 22 },
  authInput: { width: "100%", minHeight: 50, paddingHorizontal: 13, borderWidth: 1, borderColor: "#E1E6E0", borderRadius: 12, backgroundColor: "white", color: "#202925", marginTop: 10, fontSize: 14 },
  authButton: { minHeight: 49, backgroundColor: ORANGE, borderRadius: 12, alignItems: "center", justifyContent: "center", marginTop: 14, paddingHorizontal: 15 },
  authButtonText: { color: "white", fontSize: 13, fontWeight: "800" },
  googleButton: { minHeight: 48, borderWidth: 1, borderColor: "#D6DCD7", borderRadius: 12, backgroundColor: "white", alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 10, marginTop: 10 },
  googleMark: { color: "#4285F4", fontSize: 16, fontWeight: "900" },
  googleButtonText: { color: "#26312B", fontSize: 12, fontWeight: "800" },
  appleButton: { width: "100%", height: 48, marginTop: 10 },
  disabledButton: { opacity: 0.55 },
  authToggle: { alignItems: "center", paddingVertical: 13 },
  authToggleText: { color: GREEN, fontSize: 12, fontWeight: "800" },
  authNote: { color: "#77827A", fontSize: 10, lineHeight: 17, textAlign: "right", marginTop: 15 },
  validationText: { color: "#B44B3E", fontSize: 11, lineHeight: 18, textAlign: "right", marginTop: 12 },
  selectField: { minHeight: 50, paddingHorizontal: 13, borderWidth: 1, borderColor: "#E1E6E0", borderRadius: 12, backgroundColor: "white", marginTop: 10, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  selectFieldText: { color: "#202925", fontSize: 13, fontWeight: "700" },
  selectHint: { color: "#849088", fontSize: 11 },
  optionPicker: { maxHeight: 160, marginTop: 5, borderRadius: 12, backgroundColor: "#F1F4F0" },
  choiceWrap: { flexDirection: "row", flexWrap: "wrap", justifyContent: "flex-end", gap: 6, marginTop: 7 },
  choiceChip: { borderWidth: 1, borderColor: "#DCE4DC", borderRadius: 14, paddingHorizontal: 10, paddingVertical: 7, backgroundColor: "white" },
  choiceChipActive: { borderColor: GREEN, backgroundColor: "#E8F2E8" },
  choiceChipText: { color: "#58645D", fontSize: 10, fontWeight: "700" },
  choiceChipTextActive: { color: GREEN },
  locationButton: { alignItems: "flex-end", paddingVertical: 12 },
  locationButtonText: { color: GREEN, fontSize: 11, fontWeight: "800" },
  consentRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 10, marginTop: 12 },
  consentText: { flex: 1, textAlign: "right", color: "#59645E", fontSize: 10, lineHeight: 16 },
  accountPanel: { flexGrow: 1, alignItems: "stretch", padding: 20, paddingBottom: 36 },
  accountSectionTitle: { color: "#26312B", fontSize: 13, fontWeight: "900", textAlign: "right", marginTop: 23, marginBottom: 3 },
  accountNote: { color: "#77827A", fontSize: 10, lineHeight: 17, textAlign: "right", marginTop: 10 },
  secondaryAction: { alignSelf: "flex-end", paddingVertical: 10, paddingHorizontal: 13, marginTop: 10 },
  secondaryActionText: { color: GREEN, fontSize: 11, fontWeight: "800" },
  ticketHeading: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: 14 },
  ticketCard: { backgroundColor: "white", borderColor: "#E8ECE7", borderWidth: 1, borderRadius: 12, padding: 12, marginTop: 8 },
  ticketSubject: { color: "#202925", fontWeight: "800", fontSize: 12, textAlign: "right" },
  ticketStatus: { color: GREEN, fontSize: 9, textAlign: "right", marginTop: 6 },
  ordersTitle: { textAlign: "right", color: "#59645E", fontSize: 13, fontWeight: "700", marginBottom: 12 },
  logout: { color: GREEN, fontSize: 11, fontWeight: "800", padding: 8 },
  cancelButton: { borderWidth: 1, borderColor: "#EDC8BF", backgroundColor: "#F9E9E5", borderRadius: 8, paddingHorizontal: 9, paddingVertical: 6 },
  cancelText: { color: "#B44B3E", fontSize: 9, fontWeight: "800" },
  modalBackdrop: { flex: 1, justifyContent: "flex-end", backgroundColor: "#15241DBB" },
  joinScroll: { maxHeight: "88%", width: "100%" },
  joinModal: { backgroundColor: "#F8F7F2", borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, paddingBottom: 34 },
  paymentNotice: { backgroundColor: "#FFF1E5", borderColor: "#F3D5BC", borderWidth: 1, borderRadius: 13, padding: 12, marginTop: 14 },
  paymentTitle: { color: "#9B4300", fontSize: 12, fontWeight: "900", textAlign: "right" },
  paymentText: { color: "#775A44", fontSize: 10, lineHeight: 17, textAlign: "right", marginTop: 5 },
  paymentMethod: { color: "#38533E", fontSize: 11, textAlign: "right", marginTop: 5 },
  paymentChoice: { borderWidth: 1, borderColor: "#F3D5BC", borderRadius: 9, paddingHorizontal: 9, paddingVertical: 8, marginTop: 7 },
  paymentChoiceActive: { borderColor: GREEN, backgroundColor: "#E8F2E8" },
  receiptPicker: { minHeight: 46, marginTop: 12, borderWidth: 1, borderColor: GREEN, borderRadius: 11, alignItems: "center", justifyContent: "center", backgroundColor: "white" },
  receiptPickerText: { color: GREEN, fontSize: 12, fontWeight: "800" },
  receiptPreview: { width: "100%", height: 210, marginTop: 10, backgroundColor: "white", borderRadius: 10 },
  reviewModal: { width: "100%", backgroundColor: "#F8F7F2", borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, paddingBottom: 32 },
  ratingRow: { flexDirection: "row", justifyContent: "center", gap: 12, marginVertical: 17 },
  ratingStar: { color: "#CCD2CC", fontSize: 33 },
  ratingStarActive: { color: "#F4A321" },
  reviewButton: { borderWidth: 1, borderColor: GREEN, borderRadius: 8, paddingHorizontal: 9, paddingVertical: 6 },
  reviewButtonText: { color: GREEN, fontSize: 9, fontWeight: "800" },
  fulfillmentChoices: { flexDirection: "row", gap: 8, marginTop: 13 },
  fulfillmentChoice: { flex: 1, padding: 11, borderWidth: 1, borderColor: "#E1E6E0", borderRadius: 12, backgroundColor: "white" },
  fulfillmentSelected: { borderColor: GREEN, backgroundColor: "#E9F2E9" },
  fulfillmentChoiceTitle: { textAlign: "right", color: "#202925", fontSize: 11, fontWeight: "800" },
  fulfillmentChoiceText: { textAlign: "right", color: "#68736E", fontSize: 9, marginTop: 4 },
  addressInput: { minHeight: 85, textAlignVertical: "top", paddingTop: 12 },
  availabilityRow: { flexDirection: "row", justifyContent: "space-between", gap: 7, marginTop: 8 },
  availability: { color: "#68736E", fontSize: 9, textAlign: "right", flexShrink: 1 },
  trackLink: { color: GREEN, fontSize: 10, fontWeight: "800", marginTop: 6, textAlign: "right" },
  header: { paddingHorizontal: 20, paddingTop: 12, paddingBottom: 20, flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  greeting: { fontSize: 24, fontWeight: "800", color: "#202925", textAlign: "right" },
  location: { fontSize: 12, color: "#68736E", marginTop: 3, textAlign: "right" },
  brand: { width: 38, height: 38, borderRadius: 13, backgroundColor: ORANGE, alignItems: "center", justifyContent: "center" },
  brandMark: { fontSize: 22, color: "white", fontWeight: "800" },
  titleRow: { paddingHorizontal: 20, paddingBottom: 13, flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  title: { fontSize: 20, fontWeight: "800", color: "#202925", textAlign: "right" },
  subtitle: { fontSize: 11, color: "#707B75", marginTop: 2, textAlign: "right" },
  live: { color: GREEN, backgroundColor: "#E7F2E7", paddingHorizontal: 9, paddingVertical: 5, borderRadius: 10, fontSize: 10, fontWeight: "700" },
  list: { paddingHorizontal: 14, paddingBottom: 14 },
  highlightSection: { marginBottom: 13 },
  highlightHeading: { flexDirection: "row", justifyContent: "space-between", alignItems: "baseline", paddingHorizontal: 2, marginBottom: 7 },
  highlightTitle: { color: "#202925", fontSize: 14, fontWeight: "900", textAlign: "right" },
  highlightCount: { color: "#87918A", fontSize: 9 },
  highlightRow: { gap: 8, paddingBottom: 3 },
  highlightCard: { width: 238, padding: 10, backgroundColor: "white", borderRadius: 14, borderWidth: 1, borderColor: "#ECEEEC" },
  highlightProduct: { flexDirection: "row", alignItems: "center", gap: 9 },
  highlightArt: { width: 48, height: 48, borderRadius: 12 },
  highlightInfo: { flex: 1, alignItems: "flex-end" },
  highlightName: { color: "#202925", fontSize: 11, fontWeight: "800", textAlign: "right" },
  highlightPrice: { color: ORANGE, fontSize: 10, fontWeight: "800", marginTop: 3, textAlign: "right" },
  highlightSeller: { color: "#68736E", fontSize: 9, marginTop: 3, textAlign: "right" },
  highlightEmpty: { color: "#7A847E", fontSize: 10, textAlign: "right", paddingVertical: 6 },
  categoryHeader: { marginTop: 5, marginBottom: 12 },
  categoryRow: { flexDirection: "row", gap: 6, paddingVertical: 7 },
  sectionLabel: { color: "#5D6962", fontSize: 11, fontWeight: "800", textAlign: "right", marginBottom: 7 },
  card: { backgroundColor: "white", borderRadius: 18, padding: 14, marginBottom: 11, borderWidth: 1, borderColor: "#ECEEEC" },
  productRow: { flexDirection: "row", alignItems: "center", gap: 9 },
  art: { width: 57, height: 57, backgroundColor: "#FFF4E9", borderRadius: 14, justifyContent: "center", alignItems: "center" },
  artImage: { width: "100%", height: "100%", borderRadius: 14 },
  emoji: { fontSize: 31 },
  productInfo: { flex: 1, alignItems: "flex-end" },
  category: { color: GREEN, fontSize: 10, fontWeight: "700" },
  name: { color: "#202925", fontSize: 15, fontWeight: "800", marginTop: 2, textAlign: "right" },
  pickup: { color: "#727C76", fontSize: 9, marginTop: 3, textAlign: "right" },
  orderDetail: { color: "#59645E", fontSize: 10, marginTop: 4, textAlign: "right" },
  discount: { alignSelf: "flex-start", backgroundColor: "#FFF0E3", color: "#B65000", borderRadius: 7, paddingHorizontal: 6, paddingVertical: 4, fontSize: 9, fontWeight: "800" },
  priceRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "baseline", marginTop: 13 },
  price: { color: ORANGE, fontSize: 20, fontWeight: "800" },
  currency: { color: "#59645E", fontSize: 10, fontWeight: "500" },
  oldPrice: { color: "#929A95", fontSize: 10, textDecorationLine: "line-through" },
  progressLabels: { flexDirection: "row", justifyContent: "space-between", marginTop: 10 },
  progressCount: { color: "#36433B", fontSize: 10, fontWeight: "800" },
  progressHint: { color: "#7A847E", fontSize: 9 },
  track: { height: 7, borderRadius: 6, backgroundColor: "#EDF0ED", overflow: "hidden", marginTop: 5 },
  fill: { height: "100%", borderRadius: 6, backgroundColor: ORANGE },
  footer: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-end", marginTop: 12 },
  timerLabel: { color: "#7A847E", fontSize: 8 },
  timer: { color: "#202925", fontSize: 11, fontWeight: "800", fontVariant: ["tabular-nums"] },
  actions: { flexDirection: "row", gap: 6 },
  shareButton: { paddingHorizontal: 10, paddingVertical: 8, borderRadius: 9, borderWidth: 1, borderColor: "#E3E9E3" },
  shareText: { color: GREEN, fontSize: 10, fontWeight: "700" },
  cartButton: { backgroundColor: GREEN, paddingHorizontal: 10, paddingVertical: 8, borderRadius: 9 },
  cartButtonText: { color: "white", fontSize: 10, fontWeight: "800" },
  joinButton: { backgroundColor: ORANGE, paddingHorizontal: 12, paddingVertical: 8, borderRadius: 9 },
  retry: { marginTop: 14, backgroundColor: ORANGE, paddingVertical: 9, paddingHorizontal: 18, borderRadius: 10 },
  joinText: { color: "white", fontSize: 10, fontWeight: "800" },
  center: { flex: 1, alignItems: "center", justifyContent: "center", padding: 30 },
  emptyIcon: { fontSize: 35 },
  emptyTitle: { fontSize: 16, fontWeight: "800", color: "#202925", marginTop: 9, textAlign: "center" },
  emptyText: { fontSize: 12, color: "#707B75", textAlign: "center", marginTop: 6 },
  tabs: { height: 56, backgroundColor: "white", borderTopWidth: 1, borderTopColor: "#E8EAE8", flexDirection: "row", justifyContent: "space-around", alignItems: "center" },
  tab: { fontSize: 10, color: "#89918C" },
  activeTab: { fontSize: 10, color: ORANGE, fontWeight: "800" },
})
