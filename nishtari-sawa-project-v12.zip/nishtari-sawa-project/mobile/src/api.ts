import * as SecureStore from "expo-secure-store"

export type Deal = {
  id: string
  name: string
  category: string
  emoji: string
  unit: string
  price: number
  retailPrice: number
  moq: number
  maxQuantity: number | null
  stockQuantity: number
  availableQuantity: number
  committedQuantity: number
  acceptsShipping: boolean
  acceptsPickup: boolean
  distanceKm: number
  endsAt: string
  pickupLabel?: string
}

export type Account = { id: string; name: string; email: string; role: "buyer" | "supplier" | "admin"; phone?: string | null; whatsappOptIn?: boolean }
export type SocialProvider = "google" | "apple"
export type SocialAuthConfig = { google: boolean; apple: boolean }
export type Membership = {
  membershipId: string
  dealId: string
  name: string
  emoji: string
  unit: string
  quantity: number
  unitPrice: number
  total: number
  status: string
  createdAt: string
  sellerName: string
  fulfillmentMethod: "merchant_shipping" | "self_pickup"
  shippingAddress: string | null
  fulfillmentStatus: string
  carrierName: string | null
  trackingNumber: string | null
  trackingUrl: string | null
  fulfillmentNote: string | null
  pickupLabel: string | null
}
export type CartItem = Omit<Deal, "distanceKm"> & {
  dealId: string
  quantity: number
  status: string
  pickupLabel: string
  updatedAt: string
}
export type PlatformSettings = Record<string, boolean>
export type BuyerLoyalty = { points: number; profile: { loyaltyPointsPerEgp: number } }

const API_URL = process.env.EXPO_PUBLIC_API_URL?.replace(/\/$/, "")

async function request<T>(path: string, init?: RequestInit, token?: string): Promise<T> {
  if (!API_URL) throw new Error("ظبّط عنوان السيرفر الأول في EXPO_PUBLIC_API_URL")
  const headers: Record<string, string> = { "Content-Type": "application/json", ...init?.headers as Record<string, string> }
  if (token) headers.Authorization = `Bearer ${token}`
  const response = await fetch(`${API_URL}${path}`, {
    ...init,
    headers,
  })
  const body = await response.json().catch(() => ({}))
  if (!response.ok) throw Object.assign(new Error(body.error ?? `server_error_${response.status}`), { status: response.status })
  return body as T
}

export async function getSavedAccount(): Promise<Account | null> {
  const token = await SecureStore.getItemAsync("nishtari_access_token")
  if (!token) return null
  try {
    const result = await request<{ user: Account }>("/api/v1/auth/me", undefined, token)
    return result.user
  } catch (error) {
    if ((error as Error & { status?: number }).status === 401) {
      await SecureStore.deleteItemAsync("nishtari_access_token")
      return null
    }
    throw error
  }
}

export async function loginAccount(email: string, password: string): Promise<Account> {
  const result = await request<{ user: Account; accessToken: string }>("/api/v1/auth/login", {
    method: "POST",
    body: JSON.stringify({ email, password }),
  })
  await SecureStore.setItemAsync("nishtari_access_token", result.accessToken)
  return result.user
}

export async function createOAuthNonce(provider: SocialProvider): Promise<string> {
  const result = await request<{ nonce: string }>("/api/v1/auth/nonce", {
    method: "POST",
    body: JSON.stringify({ provider }),
  })
  return result.nonce
}

export async function loginWithSocial(provider: SocialProvider, idToken: string, nonce: string, name?: string): Promise<Account> {
  const result = await request<{ user: Account; accessToken: string }>("/api/v1/auth/social", {
    method: "POST",
    body: JSON.stringify({ provider, idToken, nonce, name }),
  })
  await SecureStore.setItemAsync("nishtari_access_token", result.accessToken)
  return result.user
}

export async function registerBuyer(name: string, email: string, password: string, phone: string, whatsappOptIn: boolean): Promise<Account> {
  const result = await request<{ user: Account; accessToken: string }>("/api/v1/auth/register", {
    method: "POST",
    body: JSON.stringify({ name, email, password, role: "buyer", phone, whatsappOptIn }),
  })
  await SecureStore.setItemAsync("nishtari_access_token", result.accessToken)
  return result.user
}

export async function logoutAccount(): Promise<void> {
  await SecureStore.deleteItemAsync("nishtari_access_token")
}

export async function getNearbyDeals(latitude: number, longitude: number): Promise<Deal[]> {
  const params = new URLSearchParams({ lat: String(latitude), lng: String(longitude), radius_km: "2" })
  const result = await request<{ deals: Deal[] }>(`/api/v1/deals/nearby?${params}`)
  return result.deals
}

export async function getPublicSettings(): Promise<PlatformSettings> {
  const result = await request<{ settings: PlatformSettings }>("/api/v1/config")
  return result.settings
}

export async function getSocialAuthConfig(): Promise<SocialAuthConfig> {
  const result = await request<{ authProviders?: Partial<Record<SocialProvider, { enabled?: boolean }>> }>("/api/v1/config")
  return {
    google: result.authProviders?.google?.enabled === true,
    apple: result.authProviders?.apple?.enabled === true,
  }
}

export async function getBuyerMemberships(): Promise<Membership[]> {
  const token = await SecureStore.getItemAsync("nishtari_access_token")
  if (!token) throw new Error("سجّل دخولك الأول.")
  const result = await request<{ memberships: Membership[] }>("/api/v1/me/memberships", undefined, token)
  return result.memberships
}

export async function cancelMembership(membershipId: string): Promise<void> {
  const token = await SecureStore.getItemAsync("nishtari_access_token")
  if (!token) throw new Error("سجّل دخولك الأول.")
  await request(`/api/v1/me/memberships/${encodeURIComponent(membershipId)}`, { method: "DELETE" }, token)
}

export async function requestToJoin(
  dealId: string,
  quantity: number,
  fulfillmentMethod: "merchant_shipping" | "self_pickup",
  shippingAddress?: string,
  couponCode?: string,
  loyaltyPointsToUse = 0,
) {
  const token = await SecureStore.getItemAsync("nishtari_access_token")
  if (!token) throw new Error("سجّل دخولك الأول.")
  const key = `${Date.now()}-${Math.random().toString(36).slice(2, 18)}`
  return request<{ membershipId: string; paymentStatus: string; message: string }>(`/api/v1/deals/${dealId}/memberships`, {
    method: "POST",
    headers: { "Idempotency-Key": key },
    body: JSON.stringify({ quantity, fulfillmentMethod, shippingAddress, couponCode: couponCode || null, loyaltyPointsToUse }),
  }, token)
}

export async function getBuyerLoyalty(): Promise<BuyerLoyalty> {
  const token = await SecureStore.getItemAsync("nishtari_access_token")
  if (!token) throw new Error("سجّل دخولك الأول.")
  return request<BuyerLoyalty>("/api/v1/me/loyalty", undefined, token)
}

export async function getBuyerCart(): Promise<CartItem[]> {
  const token = await SecureStore.getItemAsync("nishtari_access_token")
  if (!token) throw new Error("سجّل دخولك الأول.")
  const result = await request<{ items: CartItem[] }>("/api/v1/me/cart", undefined, token)
  return result.items
}

export async function saveCartItem(dealId: string, quantity: number): Promise<void> {
  const token = await SecureStore.getItemAsync("nishtari_access_token")
  if (!token) throw new Error("سجّل دخولك الأول.")
  await request(`/api/v1/me/cart/items/${encodeURIComponent(dealId)}`, {
    method: "PUT",
    body: JSON.stringify({ quantity }),
  }, token)
}

export async function deleteCartItem(dealId: string): Promise<void> {
  const token = await SecureStore.getItemAsync("nishtari_access_token")
  if (!token) throw new Error("سجّل دخولك الأول.")
  await request(`/api/v1/me/cart/items/${encodeURIComponent(dealId)}`, { method: "DELETE" }, token)
}

export async function registerPushDevice(token: string, platform: "android" | "ios"): Promise<void> {
  const accessToken = await SecureStore.getItemAsync("nishtari_access_token")
  if (!accessToken) return
  await request("/api/v1/me/push-devices", {
    method: "POST",
    body: JSON.stringify({ token, platform }),
  }, accessToken)
}

export async function unregisterPushDevice(token: string): Promise<void> {
  const accessToken = await SecureStore.getItemAsync("nishtari_access_token")
  if (!accessToken) return
  await request(`/api/v1/me/push-devices/${encodeURIComponent(token)}`, { method: "DELETE" }, accessToken)
}

export async function updateWhatsAppConsent(phone: string, whatsappOptIn: boolean): Promise<void> {
  const token = await SecureStore.getItemAsync("nishtari_access_token")
  if (!token) throw new Error("سجّل دخولك الأول.")
  await request("/api/v1/me/notifications/whatsapp", {
    method: "PATCH",
    body: JSON.stringify({ phone, whatsappOptIn }),
  }, token)
}
