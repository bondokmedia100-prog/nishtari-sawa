import React, { useEffect, useState } from "react"
import { ActivityIndicator, Alert, FlatList, Linking, Modal, Platform, SafeAreaView, ScrollView, StatusBar, StyleSheet, Switch, Text, TextInput, TouchableOpacity, View } from "react-native"
import * as AppleAuthentication from "expo-apple-authentication"
import * as Crypto from "expo-crypto"
import * as Google from "expo-auth-session/providers/google"
import * as Location from "expo-location"
import * as Device from "expo-device"
import * as Notifications from "expo-notifications"
import Constants from "expo-constants"
import * as WebBrowser from "expo-web-browser"
import { Account, CartItem, Deal, Membership, PlatformSettings, cancelMembership, createOAuthNonce, deleteCartItem, getBuyerCart, getBuyerLoyalty, getBuyerMemberships, getNearbyDeals, getPublicSettings, getSavedAccount, getSocialAuthConfig, loginAccount, loginWithSocial, logoutAccount, registerBuyer, registerPushDevice, requestToJoin, saveCartItem, unregisterPushDevice, updateWhatsAppConsent } from "./src/api"

WebBrowser.maybeCompleteAuthSession()
Notifications.setNotificationHandler({
  handleNotification: async () => ({ shouldShowAlert: true, shouldPlaySound: true, shouldSetBadge: false }),
})

const ORANGE = "#FF6F00"
const GREEN = "#2E7D32"
const GOOGLE_IOS_CLIENT_ID = process.env.EXPO_PUBLIC_GOOGLE_IOS_CLIENT_ID ?? ""
const GOOGLE_ANDROID_CLIENT_ID = process.env.EXPO_PUBLIC_GOOGLE_ANDROID_CLIENT_ID ?? ""
const GOOGLE_WEB_CLIENT_ID = process.env.EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID ?? ""

function Countdown({ endsAt }: { endsAt: string }) {
  const [now, setNow] = useState(Date.now())
  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1000)
    return () => clearInterval(timer)
  }, [])
  const seconds = Math.max(0, Math.floor((new Date(endsAt).getTime() - now) / 1000))
  return <Text style={styles.timer}>{Math.floor(seconds / 3600)}س {Math.floor(seconds % 3600 / 60)}د {String(seconds % 60).padStart(2, "0")}ث</Text>
}

function fulfillmentLabel(status: string) {
  return ({ not_started: "بانتظار تجهيز التاجر", preparing: "قيد التجهيز", shipped: "تم الشحن", in_transit: "في الطريق", ready_for_pickup: "جاهز للاستلام", delivered: "تم التوصيل", picked_up: "تم الاستلام" } as Record<string, string>)[status] ?? status
}

function socialError(error: unknown) {
  const code = error instanceof Error ? error.message : ""
  return ({
    identity_provider_not_configured: "لم تُضبط بيانات مزوّد الدخول على الخادم بعد.",
    identity_provider_unavailable: "تعذر التحقق من Google أو Apple الآن. حاول مرة أخرى.",
    invalid_identity_token: "لم نتمكن من تأكيد هوية الحساب. أعد المحاولة.",
    invalid_or_expired_nonce: "انتهت جلسة الدخول الآمنة. حاول مرة أخرى.",
    verified_email_required: "يحتاج الحساب إلى بريد إلكتروني مؤكّد.",
    buyer_registration_paused: "تسجيل المشترين متوقف مؤقتًا.",
    account_disabled: "هذا الحساب موقوف. تواصل مع الإدارة.",
    admin_social_login_must_be_linked: "حساب الإدارة يحتاج إلى تسجيل الدخول بالطريقة المعتمدة له.",
  } as Record<string, string>)[code] ?? "تحقق من الاتصال وإعدادات الدخول، ثم حاول مرة أخرى."
}

export default function App() {
  const [account, setAccount] = useState<Account | null>(null)
  const [authReady, setAuthReady] = useState(false)
  const [authMode, setAuthMode] = useState<"login" | "register">("login")
  const [fullName, setFullName] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [phone, setPhone] = useState("")
  const [whatsappOptIn, setWhatsappOptIn] = useState(false)
  const [whatsappPhone, setWhatsappPhone] = useState("")
  const [whatsappAllowed, setWhatsappAllowed] = useState(false)
  const [pushToken, setPushToken] = useState("")
  const [authBusy, setAuthBusy] = useState(false)
  const [googleNonce, setGoogleNonce] = useState("")
  const [appleAvailable, setAppleAvailable] = useState(false)
  const [socialAuthConfig, setSocialAuthConfig] = useState({ google: false, apple: false })
  const [googleRequest, , promptGoogle] = Google.useIdTokenAuthRequest({
    iosClientId: GOOGLE_IOS_CLIENT_ID || undefined,
    androidClientId: GOOGLE_ANDROID_CLIENT_ID || undefined,
    webClientId: GOOGLE_WEB_CLIENT_ID || undefined,
    extraParams: googleNonce ? { nonce: googleNonce } : {},
    scopes: ["openid", "profile", "email"],
  })
  const [selectedDeal, setSelectedDeal] = useState<Deal | CartItem | null>(null)
  const [joinQuantity, setJoinQuantity] = useState("1")
  const [fulfillmentMethod, setFulfillmentMethod] = useState<"merchant_shipping" | "self_pickup">("self_pickup")
  const [shippingAddress, setShippingAddress] = useState("")
  const [couponCode, setCouponCode] = useState("")
  const [loyaltyPointsToUse, setLoyaltyPointsToUse] = useState("")
  const [loyaltyPoints, setLoyaltyPoints] = useState(0)
  const [joinBusy, setJoinBusy] = useState(false)
  const [activeTab, setActiveTab] = useState<"deals" | "cart" | "orders" | "account">("deals")
  const [memberships, setMemberships] = useState<Membership[]>([])
  const [cartItems, setCartItems] = useState<CartItem[]>([])
  const [deals, setDeals] = useState<Deal[]>([])
  const [platformSettings, setPlatformSettings] = useState<PlatformSettings>({})
  const [loading, setLoading] = useState(true)
  const [locationMessage, setLocationMessage] = useState("بنحدد مكانك...")
  const [error, setError] = useState("")

  async function loadDeals() {
    setLoading(true)
    setError("")
    try {
      const permission = await Location.requestForegroundPermissionsAsync()
      if (permission.status !== "granted") throw new Error("اسمحلنا بالموقع عشان نجيبلك صفقات قريبة.")
      const position = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced })
      setLocationMessage("صفقات قريبة منك · في نطاق ٢ كم")
      try { setPlatformSettings(await getPublicSettings()) } catch {}
      setDeals(await getNearbyDeals(position.coords.latitude, position.coords.longitude))
    } catch (err) {
      setError(err instanceof Error ? err.message : "حصلت مشكلة وإحنا بنجيب الصفقات.")
    } finally {
      setLoading(false)
    }
  }

  async function restoreSession() {
    try {
      const [settings, providers] = await Promise.all([
        getPublicSettings().catch(() => null),
        getSocialAuthConfig().catch(() => null),
      ])
      if (settings) setPlatformSettings(settings)
      if (providers) setSocialAuthConfig(providers)
      const saved = await getSavedAccount()
      if (saved?.role === "buyer") setAccount(saved)
    } catch {
      setError("تعذر الاتصال بالخادم. احتفظنا ببيانات الدخول؛ حاول مرة أخرى.")
    } finally {
      setAuthReady(true)
    }
  }

  useEffect(() => { void restoreSession() }, [])
  useEffect(() => {
    if (!account) return
    setWhatsappPhone(account.phone ?? "")
    setWhatsappAllowed(account.whatsappOptIn === true)
    void loadDeals()
    void loadMemberships()
    void loadCart()
    void loadLoyalty()
    void enablePushNotifications().catch(() => {})
  }, [account?.id])
  useEffect(() => {
    let active = true
    if (GOOGLE_IOS_CLIENT_ID || GOOGLE_ANDROID_CLIENT_ID || GOOGLE_WEB_CLIENT_ID) {
      void createOAuthNonce("google").then((nonce) => { if (active) setGoogleNonce(nonce) }).catch(() => {})
    }
    void AppleAuthentication.isAvailableAsync().then((available) => { if (active) setAppleAvailable(available) }).catch(() => {})
    return () => { active = false }
  }, [])

  async function loadMemberships() {
    try {
      setMemberships(await getBuyerMemberships())
    } catch (err) {
      setError(err instanceof Error ? err.message : "تعذر تحميل انضماماتك.")
    }
  }

  async function loadCart() {
    try {
      setCartItems(await getBuyerCart())
    } catch {
      setCartItems([])
    }
  }

  async function loadLoyalty() {
    try {
      const loyalty = await getBuyerLoyalty()
      setLoyaltyPoints(loyalty.points)
    } catch {
      setLoyaltyPoints(0)
    }
  }

  async function enablePushNotifications() {
    if (!Device.isDevice) return
    let permission = await Notifications.getPermissionsAsync()
    if (permission.status !== "granted") permission = await Notifications.requestPermissionsAsync()
    if (permission.status !== "granted") return
    if (Platform.OS === "android") {
      await Notifications.setNotificationChannelAsync("default", {
        name: "إشعارات نشتري سوا",
        importance: Notifications.AndroidImportance.MAX,
      })
    }
    const easProjectId = process.env.EXPO_PUBLIC_EAS_PROJECT_ID ||
      (Constants as unknown as { easConfig?: { projectId?: string } }).easConfig?.projectId ||
      (Constants.expoConfig?.extra as { eas?: { projectId?: string } } | undefined)?.eas?.projectId
    if (!easProjectId) return
    const token = (await Notifications.getExpoPushTokenAsync({ projectId: easProjectId })).data
    await registerPushDevice(token, Platform.OS === "ios" ? "ios" : "android")
    setPushToken(token)
  }

  async function addDealToCart(deal: Deal) {
    try {
      const current = cartItems.find((item) => item.dealId === deal.id)?.quantity ?? 0
      await saveCartItem(deal.id, current + 1)
      await loadCart()
      Alert.alert("اتضاف للسلة", `${deal.name} · الكمية ${current + 1}`)
    } catch (err) {
      Alert.alert("تعذر الإضافة للسلة", err instanceof Error ? err.message : "حاول مرة أخرى.")
    }
  }

  async function saveWhatsAppPreferences() {
    try {
      await updateWhatsAppConsent(whatsappPhone.trim(), whatsappAllowed)
      setAccount((current) => current ? { ...current, phone: whatsappPhone.trim(), whatsappOptIn: whatsappAllowed } : current)
      Alert.alert("تم حفظ التفضيل", whatsappAllowed ? "سنستخدم رقمك لإشعارات واتساب التي وافقت عليها." : "تم إيقاف إشعارات واتساب.")
    } catch (err) {
      Alert.alert("تعذر حفظ التفضيل", err instanceof Error ? err.message : "تحقق من رقم الهاتف.")
    }
  }

  async function submitAuth() {
    if (authMode === "register" && platformSettings.buyer_registration_enabled === false) {
      Alert.alert("التسجيل متوقف مؤقتًا", "أوقف المسؤول إنشاء حسابات جديدة مؤقتًا.")
      return
    }
    if (authMode === "register" && whatsappOptIn && !phone.trim()) {
      Alert.alert("رقم الهاتف مطلوب", "أدخل رقمًا دوليًا حتى نرسل لك رسائل واتساب التي وافقت عليها.")
      return
    }
    setAuthBusy(true)
    try {
      const user = authMode === "register"
        ? await registerBuyer(fullName.trim(), email.trim().toLowerCase(), password, phone.trim(), whatsappOptIn)
        : await loginAccount(email.trim().toLowerCase(), password)
      if (user.role !== "buyer") {
        await logoutAccount()
        Alert.alert("حساب غير مخصص للمشتري", "استخدم لوحة الويب لإدارة حساب البائع أو الإدارة.")
        return
      }
      setAccount(user)
      setPassword("")
      setPhone("")
      setWhatsappOptIn(false)
      setError("")
    } catch (err) {
      const status = (err as Error & { status?: number }).status
      const message = status === 404
        ? "تسجيل الدخول يحتاج نشر تحديث الخادم أولًا. لم يتم إنشاء الحساب."
        : err instanceof Error && err.message === "invalid_credentials"
          ? "البريد أو كلمة المرور غير صحيحين."
        : err instanceof Error && err.message === "email_already_registered"
            ? "هذا البريد مسجل بالفعل. سجّل الدخول بدلًا من إنشاء حساب جديد."
        : err instanceof Error && err.message === "buyer_registration_paused"
              ? "تسجيل المشترين متوقف مؤقتًا."
              : err instanceof Error && err.message === "valid_phone_required_for_whatsapp"
                ? "أدخل رقمًا دوليًا صحيحًا قبل الموافقة على رسائل واتساب."
            : err instanceof Error && err.message.includes("password_must_be")
              ? "كلمة المرور يجب أن تكون 12 حرفًا على الأقل."
              : "تعذر إكمال الطلب. تحقق من الاتصال وحاول مرة أخرى."
      Alert.alert("تعذر الدخول", message)
    } finally {
      setAuthBusy(false)
    }
  }

  async function acceptSocialAccount(user: Account) {
    if (user.role !== "buyer") {
      await logoutAccount()
      Alert.alert("حساب غير مخصص للمشتري", "استخدم لوحة الويب لإدارة حساب البائع أو الإدارة.")
      return
    }
    setAccount(user)
    setPassword("")
    setError("")
  }

  async function signInWithGoogle() {
    if (authBusy) return
    if (!googleRequest || !googleNonce) {
      Alert.alert("Google غير جاهز", "تحقق من إعداد معرّف Google في إعدادات التطبيق والخادم.")
      return
    }
    setAuthBusy(true)
    try {
      const result = await promptGoogle()
      if (result.type === "success") {
        const idToken = result.params.id_token
        if (!idToken) throw new Error("identity_token_missing")
        await acceptSocialAccount(await loginWithSocial("google", idToken, googleNonce))
      }
    } catch (err) {
      Alert.alert("تعذر الدخول بـ Google", socialError(err))
    } finally {
      try { setGoogleNonce(await createOAuthNonce("google")) } catch { setGoogleNonce("") }
      setAuthBusy(false)
    }
  }

  async function signInWithApple() {
    if (authBusy) return
    setAuthBusy(true)
    try {
      const nonce = await createOAuthNonce("apple")
      const appleNonce = await Crypto.digestStringAsync(Crypto.CryptoDigestAlgorithm.SHA256, nonce)
      const credential = await AppleAuthentication.signInAsync({
        requestedScopes: [AppleAuthentication.AppleAuthenticationScope.FULL_NAME, AppleAuthentication.AppleAuthenticationScope.EMAIL],
        nonce: appleNonce,
      })
      if (!credential.identityToken) throw new Error("identity_token_missing")
      const name = [credential.fullName?.givenName, credential.fullName?.familyName].filter(Boolean).join(" ")
      await acceptSocialAccount(await loginWithSocial("apple", credential.identityToken, nonce, name))
    } catch (err) {
      if ((err as Error & { code?: string }).code !== "ERR_REQUEST_CANCELED") Alert.alert("تعذر الدخول بـ Apple", socialError(err))
    } finally {
      setAuthBusy(false)
    }
  }

  async function signOut() {
    if (pushToken) await unregisterPushDevice(pushToken).catch(() => {})
    await logoutAccount()
    setAccount(null)
    setDeals([])
    setError("")
    setMemberships([])
    setCartItems([])
    setPushToken("")
    setLoyaltyPoints(0)
    setActiveTab("deals")
  }

  function join(deal: Deal | CartItem, quantity = 1) {
    if (platformSettings.orders_enabled === false) {
      Alert.alert("الطلبات متوقفة مؤقتًا", "أوقف المسؤول استقبال الطلبات مؤقتًا.")
      return
    }
    const canPickup = deal.acceptsPickup && platformSettings.self_pickup_enabled !== false
    const canShip = deal.acceptsShipping && platformSettings.merchant_shipping_enabled !== false
    if (!canPickup && !canShip) {
      Alert.alert("التسليم غير متاح", "طرق التسليم لهذا العرض متوقفة حاليًا.")
      return
    }
    setJoinQuantity(String(quantity))
    setFulfillmentMethod(canPickup ? "self_pickup" : "merchant_shipping")
    setShippingAddress("")
    setCouponCode("")
    setLoyaltyPointsToUse("")
    setSelectedDeal(deal)
  }

  async function confirmJoin() {
    const deal = selectedDeal
    const quantity = Number(joinQuantity)
    const maximum = deal?.availableQuantity ?? (deal?.maxQuantity == null ? 1_000_000 : deal.maxQuantity - deal.committedQuantity)
    if (!deal || !Number.isSafeInteger(quantity) || quantity < 1 || quantity > maximum) {
      Alert.alert("راجع الكمية", `أدخل كمية من 1 إلى ${Math.max(0, maximum)}.`)
      return
    }
    if (fulfillmentMethod === "merchant_shipping" && (!deal.acceptsShipping || platformSettings.merchant_shipping_enabled === false || shippingAddress.trim().length < 8)) {
      Alert.alert("أكمل عنوان التوصيل", "أدخل عنوانًا واضحًا لا يقل عن 8 أحرف.")
      return
    }
    if (fulfillmentMethod === "self_pickup" && (!deal.acceptsPickup || platformSettings.self_pickup_enabled === false)) {
      Alert.alert("الاستلام غير متاح", "اختر الشحن من التاجر لهذا العرض.")
      return
    }
    setJoinBusy(true)
    try {
      const points = Number(loyaltyPointsToUse || 0)
      if (!Number.isSafeInteger(points) || points < 0 || points > loyaltyPoints) {
        Alert.alert("راجع النقاط", `رصيدك المتاح ${loyaltyPoints} نقطة.`)
        return
      }
      const result = await requestToJoin(deal.id, quantity, fulfillmentMethod, shippingAddress.trim(), couponCode.trim(), points)
      setSelectedDeal(null)
      await loadMemberships()
      await loadLoyalty()
      await deleteCartItem(deal.id).catch(() => {})
      await loadCart()
      Alert.alert("اتسجل انضمامك", result.message === "payment_provider_not_connected" ? "الدفع لسه مش متوصل؛ مفيش فلوس هتتخصم." : "تم حفظ الكمية على حسابك.")
    } catch (err) {
      Alert.alert("محتاجين نكمّل خطوة", err instanceof Error ? err.message : "جرّب تاني كمان شوية.")
    } finally {
      setJoinBusy(false)
    }
  }

  async function cancelOrder(item: Membership) {
    try {
      await cancelMembership(item.membershipId)
      await loadMemberships()
      Alert.alert("تم الإلغاء", "أُلغي انضمامك للمجموعة.")
    } catch (err) {
      Alert.alert("تعذر الإلغاء", err instanceof Error ? err.message : "حاول مرة أخرى.")
    }
  }

  function share(deal: Deal) {
    const message = `يلا نشتري سوا ${deal.name} بسعر ${deal.price.toFixed(2)} جنيه! فاضل ${Math.max(0, deal.moq - deal.committedQuantity)} وحدة ونوصل لسعر الجملة.`
    void Linking.openURL(`https://wa.me/?text=${encodeURIComponent(message)}`)
  }

  if (!authReady) return <SafeAreaView style={styles.safe}><View style={styles.center}><ActivityIndicator color={ORANGE} size="large" /><Text style={styles.emptyText}>بنتأكد من حسابك...</Text></View></SafeAreaView>

  if (!account) return (
    <SafeAreaView style={styles.authSafe}>
      <StatusBar barStyle="dark-content" backgroundColor="#F5F5F5" />
      <ScrollView contentContainerStyle={styles.authContent} keyboardShouldPersistTaps="handled">
        <View style={styles.authBrand}><Text style={styles.brandMark}>↗</Text><Text style={styles.authBrandText}>نشتري سوا</Text></View>
        <Text style={styles.authEyebrow}>سوق جماعي من قلب الحي</Text>
        <Text style={styles.authTitle}>{authMode === "register" ? "حسابك يبدأ من هنا" : "أهلاً بيك"}</Text>
        <Text style={styles.authIntro}>سجّل بحساب مشتري لتصفح الصفقات والانضمام بالكميات التي تناسبك.</Text>
        {authMode === "register" && <TextInput value={fullName} onChangeText={setFullName} style={styles.authInput} placeholder="الاسم بالكامل" placeholderTextColor="#849088" autoComplete="name" textAlign="right" />}
        {authMode === "register" && <TextInput value={phone} onChangeText={setPhone} style={styles.authInput} placeholder="رقم الهاتف (اختياري)" placeholderTextColor="#849088" keyboardType="phone-pad" autoComplete="tel" textAlign="right" />}
        {authMode === "register" && <View style={styles.consentRow}><Text style={styles.consentText}>أوافق على رسائل واتساب عن حسابي وطلباتي وعروض جديدة.</Text><Switch value={whatsappOptIn} onValueChange={setWhatsappOptIn} trackColor={{ true: GREEN }} /></View>}
        <TextInput value={email} onChangeText={setEmail} style={styles.authInput} placeholder="البريد الإلكتروني" placeholderTextColor="#849088" keyboardType="email-address" autoCapitalize="none" autoComplete="email" textAlign="right" />
        <TextInput value={password} onChangeText={setPassword} style={styles.authInput} placeholder="كلمة المرور (12 حرفًا على الأقل)" placeholderTextColor="#849088" secureTextEntry autoComplete={authMode === "register" ? "new-password" : "current-password"} textAlign="right" />
        <TouchableOpacity disabled={authBusy || !email || !password || (authMode === "register" && (!fullName.trim() || platformSettings.buyer_registration_enabled === false))} onPress={() => void submitAuth()} style={[styles.authButton, (authBusy || !email || !password || (authMode === "register" && (!fullName.trim() || platformSettings.buyer_registration_enabled === false))) && styles.disabledButton]}>
          {authBusy ? <ActivityIndicator color="white" /> : <Text style={styles.authButtonText}>{authMode === "register" ? "إنشاء حساب مشتري" : "تسجيل الدخول"}</Text>}
        </TouchableOpacity>
        {authMode === "login" && socialAuthConfig.google && (GOOGLE_IOS_CLIENT_ID || GOOGLE_ANDROID_CLIENT_ID || GOOGLE_WEB_CLIENT_ID) && <TouchableOpacity disabled={authBusy || !googleRequest || !googleNonce} onPress={() => void signInWithGoogle()} style={[styles.googleButton, (authBusy || !googleRequest || !googleNonce) && styles.disabledButton]}><Text style={styles.googleMark}>G</Text><Text style={styles.googleButtonText}>متابعة باستخدام Google</Text></TouchableOpacity>}
        {authMode === "login" && socialAuthConfig.apple && Platform.OS === "ios" && appleAvailable && <AppleAuthentication.AppleAuthenticationButton buttonType={AppleAuthentication.AppleAuthenticationButtonType.SIGN_IN} buttonStyle={AppleAuthentication.AppleAuthenticationButtonStyle.BLACK} cornerRadius={12} style={styles.appleButton} onPress={() => void signInWithApple()} />}
        <TouchableOpacity onPress={() => setAuthMode(authMode === "register" ? "login" : "register")} style={styles.authToggle}>
          <Text style={styles.authToggleText}>{authMode === "register" ? "لديك حساب؟ سجّل الدخول" : "مستخدم جديد؟ أنشئ حسابًا"}</Text>
        </TouchableOpacity>
        <Text style={styles.authNote}>تظهر خيارات Google وApple بعد تفعيلها في إعدادات التطبيق والخادم. كلمة المرور لا تُحفظ في التطبيق.</Text>
      </ScrollView>
    </SafeAreaView>
  )

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="dark-content" backgroundColor="#F5F5F5" />
      <View style={styles.header}>
        <View><Text style={styles.greeting}>أهلاً {account.name.split(" ")[0]} 👋</Text><Text style={styles.location}>{locationMessage}</Text></View>
        <View style={styles.brand}><Text style={styles.brandMark}>↗</Text></View>
      </View>
      <View style={styles.titleRow}><View><Text style={styles.title}>نشتريها سوا</Text><Text style={styles.subtitle}>كل ما العدد يكمل، التوفير يزيد 🤝</Text></View><TouchableOpacity onPress={() => void signOut()}><Text style={styles.logout}>خروج</Text></TouchableOpacity></View>
      {error ? <View style={styles.center}><Text style={styles.emptyIcon}>📍</Text><Text style={styles.emptyTitle}>مش قادرين نجيب البيانات</Text><Text style={styles.emptyText}>{error}</Text><TouchableOpacity onPress={() => { setError(""); void loadDeals(); void loadMemberships() }} style={styles.retry}><Text style={styles.joinText}>جرّب تاني</Text></TouchableOpacity></View> : activeTab === "deals" && loading ? <View style={styles.center}><ActivityIndicator color={ORANGE} size="large" /><Text style={styles.emptyText}>بنلفّ على صفقات قريبة منك...</Text></View> : activeTab === "deals" ? (
        <FlatList
          data={deals}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.list}
          refreshing={loading}
          onRefresh={() => void loadDeals()}
          ListEmptyComponent={<View style={styles.center}><Text style={styles.emptyIcon}>🧭</Text><Text style={styles.emptyTitle}>مفيش صفقات جنبك دلوقتي</Text><Text style={styles.emptyText}>هنعرضلك الجديد أول ما يفتح في منطقتك.</Text></View>}
          renderItem={({ item }) => {
            const progress = Math.min(100, Math.round(item.committedQuantity / item.moq * 100))
            const savings = Math.max(0, Math.round((1 - item.price / item.retailPrice) * 100))
            return <View style={styles.card}>
              <View style={styles.productRow}>
                <View style={styles.art}><Text style={styles.emoji}>{item.emoji}</Text></View>
                <View style={styles.productInfo}><Text style={styles.category}>{item.category} · {item.distanceKm.toFixed(1)} كم</Text><Text style={styles.name}>{item.name}</Text><Text style={styles.pickup}>📍 استلام من نقطة قريبة</Text></View>
                <Text style={styles.discount}>وفر {savings}٪</Text>
              </View>
              <View style={styles.priceRow}><Text style={styles.price}>{item.price.toFixed(2)} <Text style={styles.currency}>جنيه / {item.unit}</Text></Text><Text style={styles.oldPrice}>{item.retailPrice.toFixed(2)} جنيه</Text></View>
              <View style={styles.progressLabels}><Text style={styles.progressCount}>{item.committedQuantity} من {item.moq} وحدة</Text><Text style={styles.progressHint}>لسعر الجملة</Text></View>
              <View style={styles.track}><View style={[styles.fill, { width: `${progress}%` }]} /></View>
              <View style={styles.availabilityRow}><Text style={styles.availability}>المتاح من التاجر: {item.availableQuantity} {item.unit}</Text><Text style={styles.availability}>{[item.acceptsShipping && platformSettings.merchant_shipping_enabled !== false && "شحن", item.acceptsPickup && platformSettings.self_pickup_enabled !== false && "استلام ذاتي"].filter(Boolean).join(" · ")}</Text></View>
              <View style={styles.footer}><View><Text style={styles.timerLabel}>العرض هيخلص كمان</Text><Countdown endsAt={item.endsAt} /></View><View style={styles.actions}><TouchableOpacity style={styles.shareButton} onPress={() => share(item)}><Text style={styles.shareText}>شارك</Text></TouchableOpacity><TouchableOpacity disabled={item.availableQuantity < 1 || platformSettings.orders_enabled === false} style={[styles.cartButton, (item.availableQuantity < 1 || platformSettings.orders_enabled === false) && styles.disabledButton]} onPress={() => void addDealToCart(item)}><Text style={styles.cartButtonText}>+ للسلة</Text></TouchableOpacity><TouchableOpacity disabled={item.availableQuantity < 1 || platformSettings.orders_enabled === false || (!(item.acceptsShipping && platformSettings.merchant_shipping_enabled !== false) && !(item.acceptsPickup && platformSettings.self_pickup_enabled !== false))} style={[styles.joinButton, (item.availableQuantity < 1 || platformSettings.orders_enabled === false) && styles.disabledButton]} onPress={() => void join(item)}><Text style={styles.joinText}>{platformSettings.orders_enabled === false ? "الطلبات متوقفة" : item.availableQuantity < 1 ? "نفدت الكمية" : "اطلب"}</Text></TouchableOpacity></View></View>
            </View>
          }}
        />
      ) : activeTab === "cart" ? (
        <FlatList
          data={cartItems}
          keyExtractor={(item) => item.dealId}
          contentContainerStyle={styles.list}
          onRefresh={() => void loadCart()}
          refreshing={false}
          ListHeaderComponent={<Text style={styles.ordersTitle}>اختياراتك قبل تأكيد الطلب</Text>}
          ListEmptyComponent={<View style={styles.center}><Text style={styles.emptyIcon}>🛒</Text><Text style={styles.emptyTitle}>السلة فاضية</Text><Text style={styles.emptyText}>أضف منتجًا من الصفقات القريبة وسيظهر هنا.</Text></View>}
          renderItem={({ item }) => <View style={styles.card}><View style={styles.productRow}><View style={styles.art}><Text style={styles.emoji}>{item.emoji}</Text></View><View style={styles.productInfo}><Text style={styles.name}>{item.name}</Text><Text style={styles.category}>{item.quantity} {item.unit} · {item.price.toFixed(2)} جنيه للوحدة</Text><Text style={styles.pickup}>المتاح الآن: {item.availableQuantity} · {item.status === "active" ? "العرض متاح" : "العرض غير متاح"}</Text></View></View><View style={styles.priceRow}><Text style={styles.progressCount}>إجمالي تقريبي {(item.price * item.quantity).toFixed(2)} جنيه</Text><View style={styles.actions}><TouchableOpacity disabled={item.status !== "active" || item.availableQuantity < item.quantity} style={[styles.joinButton, (item.status !== "active" || item.availableQuantity < item.quantity) && styles.disabledButton]} onPress={() => join(item, item.quantity)}><Text style={styles.joinText}>تأكيد الطلب</Text></TouchableOpacity><TouchableOpacity style={styles.cancelButton} onPress={() => void deleteCartItem(item.dealId).then(loadCart)}><Text style={styles.cancelText}>حذف</Text></TouchableOpacity></View></View></View>}
        />
      ) : activeTab === "orders" ? (
        <FlatList
          data={memberships}
          keyExtractor={(item) => item.membershipId}
          contentContainerStyle={styles.list}
          onRefresh={() => void loadMemberships()}
          refreshing={false}
          ListHeaderComponent={<Text style={styles.ordersTitle}>مجموعاتي المحفوظة على حسابك</Text>}
          ListEmptyComponent={<View style={styles.center}><Text style={styles.emptyIcon}>🧺</Text><Text style={styles.emptyTitle}>لسه ما انضمتش لمجموعة</Text><Text style={styles.emptyText}>اختار صفقة من الرئيسية وابدأ بكمية تناسبك.</Text></View>}
          renderItem={({ item }) => <View style={styles.card}><View style={styles.productRow}><View style={styles.art}><Text style={styles.emoji}>{item.emoji}</Text></View><View style={styles.productInfo}><Text style={styles.name}>{item.name}</Text><Text style={styles.category}>{item.quantity} {item.unit} · {item.unitPrice.toFixed(2)} جنيه للوحدة</Text><Text style={styles.pickup}>{item.status === "pending_payment" ? "طلب محفوظ دون دفع" : item.status} · {fulfillmentLabel(item.fulfillmentStatus)}</Text><Text style={styles.pickup}>{item.fulfillmentMethod === "merchant_shipping" ? `عنوان التوصيل: ${item.shippingAddress || ""}` : `بدون توصيل · ${item.pickupLabel || "نقطة التاجر"}`}</Text>{item.carrierName || item.trackingNumber ? <Text style={styles.pickup}>{item.carrierName || "شركة الشحن"} · تتبع {item.trackingNumber || "لم يضف بعد"}</Text> : null}{item.trackingUrl ? <TouchableOpacity onPress={() => void Linking.openURL(item.trackingUrl!)}><Text style={styles.trackLink}>فتح تتبع الشحنة ←</Text></TouchableOpacity> : null}</View></View><View style={styles.priceRow}><Text style={styles.progressCount}>الإجمالي {item.total.toFixed(2)} جنيه</Text>{item.status === "pending_payment" && <TouchableOpacity style={styles.cancelButton} onPress={() => void cancelOrder(item)}><Text style={styles.cancelText}>إلغاء الطلب</Text></TouchableOpacity>}</View></View>}
        />
      ) : (
        <ScrollView contentContainerStyle={styles.accountPanel}><Text style={styles.emptyIcon}>👤</Text><Text style={styles.emptyTitle}>{account.name}</Text><Text style={styles.emptyText}>{account.email}</Text><Text style={styles.accountNote}>حساب مشتري · كلمة المرور غير محفوظة في التطبيق.</Text><TextInput value={whatsappPhone} onChangeText={setWhatsappPhone} style={styles.authInput} placeholder="رقم الهاتف +201..." placeholderTextColor="#849088" keyboardType="phone-pad" textAlign="right" /><View style={styles.consentRow}><Text style={styles.consentText}>موافق على رسائل واتساب للطلبات والعروض</Text><Switch value={whatsappAllowed} onValueChange={setWhatsappAllowed} trackColor={{ true: GREEN }} /></View><TouchableOpacity onPress={() => void saveWhatsAppPreferences()} style={styles.retry}><Text style={styles.joinText}>حفظ تفضيلات واتساب</Text></TouchableOpacity><TouchableOpacity onPress={() => void signOut()} style={styles.retry}><Text style={styles.joinText}>تسجيل الخروج</Text></TouchableOpacity></ScrollView>
      )}
      <View style={styles.tabs}>
        <TouchableOpacity onPress={() => setActiveTab("deals")}><Text style={activeTab === "deals" ? styles.activeTab : styles.tab}>⌂  الرئيسية</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => { setActiveTab("cart"); void loadCart() }}><Text style={activeTab === "cart" ? styles.activeTab : styles.tab}>🛒 السلة {cartItems.length ? `(${cartItems.length})` : ""}</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => { setActiveTab("orders"); void loadMemberships() }}><Text style={activeTab === "orders" ? styles.activeTab : styles.tab}>♡  مجموعاتي</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => setActiveTab("account")}><Text style={activeTab === "account" ? styles.activeTab : styles.tab}>♙  حسابي</Text></TouchableOpacity>
      </View>
      <Modal visible={selectedDeal !== null} transparent animationType="slide" onRequestClose={() => setSelectedDeal(null)}>
        <View style={styles.modalBackdrop}><ScrollView style={styles.joinScroll} contentContainerStyle={styles.joinModal} keyboardShouldPersistTaps="handled">
          <Text style={styles.authEyebrow}>طلب كمية من التاجر</Text>
          <Text style={styles.emptyTitle}>{selectedDeal?.name}</Text>
          <Text style={styles.emptyText}>{selectedDeal?.price.toFixed(2)} جنيه للوحدة · الدفع غير متصل</Text>
          <TextInput value={joinQuantity} onChangeText={setJoinQuantity} style={styles.authInput} keyboardType="number-pad" maxLength={7} placeholder="الكمية" textAlign="right" />
          {platformSettings.coupons_enabled && <TextInput value={couponCode} onChangeText={setCouponCode} style={styles.authInput} autoCapitalize="characters" maxLength={40} placeholder="كود الخصم (اختياري)" textAlign="right" />}
          {platformSettings.loyalty_enabled && <><Text style={styles.authNote}>رصيدك: {loyaltyPoints} نقطة</Text><TextInput value={loyaltyPointsToUse} onChangeText={setLoyaltyPointsToUse} style={styles.authInput} keyboardType="number-pad" maxLength={7} placeholder="نقاط تستخدمها (اختياري)" textAlign="right" /></>}
          <Text style={styles.authNote}>المتاح الآن: {selectedDeal?.availableQuantity} {selectedDeal?.unit}</Text>
          {selectedDeal?.acceptsShipping && platformSettings.merchant_shipping_enabled !== false && selectedDeal.acceptsPickup && platformSettings.self_pickup_enabled !== false ? <View style={styles.fulfillmentChoices}>
            <TouchableOpacity onPress={() => setFulfillmentMethod("self_pickup")} style={[styles.fulfillmentChoice, fulfillmentMethod === "self_pickup" && styles.fulfillmentSelected]}><Text style={styles.fulfillmentChoiceTitle}>بدون توصيل</Text><Text style={styles.fulfillmentChoiceText}>استلام من نقطة التاجر</Text></TouchableOpacity>
            <TouchableOpacity onPress={() => setFulfillmentMethod("merchant_shipping")} style={[styles.fulfillmentChoice, fulfillmentMethod === "merchant_shipping" && styles.fulfillmentSelected]}><Text style={styles.fulfillmentChoiceTitle}>شحن من التاجر</Text><Text style={styles.fulfillmentChoiceText}>أدخل عنوان التوصيل</Text></TouchableOpacity>
          </View> : <Text style={styles.authNote}>{fulfillmentMethod === "merchant_shipping" ? "التوصيل من التاجر" : "بدون توصيل · استلام ذاتي"}</Text>}
          {fulfillmentMethod === "merchant_shipping" && <TextInput value={shippingAddress} onChangeText={setShippingAddress} style={[styles.authInput, styles.addressInput]} multiline maxLength={500} placeholder="المنطقة، الشارع، وعلامة مميزة" textAlign="right" />}
          {fulfillmentMethod === "self_pickup" && <Text style={styles.authNote}>نقطة الاستلام: {selectedDeal?.pickupLabel || "عنوان التاجر"}</Text>}
          <Text style={styles.authNote}>{fulfillmentMethod === "merchant_shipping" ? "معاينة فقط: لا يوجد دفع أو شحن حقيقي. استخدم عنوانًا تجريبيًا، فالطلب يحفظ العنوان على الخدمة." : "سيتم حجز الكمية للمتابعة فقط. لا يوجد دفع أو خصم."}</Text>
          <TouchableOpacity disabled={joinBusy || (selectedDeal?.availableQuantity ?? 0) < 1} onPress={() => void confirmJoin()} style={[styles.authButton, joinBusy && styles.disabledButton]}>{joinBusy ? <ActivityIndicator color="white" /> : <Text style={styles.authButtonText}>حفظ الطلب</Text>}</TouchableOpacity>
          <TouchableOpacity onPress={() => setSelectedDeal(null)} style={styles.authToggle}><Text style={styles.authToggleText}>رجوع</Text></TouchableOpacity>
        </ScrollView></View>
      </Modal>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#F5F5F5" },
  authSafe: { flex: 1, backgroundColor: "#F5F5F5" },
  authContent: { flexGrow: 1, justifyContent: "center", padding: 24, paddingTop: 40, paddingBottom: 40 },
  authBrand: { flexDirection: "row", alignItems: "center", justifyContent: "flex-end", gap: 10, marginBottom: 38 },
  authBrandText: { color: GREEN, fontWeight: "900", fontSize: 20 },
  authEyebrow: { color: GREEN, fontSize: 12, fontWeight: "800", textAlign: "right", marginBottom: 8 },
  authTitle: { color: "#202925", fontSize: 30, fontWeight: "900", textAlign: "right" },
  authIntro: { color: "#68736E", fontSize: 13, lineHeight: 22, textAlign: "right", marginTop: 9, marginBottom: 22 },
  authInput: { width: "100%", minHeight: 50, paddingHorizontal: 13, borderWidth: 1, borderColor: "#E1E6E0", borderRadius: 12, backgroundColor: "white", color: "#202925", marginTop: 10, fontSize: 14 },
  authButton: { minHeight: 49, backgroundColor: ORANGE, borderRadius: 12, alignItems: "center", justifyContent: "center", marginTop: 14, paddingHorizontal: 15 },
  authButtonText: { color: "white", fontSize: 13, fontWeight: "800" },
  googleButton: { minHeight: 48, borderWidth: 1, borderColor: "#D6DCD7", borderRadius: 12, backgroundColor: "white", alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 10, marginTop: 10 },
  googleMark: { color: "#4285F4", fontSize: 16, fontWeight: "900" },
  googleButtonText: { color: "#26312B", fontSize: 12, fontWeight: "800" },
  appleButton: { width: "100%", height: 48, marginTop: 10 },
  disabledButton: { opacity: 0.55 },
  authToggle: { alignItems: "center", paddingVertical: 13 },
  authToggleText: { color: GREEN, fontSize: 12, fontWeight: "800" },
  authNote: { color: "#77827A", fontSize: 10, lineHeight: 17, textAlign: "right", marginTop: 15 },
  consentRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 10, marginTop: 12 },
  consentText: { flex: 1, textAlign: "right", color: "#59645E", fontSize: 10, lineHeight: 16 },
  accountPanel: { flexGrow: 1, alignItems: "center", justifyContent: "center", padding: 24 },
  ordersTitle: { textAlign: "right", color: "#59645E", fontSize: 13, fontWeight: "700", marginBottom: 12 },
  logout: { color: GREEN, fontSize: 11, fontWeight: "800", padding: 8 },
  cancelButton: { borderWidth: 1, borderColor: "#EDC8BF", backgroundColor: "#F9E9E5", borderRadius: 8, paddingHorizontal: 9, paddingVertical: 6 },
  cancelText: { color: "#B44B3E", fontSize: 9, fontWeight: "800" },
  modalBackdrop: { flex: 1, justifyContent: "flex-end", backgroundColor: "#15241DBB" },
  joinScroll: { maxHeight: "88%", width: "100%" },
  joinModal: { backgroundColor: "#F8F7F2", borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, paddingBottom: 34 },
  fulfillmentChoices: { flexDirection: "row", gap: 8, marginTop: 13 },
  fulfillmentChoice: { flex: 1, padding: 11, borderWidth: 1, borderColor: "#E1E6E0", borderRadius: 12, backgroundColor: "white" },
  fulfillmentSelected: { borderColor: GREEN, backgroundColor: "#E9F2E9" },
  fulfillmentChoiceTitle: { textAlign: "right", color: "#202925", fontSize: 11, fontWeight: "800" },
  fulfillmentChoiceText: { textAlign: "right", color: "#68736E", fontSize: 9, marginTop: 4 },
  addressInput: { minHeight: 85, textAlignVertical: "top", paddingTop: 12 },
  availabilityRow: { flexDirection: "row", justifyContent: "space-between", gap: 7, marginTop: 8 },
  availability: { color: "#68736E", fontSize: 9, textAlign: "right", flexShrink: 1 },
  trackLink: { color: GREEN, fontSize: 10, fontWeight: "800", marginTop: 6, textAlign: "right" },
  header: { paddingHorizontal: 20, paddingTop: 12, paddingBottom: 20, flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  greeting: { fontSize: 24, fontWeight: "800", color: "#202925", textAlign: "right" },
  location: { fontSize: 12, color: "#68736E", marginTop: 3, textAlign: "right" },
  brand: { width: 38, height: 38, borderRadius: 13, backgroundColor: ORANGE, alignItems: "center", justifyContent: "center" },
  brandMark: { fontSize: 22, color: "white", fontWeight: "800" },
  titleRow: { paddingHorizontal: 20, paddingBottom: 13, flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  title: { fontSize: 20, fontWeight: "800", color: "#202925", textAlign: "right" },
  subtitle: { fontSize: 11, color: "#707B75", marginTop: 2, textAlign: "right" },
  live: { color: GREEN, backgroundColor: "#E7F2E7", paddingHorizontal: 9, paddingVertical: 5, borderRadius: 10, fontSize: 10, fontWeight: "700" },
  list: { paddingHorizontal: 14, paddingBottom: 14 },
  card: { backgroundColor: "white", borderRadius: 18, padding: 14, marginBottom: 11, borderWidth: 1, borderColor: "#ECEEEC" },
  productRow: { flexDirection: "row", alignItems: "center", gap: 9 },
  art: { width: 57, height: 57, backgroundColor: "#FFF4E9", borderRadius: 14, justifyContent: "center", alignItems: "center" },
  emoji: { fontSize: 31 },
  productInfo: { flex: 1, alignItems: "flex-end" },
  category: { color: GREEN, fontSize: 10, fontWeight: "700" },
  name: { color: "#202925", fontSize: 15, fontWeight: "800", marginTop: 2, textAlign: "right" },
  pickup: { color: "#727C76", fontSize: 9, marginTop: 3, textAlign: "right" },
  discount: { alignSelf: "flex-start", backgroundColor: "#FFF0E3", color: "#B65000", borderRadius: 7, paddingHorizontal: 6, paddingVertical: 4, fontSize: 9, fontWeight: "800" },
  priceRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "baseline", marginTop: 13 },
  price: { color: ORANGE, fontSize: 20, fontWeight: "800" },
  currency: { color: "#59645E", fontSize: 10, fontWeight: "500" },
  oldPrice: { color: "#929A95", fontSize: 10, textDecorationLine: "line-through" },
  progressLabels: { flexDirection: "row", justifyContent: "space-between", marginTop: 10 },
  progressCount: { color: "#36433B", fontSize: 10, fontWeight: "800" },
  progressHint: { color: "#7A847E", fontSize: 9 },
  track: { height: 7, borderRadius: 6, backgroundColor: "#EDF0ED", overflow: "hidden", marginTop: 5 },
  fill: { height: "100%", borderRadius: 6, backgroundColor: ORANGE },
  footer: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-end", marginTop: 12 },
  timerLabel: { color: "#7A847E", fontSize: 8 },
  timer: { color: "#202925", fontSize: 11, fontWeight: "800", fontVariant: ["tabular-nums"] },
  actions: { flexDirection: "row", gap: 6 },
  shareButton: { paddingHorizontal: 10, paddingVertical: 8, borderRadius: 9, borderWidth: 1, borderColor: "#E3E9E3" },
  shareText: { color: GREEN, fontSize: 10, fontWeight: "700" },
  cartButton: { backgroundColor: GREEN, paddingHorizontal: 10, paddingVertical: 8, borderRadius: 9 },
  cartButtonText: { color: "white", fontSize: 10, fontWeight: "800" },
  joinButton: { backgroundColor: ORANGE, paddingHorizontal: 12, paddingVertical: 8, borderRadius: 9 },
  retry: { marginTop: 14, backgroundColor: ORANGE, paddingVertical: 9, paddingHorizontal: 18, borderRadius: 10 },
  joinText: { color: "white", fontSize: 10, fontWeight: "800" },
  center: { flex: 1, alignItems: "center", justifyContent: "center", padding: 30 },
  emptyIcon: { fontSize: 35 },
  emptyTitle: { fontSize: 16, fontWeight: "800", color: "#202925", marginTop: 9, textAlign: "center" },
  emptyText: { fontSize: 12, color: "#707B75", textAlign: "center", marginTop: 6 },
  tabs: { height: 56, backgroundColor: "white", borderTopWidth: 1, borderTopColor: "#E8EAE8", flexDirection: "row", justifyContent: "space-around", alignItems: "center" },
  tab: { fontSize: 10, color: "#89918C" },
  activeTab: { fontSize: 10, color: ORANGE, fontWeight: "800" },
})
