import assert from "node:assert/strict"
import test from "node:test"
import { enqueuePushNotification, enqueueWhatsAppEvent } from "../src/notifications.mjs"
import { startNotificationDispatcher } from "../src/notification-dispatcher.mjs"

const buyerId = "65000000-0000-4000-8000-000000000001"
const webhookSecret = "a-webhook-secret-long-enough-for-this-test"

test("WhatsApp events contain contact details only after explicit opt-in", async () => {
  const calls = []
  const client = { async query(sql, params) {
    calls.push({ sql, params })
    if (sql.includes("SELECT id, full_name, phone, whatsapp_opt_in")) {
      return { rows: [{ id: buyerId, full_name: "Buyer", phone: "+201012345678", whatsapp_opt_in: true }] }
    }
    return { rows: [], rowCount: 1 }
  } }

  const queued = await enqueueWhatsAppEvent(client, "customer.registered", buyerId, { source: "email" })
  assert.equal(queued, true)
  assert.equal(calls.length, 2)
  assert.equal(calls[1].params[1], "customer.registered")
  assert.deepEqual(JSON.parse(calls[1].params[2]), {
    customer: { id: buyerId, name: "Buyer", phone: "+201012345678" },
    source: "email",
  })
})

test("WhatsApp opt-out prevents an outbound contact event", async () => {
  const calls = []
  const client = { async query(sql) {
    calls.push(sql)
    return { rows: [{ id: buyerId, full_name: "Buyer", phone: "+201012345678", whatsapp_opt_in: false }] }
  } }

  const queued = await enqueueWhatsAppEvent(client, "cart.item_added", buyerId, { item: { dealId: "deal" } })
  assert.equal(queued, false)
  assert.equal(calls.length, 1)
})

test("push events are queued only for a user with a registered device", async () => {
  let call
  const client = { async query(sql, params) { call = { sql, params }; return { rows: [], rowCount: 0 } } }
  await enqueuePushNotification(client, buyerId, "order.created", {
    title: "Order saved",
    body: "Payment is not connected.",
    data: { orderId: "66000000-0000-4000-8000-000000000001" },
  })
  assert.match(call.sql, /EXISTS \(SELECT 1 FROM push_devices/)
  assert.equal(call.params[1], "order.created")
  assert.equal(JSON.parse(call.params[2]).title, "Order saved")
})

test("notification dispatcher reads n8n settings dynamically and sends the configured secret", async () => {
  let n8nClaimed = false
  let sentRequest
  let dispatcherError
  let finishDelivery
  const delivered = new Promise((resolve) => { finishDelivery = resolve })
  const event = { id: "event-1", event_type: "customer.registered", payload: { customer: { id: buyerId } }, attempts: 1 }
  const pool = {
    async connect() {
      return {
        async query(sql, params = []) {
          if (["BEGIN", "COMMIT", "ROLLBACK"].includes(sql)) return { rows: [], rowCount: 0 }
          if (sql.includes("UPDATE notification_outbox") && sql.includes("RETURNING id")) {
            if (params[1] === "n8n" && !n8nClaimed) {
              n8nClaimed = true
              return { rows: [event], rowCount: 1 }
            }
            return { rows: [], rowCount: 0 }
          }
          throw new Error(`Unexpected query: ${sql}`)
        },
        release() {},
      }
    },
    async query(sql) {
      if (sql.includes("SET sent_at")) return { rows: [], rowCount: 1 }
      throw new Error(`Unexpected query: ${sql}`)
    },
  }
  const stop = startNotificationDispatcher(pool, { error({ error }) { dispatcherError = error } }, {
    intervalMs: 60_000,
    async getWebhookConfig() { return { webhookUrl: "https://n8n.example.org/hook", webhookSecret } },
    async fetcher(url, options) {
      sentRequest = { url, options }
      finishDelivery()
      return { ok: true }
    },
  })
  let timeout
  await Promise.race([delivered, new Promise((_, reject) => { timeout = setTimeout(() => reject(new Error(`delivery_timeout:${dispatcherError?.message ?? "no_dispatch_error"}`)), 1000) })])
  clearTimeout(timeout)
  await stop()
  assert.equal(sentRequest.url, "https://n8n.example.org/hook")
  assert.equal(sentRequest.options.headers.Authorization, `Bearer ${webhookSecret}`)
  assert.equal(JSON.parse(sentRequest.options.body).event, "customer.registered")
})
