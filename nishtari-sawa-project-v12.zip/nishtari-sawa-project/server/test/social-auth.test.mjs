import assert from "node:assert/strict"
import { generateKeyPairSync, sign } from "node:crypto"
import test from "node:test"
import { hashNonce, verifyProviderToken } from "../src/social-auth.mjs"

const now = 1_700_000_000_000
const nonce = "nonce-value-long-enough-for-a-secure-test"
const googlePair = generateKeyPairSync("rsa", { modulusLength: 2048 })
const googleJwk = { ...googlePair.publicKey.export({ format: "jwk" }), kid: "google-test-key", use: "sig", alg: "RS256" }
const applePair = generateKeyPairSync("ec", { namedCurve: "prime256v1" })
const appleJwk = { ...applePair.publicKey.export({ format: "jwk" }), kid: "apple-test-key", use: "sig", alg: "ES256" }

function makeToken(provider, claims, algorithm = provider === "google" ? "RS256" : "ES256") {
  const header = Buffer.from(JSON.stringify({ alg: algorithm, kid: provider === "google" ? googleJwk.kid : appleJwk.kid, typ: "JWT" })).toString("base64url")
  const payload = Buffer.from(JSON.stringify(claims)).toString("base64url")
  const input = `${header}.${payload}`
  const signature = algorithm === "ES256"
    ? sign("sha256", Buffer.from(input), { key: applePair.privateKey, dsaEncoding: "ieee-p1363" })
    : sign("RSA-SHA256", Buffer.from(input), googlePair.privateKey)
  return `${input}.${signature.toString("base64url")}`
}

function claims(provider, overrides = {}) {
  return {
    iss: provider === "google" ? "https://accounts.google.com" : "https://appleid.apple.com",
    aud: provider === "google" ? "google-client" : "apple-client",
    sub: `${provider}-subject-123`,
    iat: now / 1000,
    exp: now / 1000 + 300,
    nonce,
    email: " Buyer@Example.Test ",
    email_verified: true,
    name: "Test Buyer",
    ...overrides,
  }
}

function fetchKeys(jwk) {
  return async () => ({
    ok: true,
    headers: { get: () => "max-age=300" },
    json: async () => ({ keys: [jwk] }),
  })
}

test("Google RS256 identity verifies and normalizes profile fields", async () => {
  const identity = await verifyProviderToken({
    provider: "google",
    idToken: makeToken("google", claims("google")),
    nonce,
    audiences: ["google-client"],
  }, { fetcher: fetchKeys(googleJwk), now })

  assert.deepEqual(identity, {
    provider: "google",
    subject: "google-subject-123",
    email: "buyer@example.test",
    emailVerified: true,
    name: "Test Buyer",
  })
})

test("Google rejects altered identity claims, replay nonce, and ambiguous audience", async () => {
  const fetcher = fetchKeys(googleJwk)
  const verifyToken = (overrides) => verifyProviderToken({
    provider: "google",
    idToken: makeToken("google", claims("google", overrides)),
    nonce,
    audiences: ["google-client"],
  }, { fetcher, now })

  await assert.rejects(verifyToken({ aud: "other-client" }), { statusCode: 401 })
  await assert.rejects(verifyToken({ nonce: "different-nonce-value-long-enough" }), { statusCode: 401 })
  await assert.rejects(verifyToken({ aud: ["google-client", "other-client"] }), { statusCode: 401 })
  await assert.doesNotReject(verifyToken({ aud: ["google-client", "other-client"], azp: "google-client" }))
  await assert.rejects(verifyToken({ azp: "other-client" }), { statusCode: 401 })
  await assert.rejects(verifyToken({ exp: now / 1000 - 1 }), { statusCode: 401 })
  await assert.rejects(verifyToken({ nbf: now / 1000 + 1 }), { statusCode: 401 })
})

test("Apple ES256 identity verifies", async () => {
  const appleClaims = claims("apple", { nonce: hashNonce(nonce) })
  const identity = await verifyProviderToken({
    provider: "apple",
    idToken: makeToken("apple", appleClaims),
    nonce,
    audiences: ["apple-client"],
  }, { fetcher: fetchKeys(appleJwk), now })

  assert.equal(identity.provider, "apple")
  assert.equal(identity.subject, "apple-subject-123")
  assert.equal(identity.email, "buyer@example.test")
  assert.equal(identity.emailVerified, true)
})

test("social verification fails closed for missing configuration and malformed claims", async () => {
  await assert.rejects(verifyProviderToken({ provider: "google", idToken: "", nonce, audiences: [] }, { now }), { statusCode: 503 })
  const malformed = `${Buffer.from(JSON.stringify({ alg: "RS256", kid: googleJwk.kid })).toString("base64url")}.${Buffer.from("null").toString("base64url")}.bad`
  await assert.rejects(verifyProviderToken({ provider: "google", idToken: malformed, nonce, audiences: ["google-client"] }, { now }), { statusCode: 401 })
})
