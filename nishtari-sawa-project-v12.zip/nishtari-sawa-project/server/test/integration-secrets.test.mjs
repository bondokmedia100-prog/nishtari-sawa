import assert from "node:assert/strict"
import test from "node:test"
import { decryptWebhookSecret, encryptWebhookSecret, isValidWebhookSecret, isValidWebhookUrl } from "../src/integration-secrets.mjs"

const masterSecret = "a-long-test-secret-that-is-not-used-in-production"
const webhookSecret = "a-webhook-secret-long-enough-for-this-test"

test("n8n webhook secrets are encrypted and decrypt only with the same key", () => {
  const envelope = encryptWebhookSecret(webhookSecret, masterSecret)
  assert.equal(envelope.includes(webhookSecret), false)
  assert.equal(decryptWebhookSecret(envelope, masterSecret), webhookSecret)
  assert.throws(() => decryptWebhookSecret(envelope, `${masterSecret}-different`))
})

test("webhook URLs require public HTTPS destinations", () => {
  assert.equal(isValidWebhookUrl("https://n8n.example.org/webhook/abc"), true)
  assert.equal(isValidWebhookUrl("http://n8n.example.org/webhook/abc"), false)
  assert.equal(isValidWebhookUrl("https://127.0.0.1/webhook/abc"), false)
  assert.equal(isValidWebhookUrl("https://192.168.1.10/webhook/abc"), false)
  assert.equal(isValidWebhookUrl("https://localhost/webhook/abc"), false)
  assert.equal(isValidWebhookUrl("https://user:pass@n8n.example.org/webhook/abc"), false)
})

test("webhook secrets have a minimum size and reject control characters", () => {
  assert.equal(isValidWebhookSecret(webhookSecret), true)
  assert.equal(isValidWebhookSecret("too-short"), false)
  assert.equal(isValidWebhookSecret(`${webhookSecret}\n`), false)
})
