import assert from "node:assert/strict"
import { createHmac } from "node:crypto"
import test from "node:test"
import { hashPassword, issueToken, requireRole, verifyPassword, verifyToken } from "../src/auth.mjs"

const secret = "test-secret-with-at-least-thirty-two-characters"
const user = {
  id: "65000000-0000-4000-8000-000000000001",
  full_name: "Test Buyer",
  email: "buyer@example.test",
  role: "buyer",
}

test("password hashes verify without storing the original password", async () => {
  const credentials = await hashPassword("correct-horse-battery-staple")
  assert.notEqual(credentials.hash, "correct-horse-battery-staple")
  assert.equal(await verifyPassword("correct-horse-battery-staple", credentials.salt, credentials.hash), true)
  assert.equal(await verifyPassword("wrong-password", credentials.salt, credentials.hash), false)
  assert.equal(await verifyPassword("anything", credentials.salt, "invalid"), false)
})

test("signed access tokens preserve identity and enforce roles", () => {
  const token = issueToken(user, secret)
  const identity = verifyToken(`Bearer ${token}`, secret)
  assert.equal(identity.sub, user.id)
  assert.equal(requireRole(identity, "buyer").role, "buyer")
  assert.throws(() => requireRole(identity, "admin"), { statusCode: 403 })
  const alteredToken = `${token.slice(0, -1)}${token.at(-1) === "a" ? "b" : "a"}`
  assert.throws(() => verifyToken(`Bearer ${alteredToken}`, secret), { statusCode: 401 })
  assert.throws(() => verifyToken(token, secret), { statusCode: 401 })
})

test("expired tokens are rejected even with a valid signature", () => {
  const token = issueToken(user, secret)
  const [header, payload] = token.split(".")
  const expired = Buffer.from(JSON.stringify({ ...JSON.parse(Buffer.from(payload, "base64url")), exp: 1 })).toString("base64url")
  const signature = createHmac("sha256", secret).update(`${header}.${expired}`).digest("base64url")
  assert.throws(() => verifyToken(`Bearer ${header}.${expired}.${signature}`, secret), { statusCode: 401 })
})
