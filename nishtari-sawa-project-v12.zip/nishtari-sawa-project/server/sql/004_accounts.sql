ALTER TABLE users
  ADD COLUMN email TEXT,
  ADD COLUMN password_salt TEXT,
  ADD COLUMN password_hash TEXT,
  ADD COLUMN is_active BOOLEAN NOT NULL DEFAULT true,
  ADD CONSTRAINT users_password_material_pair
    CHECK ((password_hash IS NULL) = (password_salt IS NULL));

CREATE UNIQUE INDEX users_email_lower_uidx
  ON users (lower(email))
  WHERE email IS NOT NULL;

CREATE INDEX deals_supplier_status_idx ON deals (supplier_id, status, created_at DESC);
