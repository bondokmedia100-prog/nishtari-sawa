ALTER TABLE app_settings DROP CONSTRAINT app_settings_setting_key_check;
ALTER TABLE app_settings ADD CONSTRAINT app_settings_setting_key_check CHECK (setting_key IN (
  'buyer_registration_enabled',
  'seller_registration_enabled',
  'deal_creation_enabled',
  'orders_enabled',
  'merchant_shipping_enabled',
  'self_pickup_enabled',
  'maintenance_mode',
  'platform_subsidies_enabled',
  'coupons_enabled',
  'loyalty_enabled'
));

INSERT INTO app_settings (setting_key, enabled) VALUES
  ('platform_subsidies_enabled', false),
  ('coupons_enabled', false),
  ('loyalty_enabled', false)
ON CONFLICT (setting_key) DO NOTHING;

CREATE TABLE program_profile (
  singleton BOOLEAN PRIMARY KEY DEFAULT true CHECK (singleton),
  brand_name TEXT NOT NULL DEFAULT 'نشتري سوا' CHECK (length(trim(brand_name)) BETWEEN 2 AND 60),
  brand_tagline TEXT NOT NULL DEFAULT 'سوق جماعي من قلب الحي' CHECK (length(trim(brand_tagline)) BETWEEN 2 AND 120),
  brand_description TEXT NOT NULL DEFAULT 'كوّن مجموعة مع جيرانك ووصلوا لسعر أفضل.' CHECK (length(trim(brand_description)) BETWEEN 2 AND 300),
  loyalty_earn_points_per_egp INTEGER NOT NULL DEFAULT 1 CHECK (loyalty_earn_points_per_egp BETWEEN 0 AND 100),
  loyalty_points_per_egp INTEGER NOT NULL DEFAULT 100 CHECK (loyalty_points_per_egp BETWEEN 1 AND 100000),
  updated_by UUID REFERENCES users(id) ON DELETE SET NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

INSERT INTO program_profile (singleton) VALUES (true) ON CONFLICT (singleton) DO NOTHING;

ALTER TABLE deals
  ADD COLUMN platform_subsidy_minor BIGINT NOT NULL DEFAULT 0
    CHECK (platform_subsidy_minor >= 0 AND platform_subsidy_minor < unit_price_minor);

ALTER TABLE deal_memberships
  ADD COLUMN buyer_total_minor BIGINT,
  ADD COLUMN platform_subsidy_minor BIGINT NOT NULL DEFAULT 0 CHECK (platform_subsidy_minor >= 0),
  ADD COLUMN coupon_discount_minor BIGINT NOT NULL DEFAULT 0 CHECK (coupon_discount_minor >= 0),
  ADD COLUMN loyalty_points_used INTEGER NOT NULL DEFAULT 0 CHECK (loyalty_points_used >= 0),
  ADD COLUMN loyalty_discount_minor BIGINT NOT NULL DEFAULT 0 CHECK (loyalty_discount_minor >= 0);

UPDATE deal_memberships SET buyer_total_minor = unit_price_minor * quantity;
ALTER TABLE deal_memberships
  ALTER COLUMN buyer_total_minor SET NOT NULL,
  ADD CONSTRAINT membership_buyer_total_positive CHECK (buyer_total_minor > 0);

CREATE TABLE coupons (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code TEXT NOT NULL UNIQUE CHECK (code = upper(trim(code)) AND code ~ '^[A-Z0-9_-]{3,40}$'),
  discount_type TEXT NOT NULL CHECK (discount_type IN ('fixed', 'percent')),
  value INTEGER NOT NULL CHECK (value > 0 AND (discount_type <> 'percent' OR value <= 9000)),
  min_order_minor BIGINT NOT NULL DEFAULT 0 CHECK (min_order_minor >= 0),
  max_discount_minor BIGINT CHECK (max_discount_minor IS NULL OR max_discount_minor > 0),
  usage_limit INTEGER CHECK (usage_limit IS NULL OR usage_limit > 0),
  per_user_limit INTEGER NOT NULL DEFAULT 1 CHECK (per_user_limit BETWEEN 1 AND 1000),
  starts_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  ends_at TIMESTAMPTZ,
  enabled BOOLEAN NOT NULL DEFAULT true,
  created_by UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (ends_at IS NULL OR ends_at > starts_at)
);

CREATE TABLE coupon_redemptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  coupon_id UUID NOT NULL REFERENCES coupons(id),
  buyer_id UUID NOT NULL REFERENCES users(id),
  membership_id UUID NOT NULL UNIQUE REFERENCES deal_memberships(id) ON DELETE CASCADE,
  discount_minor BIGINT NOT NULL CHECK (discount_minor > 0),
  status TEXT NOT NULL DEFAULT 'reserved' CHECK (status IN ('reserved', 'redeemed', 'released')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX coupon_redemptions_usage_idx ON coupon_redemptions (coupon_id, buyer_id, status);

CREATE TABLE loyalty_ledger (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  buyer_id UUID NOT NULL REFERENCES users(id),
  membership_id UUID REFERENCES deal_memberships(id) ON DELETE SET NULL,
  entry_type TEXT NOT NULL CHECK (entry_type IN ('earned', 'redeemed', 'admin_adjustment')),
  points INTEGER NOT NULL CHECK (points <> 0),
  status TEXT NOT NULL DEFAULT 'confirmed' CHECK (status IN ('pending', 'confirmed', 'reversed')),
  note TEXT,
  created_by UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX loyalty_membership_entry_uidx
  ON loyalty_ledger (membership_id, entry_type)
  WHERE membership_id IS NOT NULL;
CREATE INDEX loyalty_buyer_history_idx ON loyalty_ledger (buyer_id, created_at DESC);
