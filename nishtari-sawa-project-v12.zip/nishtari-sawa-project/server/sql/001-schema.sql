CREATE SCHEMA IF NOT EXISTS extensions;
CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA extensions;
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TYPE user_role AS ENUM ('buyer', 'leader', 'supplier', 'admin');
CREATE TYPE deal_status AS ENUM ('draft', 'active', 'funded', 'expired', 'cancelled');
CREATE TYPE membership_status AS ENUM ('pending_payment', 'held', 'refunded', 'handed_over', 'cancelled');

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name TEXT NOT NULL,
  phone TEXT UNIQUE,
  role user_role NOT NULL DEFAULT 'buyer',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE supplier_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE REFERENCES users(id),
  business_name TEXT NOT NULL,
  verified_at TIMESTAMPTZ
);

CREATE TABLE leader_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE REFERENCES users(id),
  pickup_location extensions.GEOGRAPHY(Point, 4326) NOT NULL,
  pickup_label TEXT NOT NULL
);

CREATE TABLE products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  supplier_id UUID NOT NULL REFERENCES supplier_profiles(id),
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  emoji TEXT NOT NULL DEFAULT '🛍️',
  unit_label TEXT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT true
);

CREATE TABLE deals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id UUID NOT NULL REFERENCES products(id),
  supplier_id UUID NOT NULL REFERENCES supplier_profiles(id),
  leader_id UUID NOT NULL REFERENCES leader_profiles(id),
  unit_price_minor BIGINT NOT NULL CHECK (unit_price_minor > 0),
  retail_price_minor BIGINT NOT NULL CHECK (retail_price_minor > 0),
  currency CHAR(3) NOT NULL DEFAULT 'EGP',
  moq INTEGER NOT NULL CHECK (moq > 0),
  max_quantity INTEGER CHECK (max_quantity IS NULL OR max_quantity >= moq),
  starts_at TIMESTAMPTZ NOT NULL,
  ends_at TIMESTAMPTZ NOT NULL CHECK (ends_at > starts_at),
  status deal_status NOT NULL DEFAULT 'draft',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE deal_memberships (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  deal_id UUID NOT NULL REFERENCES deals(id),
  buyer_id UUID NOT NULL REFERENCES users(id),
  quantity INTEGER NOT NULL CHECK (quantity > 0),
  unit_price_minor BIGINT NOT NULL CHECK (unit_price_minor > 0),
  status membership_status NOT NULL DEFAULT 'pending_payment',
  request_key TEXT NOT NULL,
  reservation_expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (deal_id, buyer_id),
  UNIQUE (buyer_id, request_key)
);

CREATE TABLE payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  membership_id UUID NOT NULL UNIQUE REFERENCES deal_memberships(id),
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0),
  currency CHAR(3) NOT NULL DEFAULT 'EGP',
  status TEXT NOT NULL DEFAULT 'not_configured',
  provider_reference TEXT UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX leader_profiles_location_gix ON leader_profiles USING GIST (pickup_location);
CREATE INDEX deals_active_deadline_idx ON deals (status, ends_at);
CREATE INDEX memberships_deal_status_idx ON deal_memberships (deal_id, status);
