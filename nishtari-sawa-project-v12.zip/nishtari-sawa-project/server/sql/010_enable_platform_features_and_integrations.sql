INSERT INTO app_settings (setting_key, enabled) VALUES
  ('buyer_registration_enabled', true),
  ('seller_registration_enabled', true),
  ('deal_creation_enabled', true),
  ('orders_enabled', true),
  ('merchant_shipping_enabled', true),
  ('self_pickup_enabled', true),
  ('maintenance_mode', false),
  ('platform_subsidies_enabled', true),
  ('coupons_enabled', true),
  ('loyalty_enabled', true)
ON CONFLICT (setting_key) DO UPDATE
SET enabled = EXCLUDED.enabled, updated_at = now();

CREATE TABLE integration_settings (
  integration_key TEXT PRIMARY KEY CHECK (integration_key = 'n8n'),
  webhook_url TEXT,
  webhook_secret_ciphertext TEXT,
  enabled BOOLEAN NOT NULL,
  updated_by UUID REFERENCES users(id) ON DELETE SET NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (
    (enabled AND webhook_url IS NOT NULL AND webhook_secret_ciphertext IS NOT NULL) OR
    (NOT enabled AND webhook_url IS NULL AND webhook_secret_ciphertext IS NULL)
  )
);
