ALTER TABLE deals
  ADD COLUMN stock_quantity INTEGER NOT NULL DEFAULT 1000000
    CHECK (stock_quantity BETWEEN 0 AND 1000000),
  ADD COLUMN accepts_shipping BOOLEAN NOT NULL DEFAULT true,
  ADD COLUMN accepts_pickup BOOLEAN NOT NULL DEFAULT true;

UPDATE deals
SET stock_quantity = LEAST(COALESCE(max_quantity, 1000000), 1000000);

ALTER TABLE deal_memberships
  ADD COLUMN fulfillment_method TEXT NOT NULL DEFAULT 'self_pickup'
    CHECK (fulfillment_method IN ('merchant_shipping', 'self_pickup')),
  ADD COLUMN shipping_address TEXT,
  ADD COLUMN fulfillment_status TEXT NOT NULL DEFAULT 'not_started'
    CHECK (fulfillment_status IN ('not_started', 'preparing', 'shipped', 'in_transit', 'ready_for_pickup', 'delivered', 'picked_up')),
  ADD COLUMN carrier_name TEXT,
  ADD COLUMN tracking_number TEXT,
  ADD COLUMN tracking_url TEXT,
  ADD COLUMN fulfillment_note TEXT,
  ADD COLUMN fulfillment_updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  ADD CONSTRAINT membership_shipping_address_required
    CHECK (fulfillment_method <> 'merchant_shipping' OR
      (shipping_address IS NOT NULL AND length(trim(shipping_address)) BETWEEN 8 AND 500));

CREATE TABLE app_settings (
  setting_key TEXT PRIMARY KEY CHECK (setting_key IN (
    'buyer_registration_enabled',
    'seller_registration_enabled',
    'deal_creation_enabled',
    'orders_enabled',
    'merchant_shipping_enabled',
    'self_pickup_enabled',
    'maintenance_mode'
  )),
  enabled BOOLEAN NOT NULL,
  updated_by UUID REFERENCES users(id) ON DELETE SET NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

INSERT INTO app_settings (setting_key, enabled) VALUES
  ('buyer_registration_enabled', true),
  ('seller_registration_enabled', true),
  ('deal_creation_enabled', true),
  ('orders_enabled', true),
  ('merchant_shipping_enabled', true),
  ('self_pickup_enabled', true),
  ('maintenance_mode', false)
ON CONFLICT (setting_key) DO NOTHING;

CREATE INDEX memberships_fulfillment_status_idx
  ON deal_memberships (fulfillment_status, created_at DESC);
