UPDATE deals
SET status = 'active',
    starts_at = now() - interval '1 hour',
    ends_at = now() + interval '90 days'
WHERE id IN (
  '50000000-0000-4000-8000-000000000001',
  '50000000-0000-4000-8000-000000000002',
  '50000000-0000-4000-8000-000000000003'
);
