ALTER TABLE deals
  ADD COLUMN pickup_location extensions.GEOGRAPHY(Point, 4326),
  ADD COLUMN pickup_label TEXT;

UPDATE deals d
SET pickup_location = lp.pickup_location,
    pickup_label = lp.pickup_label
FROM leader_profiles lp
WHERE lp.id = d.leader_id;

ALTER TABLE deals
  ALTER COLUMN pickup_location SET NOT NULL,
  ALTER COLUMN pickup_label SET NOT NULL;

CREATE INDEX deals_pickup_location_gix ON deals USING GIST (pickup_location);
