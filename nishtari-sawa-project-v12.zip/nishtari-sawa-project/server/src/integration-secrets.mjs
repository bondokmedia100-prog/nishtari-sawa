import { createCipheriv, createDecipheriv, hkdfSync, randomBytes } from "node:crypto"
import { isIP } from "node:net"

const KEY_INFO = Buffer.from("nishtari-sawa:n8n-webhook-secret:v1")
const KEY_SALT = Buffer.from("nishtari-sawa:integration-secrets:v1")
const SECRET_AAD = Buffer.from("n8n-webhook-secret:v1")

export function isValidWebhookUrl(value) {
  if (typeof value !== "string" || value.length > 2048) return false
  try {
    const url = new URL(value)
    if (url.protocol !== "https:" || url.username || url.password || url.hash) return false
    const hostname = url.hostname.replace(/^\[|\]$/g, "").replace(/\.$/, "").toLowerCase()
    const ipVersion = isIP(hostname)
    if (ipVersion === 4 && !isPublicIPv4(hostname)) return false
    if (ipVersion === 6) return false
    if (!ipVersion && (!hostname.includes(".") || /\.(localhost|local|internal|test|invalid|example)$/.test(hostname))) return false
    return true
  } catch {
    return false
  }
}

export function isValidWebhookSecret(value) {
  return typeof value === "string" && value.length >= 32 && value.length <= 4096 && !/[\u0000-\u001f\u007f]/.test(value)
}

export function encryptWebhookSecret(secret, masterSecret) {
  const iv = randomBytes(12)
  const cipher = createCipheriv("aes-256-gcm", encryptionKey(masterSecret), iv)
  cipher.setAAD(SECRET_AAD)
  const encrypted = Buffer.concat([cipher.update(secret, "utf8"), cipher.final()])
  return ["v1", iv.toString("base64url"), cipher.getAuthTag().toString("base64url"), encrypted.toString("base64url")].join(".")
}

export function decryptWebhookSecret(envelope, masterSecret) {
  const [version, encodedIv, encodedTag, encodedCiphertext, ...extra] = String(envelope ?? "").split(".")
  if (version !== "v1" || !encodedIv || !encodedTag || !encodedCiphertext || extra.length) throw new Error("invalid_n8n_secret_envelope")
  const iv = Buffer.from(encodedIv, "base64url")
  const tag = Buffer.from(encodedTag, "base64url")
  if (iv.length !== 12 || tag.length !== 16) throw new Error("invalid_n8n_secret_envelope")
  const decipher = createDecipheriv("aes-256-gcm", encryptionKey(masterSecret), iv)
  decipher.setAAD(SECRET_AAD)
  decipher.setAuthTag(tag)
  return Buffer.concat([decipher.update(Buffer.from(encodedCiphertext, "base64url")), decipher.final()]).toString("utf8")
}

function encryptionKey(masterSecret) {
  if (typeof masterSecret !== "string" || masterSecret.length < 32) throw new Error("invalid_integration_encryption_key")
  return Buffer.from(hkdfSync("sha256", Buffer.from(masterSecret), KEY_SALT, KEY_INFO, 32))
}

function isPublicIPv4(hostname) {
  const octets = hostname.split(".").map(Number)
  if (octets.length !== 4 || octets.some((part) => !Number.isInteger(part) || part < 0 || part > 255)) return false
  const address = octets.reduce((value, part) => value * 256 + part, 0)
  const blocked = [
    ["0.0.0.0", 8], ["10.0.0.0", 8], ["100.64.0.0", 10], ["127.0.0.0", 8],
    ["169.254.0.0", 16], ["172.16.0.0", 12], ["192.0.0.0", 24], ["192.0.2.0", 24],
    ["192.88.99.0", 24], ["192.168.0.0", 16], ["198.18.0.0", 15], ["198.51.100.0", 24],
    ["203.0.113.0", 24], ["224.0.0.0", 4], ["240.0.0.0", 4],
  ]
  return !blocked.some(([network, bits]) => {
    const networkAddress = network.split(".").map(Number).reduce((value, part) => value * 256 + part, 0)
    return Math.floor(address / 2 ** (32 - bits)) === Math.floor(networkAddress / 2 ** (32 - bits))
  })
}
