export async function enqueueWhatsAppEvent(client, eventType, userId, data) {
  const { rows } = await client.query(
    `SELECT id, full_name, phone, whatsapp_opt_in
     FROM users WHERE id = $1 AND is_active AND role = 'buyer'`,
    [userId],
  )
  const customer = rows[0]
  if (!customer?.whatsapp_opt_in || !customer.phone) return false
  await client.query(
    `INSERT INTO notification_outbox (channel, user_id, event_type, payload)
     VALUES ('n8n', $1, $2, $3::jsonb)`,
    [customer.id, eventType, JSON.stringify({
      customer: { id: customer.id, name: customer.full_name, phone: customer.phone },
      ...data,
    })],
  )
  return true
}

export async function enqueuePushNotification(client, userId, eventType, { title, body, data = {} }) {
  await client.query(
    `INSERT INTO notification_outbox (channel, user_id, event_type, payload)
     SELECT 'push', $1, $2, $3::jsonb
     WHERE EXISTS (SELECT 1 FROM push_devices WHERE user_id = $1)`,
    [userId, eventType, JSON.stringify({ title, body, data })],
  )
}

export async function enqueuePublishedDeal(client, deal) {
  const data = {
    deal: {
      id: deal.id,
      name: deal.name,
      category: deal.category,
      price: Number(deal.unit_price_minor) / 100,
      unit: deal.unit,
      endsAt: deal.ends_at,
    },
  }
  const n8nData = JSON.stringify(data)
  await client.query(
    `INSERT INTO notification_outbox (channel, user_id, event_type, payload)
     SELECT 'n8n', u.id, 'deal.published',
            $1::jsonb || jsonb_build_object('customer', jsonb_build_object(
              'id', u.id, 'name', u.full_name, 'phone', u.phone
            ))
     FROM users u
     WHERE u.role = 'buyer' AND u.is_active AND u.whatsapp_opt_in AND u.phone IS NOT NULL`,
    [n8nData],
  )
  await client.query(
    `INSERT INTO notification_outbox (channel, user_id, event_type, payload)
     SELECT 'push', u.id, 'deal.published', $1::jsonb
     FROM users u
     WHERE u.role = 'buyer' AND u.is_active
       AND EXISTS (SELECT 1 FROM push_devices d WHERE d.user_id = u.id)`,
    [JSON.stringify({ title: "عرض جديد", body: `${deal.name} متاح الآن ضمن عروض المجموعة.`, data: { dealId: deal.id } })],
  )
}
