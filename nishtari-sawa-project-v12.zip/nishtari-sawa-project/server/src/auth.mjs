import { createHmac, randomBytes, scrypt as scryptCallback, timingSafeEqual } from "node:crypto"
import { promisify } from "node:util"

const scrypt = promisify(scryptCallback)
const roles = new Set(["buyer", "supplier", "leader", "admin"])
const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i

export async function hashPassword(password) {
  const salt = randomBytes(16).toString("hex")
  const hash = await scrypt(password, salt, 64, { N: 16384, maxmem: 64 * 1024 * 1024 })
  return { salt, hash: hash.toString("hex") }
}

export async function verifyPassword(password, salt, expectedHex) {
  if (!salt || !expectedHex || !/^[0-9a-f]{128}$/i.test(expectedHex)) return false
  const actual = await scrypt(password, salt, 64, { N: 16384, maxmem: 64 * 1024 * 1024 })
  const expected = Buffer.from(expectedHex, "hex")
  return actual.length === expected.length && timingSafeEqual(actual, expected)
}

export function issueToken(user, secret) {
  const issuedAt = Math.floor(Date.now() / 1000)
  const header = Buffer.from(JSON.stringify({ alg: "HS256", typ: "JWT" })).toString("base64url")
  const payload = Buffer.from(JSON.stringify({
    sub: user.id,
    role: user.role,
    iat: issuedAt,
    exp: issuedAt + 7 * 24 * 60 * 60,
  })).toString("base64url")
  const signature = createHmac("sha256", secret).update(`${header}.${payload}`).digest("base64url")
  return `${header}.${payload}.${signature}`
}

export function verifyToken(authorization, secret) {
  if (typeof authorization !== "string" || !authorization.startsWith("Bearer ")) {
    throw httpError(401, "unauthorized")
  }
  const parts = authorization.slice(7).split(".")
  if (parts.length !== 3) throw httpError(401, "unauthorized")
  const [encodedHeader, encodedPayload, signature] = parts
  const expected = createHmac("sha256", secret).update(`${encodedHeader}.${encodedPayload}`).digest()
  let supplied
  try { supplied = Buffer.from(signature, "base64url") } catch { supplied = Buffer.alloc(0) }
  if (supplied.length !== expected.length || supplied.toString("base64url") !== signature || !timingSafeEqual(supplied, expected)) {
    throw httpError(401, "unauthorized")
  }
  try {
    const header = JSON.parse(Buffer.from(encodedHeader, "base64url").toString())
    const payload = JSON.parse(Buffer.from(encodedPayload, "base64url").toString())
    if (header.alg !== "HS256" || !uuidPattern.test(payload.sub) || !roles.has(payload.role) ||
        !Number.isFinite(payload.exp) || payload.exp <= Date.now() / 1000) throw new Error()
    return payload
  } catch {
    throw httpError(401, "unauthorized")
  }
}

export function requireRole(identity, ...allowed) {
  if (!allowed.includes(identity.role)) throw httpError(403, "forbidden")
  return identity
}

export function publicUser(user) {
  const result = { id: user.id, name: user.full_name, email: user.email, role: user.role }
  if ("phone" in user) result.phone = user.phone
  if ("whatsapp_opt_in" in user) result.whatsappOptIn = user.whatsapp_opt_in
  return result
}

export function httpError(statusCode, code) {
  return Object.assign(new Error(code), { statusCode, code })
}
