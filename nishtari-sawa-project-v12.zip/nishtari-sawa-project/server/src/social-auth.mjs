import { createHash, createPublicKey, timingSafeEqual, verify } from "node:crypto"
import { httpError } from "./auth.mjs"

const providerSettings = {
  google: {
    issuer: new Set(["https://accounts.google.com", "accounts.google.com"]),
    jwksUrl: "https://www.googleapis.com/oauth2/v3/certs",
    algorithms: new Set(["RS256"]),
  },
  apple: {
    issuer: new Set(["https://appleid.apple.com"]),
    jwksUrl: "https://appleid.apple.com/auth/keys",
    algorithms: new Set(["RS256", "ES256"]),
  },
}

const keyCache = new Map()

export function hashNonce(nonce) {
  return createHash("sha256").update(nonce).digest("hex")
}

export async function verifyProviderToken({ provider, idToken, nonce, audiences }, { fetcher = fetch, now = Date.now() } = {}) {
  const settings = providerSettings[provider]
  if (!settings || !Array.isArray(audiences) || audiences.length === 0) throw httpError(503, "identity_provider_not_configured")
  if (typeof idToken !== "string" || idToken.length > 20_000 || typeof nonce !== "string" || nonce.length < 22 || nonce.length > 256) {
    throw httpError(401, "invalid_identity_token")
  }

  let header, claims
  const parts = idToken.split(".")
  if (parts.length !== 3) throw httpError(401, "invalid_identity_token")
  try {
    header = JSON.parse(Buffer.from(parts[0], "base64url").toString("utf8"))
    claims = JSON.parse(Buffer.from(parts[1], "base64url").toString("utf8"))
  } catch {
    throw httpError(401, "invalid_identity_token")
  }
  if (!header || typeof header !== "object" || Array.isArray(header) ||
      !claims || typeof claims !== "object" || Array.isArray(claims)) {
    throw httpError(401, "invalid_identity_token")
  }
  if (!settings.algorithms.has(header.alg) || typeof header.kid !== "string" || !settings.issuer.has(claims.iss)) {
    throw httpError(401, "invalid_identity_token")
  }

  const keys = await getKeys(provider, settings.jwksUrl, fetcher, now)
  const jwk = keys.find((key) => key.kid === header.kid && key.use !== "enc" &&
    (!key.alg || key.alg === header.alg) && (!key.key_ops || key.key_ops.includes("verify")))
  if (!jwk) throw httpError(401, "invalid_identity_token")
  let signatureValid = false
  try {
    const key = createPublicKey({ key: jwk, format: "jwk" })
    const signingInput = Buffer.from(`${parts[0]}.${parts[1]}`)
    const signature = Buffer.from(parts[2], "base64url")
    signatureValid = header.alg === "ES256"
      ? verify("sha256", signingInput, { key, dsaEncoding: "ieee-p1363" }, signature)
      : verify("RSA-SHA256", signingInput, key, signature)
  } catch {
    signatureValid = false
  }
  if (!signatureValid) throw httpError(401, "invalid_identity_token")

  const tokenAudiences = Array.isArray(claims.aud) ? claims.aud : [claims.aud]
  const acceptedAudiences = new Set(audiences)
  const hasAudience = tokenAudiences.some((audience) => acceptedAudiences.has(audience))
  const issuedAt = Number(claims.iat) * 1000
  const expiresAt = Number(claims.exp) * 1000
  const notBefore = claims.nbf === undefined ? null : Number(claims.nbf) * 1000
  const nonceHash = hashNonce(nonce)
  const tokenNonce = typeof claims.nonce === "string" ? Buffer.from(claims.nonce) : Buffer.alloc(0)
  const expectedNonces = [Buffer.from(nonce), Buffer.from(nonceHash)]
  const nonceMatches = expectedNonces.some((expected) => tokenNonce.length === expected.length && timingSafeEqual(tokenNonce, expected))
  const authorizedPartyValid = claims.azp === undefined
    ? tokenAudiences.length === 1
    : acceptedAudiences.has(claims.azp) && tokenAudiences.includes(claims.azp)
  if (!hasAudience || (claims.azp && !acceptedAudiences.has(claims.azp)) ||
      !Number.isFinite(expiresAt) || expiresAt <= now || !Number.isFinite(issuedAt) || issuedAt > now + 60_000 ||
      !authorizedPartyValid || (claims.nbf !== undefined && (!Number.isFinite(notBefore) || notBefore > now)) ||
      !nonceMatches || typeof claims.sub !== "string" || claims.sub.length < 1 || claims.sub.length > 255) {
    throw httpError(401, "invalid_identity_token")
  }

  const email = typeof claims.email === "string" ? claims.email.trim().toLowerCase() : ""
  const emailVerified = claims.email_verified === true || claims.email_verified === "true"
  return {
    provider,
    subject: claims.sub,
    email,
    emailVerified,
    name: typeof claims.name === "string" ? claims.name : "",
  }
}

async function getKeys(provider, url, fetcher, now) {
  const cached = keyCache.get(provider)
  if (cached && cached.expiresAt > now) return cached.keys
  let response
  try {
    response = await fetcher(url, { signal: AbortSignal.timeout(5000) })
  } catch {
    throw httpError(503, "identity_provider_unavailable")
  }
  if (!response.ok) throw httpError(503, "identity_provider_unavailable")
  let body
  try { body = await response.json() } catch { throw httpError(503, "identity_provider_unavailable") }
  if (!Array.isArray(body.keys) || body.keys.length === 0) throw httpError(503, "identity_provider_unavailable")
  const maxAge = Number(response.headers.get("cache-control")?.match(/max-age=(\d+)/i)?.[1] ?? 300)
  const ttl = Math.min(Math.max(maxAge, 60), 3600) * 1000
  keyCache.set(provider, { keys: body.keys, expiresAt: now + ttl })
  return body.keys
}
