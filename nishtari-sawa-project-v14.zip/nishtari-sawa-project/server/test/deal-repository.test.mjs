import assert from "node:assert/strict"
import test from "node:test"
import { DealRepository } from "../src/deal-repository.mjs"

const dealId = "50000000-0000-4000-8000-000000000001"
const buyerId = "65000000-0000-4000-8000-000000000001"

function joinPool({
  maxQuantity,
  committed,
  stockQuantity = maxQuantity ?? 1_000_000,
  acceptsShipping = true,
  acceptsPickup = true,
  featureFlags = [],
  coupon = null,
  loyaltyBalance = 0,
  pointsPerEgp = 100,
  previousMembership = null,
}) {
  const statements = []
  const inserts = []
  const client = {
    async query(sql, params = []) {
      statements.push(sql)
      if (sql === "BEGIN" || sql === "COMMIT" || sql === "ROLLBACK") return { rows: [], rowCount: 0 }
      if (sql.includes("pg_advisory_xact_lock(hashtextextended")) return { rows: [], rowCount: 1 }
      if (sql.includes("SELECT d.id, d.unit_price_minor")) {
        return { rows: [{ id: dealId, unit_price_minor: "850", platform_subsidy_minor: "50", currency: "EGP", moq: 40, max_quantity: maxQuantity, stock_quantity: stockQuantity, accepts_shipping: acceptsShipping, accepts_pickup: acceptsPickup, ends_at: new Date(Date.now() + 60_000) }], rowCount: 1 }
      }
      if (sql.includes("SELECT setting_key, enabled FROM app_settings")) return { rows: featureFlags, rowCount: featureFlags.length }
      if (sql.includes("FROM coupons WHERE code")) return { rows: coupon ? [coupon] : [], rowCount: coupon ? 1 : 0 }
      if (sql.includes("count(*)::int AS total")) return { rows: [{ total: 0, buyer_total: 0 }], rowCount: 1 }
      if (sql.includes("SELECT id FROM users WHERE id = $1 FOR UPDATE")) return { rows: [{ id: buyerId }], rowCount: 1 }
      if (sql.includes("SELECT loyalty_points_per_egp FROM program_profile")) return { rows: [{ loyalty_points_per_egp: pointsPerEgp }], rowCount: 1 }
      if (sql.includes("FROM loyalty_ledger l")) return { rows: [{ balance: loyaltyBalance }], rowCount: 1 }
      if (sql.includes("SELECT m.id, m.deal_id")) return { rows: previousMembership ? [previousMembership] : [], rowCount: previousMembership ? 1 : 0 }
      if (sql.includes("UPDATE deal_memberships SET status = 'cancelled'")) return { rows: [], rowCount: 0 }
      if (sql.includes("SELECT COALESCE(SUM(quantity)")) return { rows: [{ quantity: String(committed) }], rowCount: 1 }
      if (sql.includes("SELECT id FROM deal_memberships")) return { rows: [], rowCount: 0 }
      if (sql.includes("INSERT INTO deal_memberships")) { inserts.push(params); return { rows: [{ id: "66000000-0000-4000-8000-000000000001", status: "pending_payment" }], rowCount: 1 } }
      if (sql.includes("INSERT INTO payments")) return { rows: [], rowCount: 1 }
      if (sql.includes("INSERT INTO coupon_redemptions")) return { rows: [], rowCount: 1 }
      if (sql.includes("INSERT INTO loyalty_ledger")) return { rows: [], rowCount: 1 }
      if (sql.includes("DELETE FROM cart_items")) return { rows: [], rowCount: 0 }
      if (sql.includes("SELECT id, full_name, phone, whatsapp_opt_in")) return { rows: [{ id: buyerId, full_name: "Test Buyer", phone: null, whatsapp_opt_in: false }] }
      if (sql.includes("INSERT INTO notification_outbox")) return { rows: [], rowCount: 0 }
      throw new Error(`Unexpected query: ${sql}`)
    },
    release() { statements.push("RELEASE") },
  }
  return { pool: { async connect() { return client } }, statements, inserts }
}

test("join rejects quantities that exceed the seller's remaining capacity", async () => {
  const { pool, statements } = joinPool({ maxQuantity: 100, committed: 99 })
  const repository = new DealRepository(pool)
  await assert.rejects(
    repository.join({ dealId, buyerId, quantity: 2, requestKey: "request-key-12345", fulfillmentMethod: "self_pickup" }),
    { statusCode: 409, code: "insufficient_stock" },
  )
  assert.ok(statements.includes("ROLLBACK"))
  assert.ok(!statements.some(sql => sql.includes("INSERT INTO payments")))
})

test("join records arbitrary positive quantities when the seller leaves capacity open", async () => {
  const { pool, statements } = joinPool({ maxQuantity: null, committed: 0 })
  const repository = new DealRepository(pool)
  const result = await repository.join({ dealId, buyerId, quantity: 7, requestKey: "request-key-67890", fulfillmentMethod: "self_pickup" })
  assert.equal(result.quantity, 7)
  assert.equal(result.amountMinor, 5950)
  assert.equal(result.paymentStatus, "not_configured")
  assert.ok(statements.includes("COMMIT"))
})

test("idempotent retries replay before availability checks and bind the request payload", async () => {
  const previousMembership = {
    id: "66000000-0000-4000-8000-000000000099",
    deal_id: dealId,
    status: "pending_payment",
    quantity: 2,
    fulfillment_method: "self_pickup",
    shipping_address: null,
    loyalty_points_used: 0,
    request_fingerprint: null,
    amount_minor: "1700",
    coupon_code: null,
  }
  const { pool, statements } = joinPool({ maxQuantity: 100, committed: 2, previousMembership })
  const repository = new DealRepository(pool)
  const payload = {
    dealId,
    buyerId,
    quantity: 2,
    requestKey: "request-key-replay-123",
    fulfillmentMethod: "self_pickup",
    appSettings: { orders_enabled: false, maintenance_mode: true },
  }

  const replay = await repository.join(payload)
  assert.equal(replay.repeated, true)
  assert.equal(replay.membershipId, previousMembership.id)
  assert.ok(statements.indexOf("COMMIT") > statements.findIndex((sql) => sql.includes("pg_advisory_xact_lock")))
  assert.ok(!statements.some((sql) => sql.includes("SELECT d.id, d.unit_price_minor")))
  await assert.rejects(repository.join({ ...payload, quantity: 3 }), { statusCode: 409, code: "idempotency_key_reused" })
})

test("new joins are rejected when orders are paused", async () => {
  const { pool, statements } = joinPool({ maxQuantity: 100, committed: 0 })
  const repository = new DealRepository(pool)
  await assert.rejects(
    repository.join({
      dealId,
      buyerId,
      quantity: 1,
      requestKey: "request-key-paused-123",
      fulfillmentMethod: "self_pickup",
      appSettings: { orders_enabled: false },
    }),
    { statusCode: 403, code: "orders_paused" },
  )
  assert.ok(!statements.some((sql) => sql.includes("SELECT d.id, d.unit_price_minor")))
})

test("expired reservations are cancelled and their benefits released atomically", async () => {
  const statements = []
  const client = {
    async query(sql, params = []) {
      statements.push({ sql, params })
      if (["BEGIN", "COMMIT", "ROLLBACK"].includes(sql)) return { rows: [], rowCount: 0 }
      if (sql.includes("WITH expired AS")) return { rows: [{ id: "66000000-0000-4000-8000-000000000010" }], rowCount: 1 }
      if (sql.includes("UPDATE coupon_redemptions")) return { rows: [], rowCount: 1 }
      if (sql.includes("UPDATE loyalty_ledger")) return { rows: [], rowCount: 1 }
      throw new Error(`Unexpected query: ${sql}`)
    },
    release() {},
  }
  const repository = new DealRepository({ async connect() { return client } })
  const result = await repository.expirePendingReservations()
  assert.deepEqual(result, { expired: 1 })
  assert.equal(statements.find((entry) => entry.sql.includes("WITH expired AS")).params[0], 500)
  assert.ok(statements.some((entry) => entry.sql.includes("UPDATE coupon_redemptions")))
  assert.ok(statements.some((entry) => entry.sql.includes("UPDATE loyalty_ledger")))
  assert.ok(statements.some((entry) => entry.sql === "COMMIT"))
})

test("join applies enabled subsidy, coupon, and loyalty discounts atomically", async () => {
  const now = Date.now()
  const featureFlags = [
    { setting_key: "platform_subsidies_enabled", enabled: true },
    { setting_key: "coupons_enabled", enabled: true },
    { setting_key: "loyalty_enabled", enabled: true },
  ]
  const coupon = {
    id: "77000000-0000-4000-8000-000000000001",
    code: "SAVE5",
    discount_type: "fixed",
    value: 500,
    min_order_minor: 0,
    max_discount_minor: null,
    usage_limit: null,
    per_user_limit: 1,
    starts_at: new Date(now - 60_000),
    ends_at: new Date(now + 60_000),
    enabled: true,
  }
  const { pool, inserts, statements } = joinPool({
    maxQuantity: null,
    committed: 0,
    featureFlags,
    coupon,
    loyaltyBalance: 500,
  })
  const repository = new DealRepository(pool)
  const result = await repository.join({
    dealId,
    buyerId,
    quantity: 7,
    requestKey: "request-key-discount-123",
    fulfillmentMethod: "self_pickup",
    couponCode: "SAVE5",
    loyaltyPointsToUse: 100,
  })

  assert.equal(result.amountMinor, 5000)
  assert.equal(result.platformSubsidyMinor, 350)
  assert.equal(result.couponDiscountMinor, 500)
  assert.equal(result.loyaltyDiscountMinor, 100)
  assert.equal(result.loyaltyPointsUsed, 100)
  assert.equal(inserts[0][8], 5000)
  assert.equal(inserts[0][9], 350)
  assert.equal(inserts[0][10], 500)
  assert.equal(inserts[0][11], 100)
  assert.ok(statements.some((sql) => sql.includes("SELECT id FROM users WHERE id = $1 FOR UPDATE")))
  assert.ok(statements.includes("COMMIT"))
})

test("join reserves against merchant stock and records shipping details", async () => {
  const { pool, inserts } = joinPool({ maxQuantity: null, committed: 10, stockQuantity: 20 })
  const repository = new DealRepository(pool)
  const result = await repository.join({
    dealId,
    buyerId,
    quantity: 5,
    requestKey: "request-key-shipping-1",
    fulfillmentMethod: "merchant_shipping",
    shippingAddress: "20 Main Street, Cairo",
  })
  assert.equal(result.fulfillmentMethod, "merchant_shipping")
  assert.equal(inserts[0][6], "merchant_shipping")
  assert.equal(inserts[0][7], "20 Main Street, Cairo")
  assert.equal(inserts[0][5], 15)
  assert.match(inserts[0][13], /^[a-f0-9]{64}$/)
})

test("join rejects a delivery choice the seller does not offer", async () => {
  const { pool, statements } = joinPool({ maxQuantity: 100, committed: 0, acceptsShipping: false })
  const repository = new DealRepository(pool)
  await assert.rejects(
    repository.join({ dealId, buyerId, quantity: 1, requestKey: "request-key-pickup-1", fulfillmentMethod: "merchant_shipping", shippingAddress: "20 Main Street, Cairo" }),
    { statusCode: 409, code: "shipping_not_available" },
  )
  assert.ok(!statements.some(sql => sql.includes("INSERT INTO payments")))
})

test("join cannot reserve more physical stock than the merchant owns", async () => {
  const { pool, statements } = joinPool({ maxQuantity: 100, committed: 18, stockQuantity: 20 })
  const repository = new DealRepository(pool)
  await assert.rejects(
    repository.join({ dealId, buyerId, quantity: 3, requestKey: "request-key-stock-1", fulfillmentMethod: "self_pickup" }),
    { statusCode: 409, code: "insufficient_stock" },
  )
  assert.ok(statements.includes("ROLLBACK"))
})

test("inventory cannot be reduced below reserved orders", async () => {
  const statements = []
  const client = {
    async query(sql) {
      statements.push(sql)
      if (["BEGIN", "COMMIT", "ROLLBACK"].includes(sql)) return { rows: [], rowCount: 0 }
      if (sql.includes("SELECT d.id, d.moq, d.stock_quantity")) {
        return { rows: [{ id: dealId, moq: 10, stock_quantity: 50, max_quantity: 100, accepts_shipping: true, accepts_pickup: true, committed_quantity: "15" }] }
      }
      if (sql.includes("UPDATE deals")) {
        return { rows: [{ id: dealId, stock_quantity: 30, max_quantity: null, accepts_shipping: false, accepts_pickup: true }] }
      }
      throw new Error(`Unexpected query: ${sql}`)
    },
    release() {},
  }
  const repository = new DealRepository({ async connect() { return client } })
  await assert.rejects(
    repository.updateDealInventory({ dealId, ownerUserId: buyerId, stockQuantity: 14 }),
    { statusCode: 409, code: "inventory_below_reserved" },
  )
  assert.ok(statements.includes("ROLLBACK"))

  const result = await repository.updateDealInventory({ dealId, ownerUserId: buyerId, stockQuantity: 30, maxQuantity: null, acceptsShipping: false, acceptsPickup: true })
  assert.equal(result.availableQuantity, 15)
  assert.equal(result.acceptsPickup, true)
})

test("shipping cannot be marked as dispatched without tracking details", async () => {
  const statements = []
  const client = {
    async query(sql) {
      statements.push(sql)
      if (["BEGIN", "COMMIT", "ROLLBACK"].includes(sql)) return { rows: [], rowCount: 0 }
      if (sql.includes("SELECT m.id, m.status AS order_status")) {
        return { rows: [{ id: "66000000-0000-4000-8000-000000000001", order_status: "held", payment_status: "paid", fulfillment_method: "merchant_shipping", fulfillment_status: "preparing", tracking_number: null, tracking_url: null, buyer_id: buyerId, buyer_total_minor: 850, name: "Test product" }] }
      }
      if (sql.includes("UPDATE deal_memberships")) {
        return { rows: [{ id: "66000000-0000-4000-8000-000000000001", fulfillment_status: "shipped", carrier_name: "Local Courier", tracking_number: "NS123", tracking_url: null, fulfillment_note: null, fulfillment_updated_at: new Date() }] }
      }
      if (sql.includes("SELECT id, full_name, phone, whatsapp_opt_in")) return { rows: [{ id: buyerId, full_name: "Test Buyer", phone: null, whatsapp_opt_in: false }] }
      if (sql.includes("INSERT INTO notification_outbox")) return { rows: [], rowCount: 0 }
      throw new Error(`Unexpected query: ${sql}`)
    },
    release() {},
  }
  const repository = new DealRepository({ async connect() { return client } })
  await assert.rejects(
    repository.setFulfillment({ membershipId: "66000000-0000-4000-8000-000000000001", status: "shipped" }),
    { statusCode: 400, code: "tracking_details_required" },
  )
  const updated = await repository.setFulfillment({
    membershipId: "66000000-0000-4000-8000-000000000001",
    status: "shipped",
    carrierName: "Local Courier",
    trackingNumber: "NS123",
  })
  assert.equal(updated.fulfillmentStatus, "shipped")
  assert.equal(updated.trackingNumber, "NS123")
  assert.ok(statements.includes("COMMIT"))
})

test("unpaid or unconfigured orders cannot enter fulfillment", async () => {
  const statements = []
  let lookup = 0
  const client = {
    async query(sql) {
      statements.push(sql)
      if (["BEGIN", "COMMIT", "ROLLBACK"].includes(sql)) return { rows: [], rowCount: 0 }
      if (sql.includes("SELECT m.id, m.status AS order_status")) {
        lookup += 1
        return { rows: [{
          id: "66000000-0000-4000-8000-000000000002",
          order_status: lookup === 1 ? "pending_payment" : "held",
          payment_status: "not_configured",
          fulfillment_method: "merchant_shipping",
          fulfillment_status: "not_started",
        }] }
      }
      throw new Error(`Unexpected query: ${sql}`)
    },
    release() {},
  }
  const repository = new DealRepository({ async connect() { return client } })
  await assert.rejects(
    repository.setFulfillment({ membershipId: "66000000-0000-4000-8000-000000000002", status: "preparing" }),
    { statusCode: 409, code: "order_not_fulfillable" },
  )
  await assert.rejects(
    repository.setFulfillment({ membershipId: "66000000-0000-4000-8000-000000000002", status: "preparing" }),
    { statusCode: 409, code: "order_not_fulfillable" },
  )
  assert.ok(!statements.some((sql) => sql.includes("UPDATE deal_memberships")))
})

test("fulfillment cannot move backwards", async () => {
  const client = {
    async query(sql) {
      if (["BEGIN", "COMMIT", "ROLLBACK"].includes(sql)) return { rows: [], rowCount: 0 }
      if (sql.includes("SELECT m.id, m.status AS order_status")) {
        return { rows: [{ id: "66000000-0000-4000-8000-000000000003", order_status: "held", payment_status: "paid", fulfillment_method: "merchant_shipping", fulfillment_status: "shipped" }] }
      }
      throw new Error(`Unexpected query: ${sql}`)
    },
    release() {},
  }
  const repository = new DealRepository({ async connect() { return client } })
  await assert.rejects(
    repository.setFulfillment({ membershipId: "66000000-0000-4000-8000-000000000003", status: "preparing" }),
    { statusCode: 409, code: "invalid_fulfillment_transition" },
  )
})

test("admin cancellation rejects progressed orders and preserves fulfillment history", async () => {
  const statements = []
  let cancellations = 0
  const client = {
    async query(sql) {
      statements.push(sql)
      if (["BEGIN", "COMMIT", "ROLLBACK"].includes(sql)) return { rows: [], rowCount: 0 }
      if (sql.includes("UPDATE deal_memberships") && sql.includes("fulfillment_status = 'not_started'")) {
        cancellations += 1
        return cancellations === 1 ? { rows: [], rowCount: 0 } : { rows: [{ id: "66000000-0000-4000-8000-000000000004", status: "cancelled" }], rowCount: 1 }
      }
      if (sql.includes("UPDATE coupon_redemptions") || sql.includes("UPDATE loyalty_ledger")) return { rows: [], rowCount: 1 }
      throw new Error(`Unexpected query: ${sql}`)
    },
    release() {},
  }
  const repository = new DealRepository({ async connect() { return client } })
  await assert.rejects(repository.cancelAdminOrder("66000000-0000-4000-8000-000000000004"), { statusCode: 404, code: "order_not_cancellable" })
  assert.deepEqual(await repository.cancelAdminOrder("66000000-0000-4000-8000-000000000004"), {
    membershipId: "66000000-0000-4000-8000-000000000004",
    status: "cancelled",
  })
  assert.ok(statements.filter((sql) => sql.includes("UPDATE deal_memberships")).every((sql) => !sql.includes("SET status = 'cancelled', fulfillment_status")))
})

test("a new offer keeps its pickup point without moving the seller's existing offers", async () => {
  const statements = []
  const client = {
    async query(sql, params = []) {
      statements.push({ sql, params })
      if (["BEGIN", "COMMIT", "ROLLBACK"].includes(sql)) return { rows: [], rowCount: 0 }
      if (sql.includes("SELECT id, business_name FROM supplier_profiles")) {
        return { rows: [{ id: "20000000-0000-4000-8000-000000000001", business_name: "Local Shop" }] }
      }
      if (sql.includes("INSERT INTO leader_profiles")) return { rows: [] }
      if (sql.includes("SELECT id FROM leader_profiles")) {
        return { rows: [{ id: "30000000-0000-4000-8000-000000000001" }] }
      }
      if (sql.includes("INSERT INTO products")) {
        return { rows: [{ id: "40000000-0000-4000-8000-000000000001" }] }
      }
      if (sql.includes("INSERT INTO deals")) {
        return { rows: [{ id: dealId, ends_at: new Date("2030-01-01T00:00:00Z"), status: "draft", created_at: new Date() }] }
      }
      throw new Error(`Unexpected query: ${sql}`)
    },
    release() {},
  }
  const repository = new DealRepository({ async connect() { return client } })
  const deal = await repository.createOffer({
    userId: "65000000-0000-4000-8000-000000000002",
    name: "Apples",
    category: "Fruit",
    emoji: "🍎",
    unit: "kg",
    price: 8,
    retailPrice: 12,
    moq: 10,
    maxQuantity: 80,
    stockQuantity: 80,
    acceptsShipping: true,
    acceptsPickup: true,
    latitude: 31.2,
    longitude: 29.9,
    pickupLabel: "Alexandria pickup point",
    endsAt: new Date("2030-01-01T00:00:00Z"),
  })

  const leaderInsert = statements.find(({ sql }) => sql.includes("INSERT INTO leader_profiles"))
  const dealInsert = statements.find(({ sql }) => sql.includes("INSERT INTO deals"))
  assert.match(leaderInsert.sql, /ON CONFLICT \(user_id\) DO NOTHING/)
  assert.match(dealInsert.sql, /pickup_location, pickup_label/)
  assert.deepEqual(dealInsert.params.slice(3, 6), [29.9, 31.2, "Alexandria pickup point"])
  assert.equal(deal.location, "Alexandria pickup point")
})
