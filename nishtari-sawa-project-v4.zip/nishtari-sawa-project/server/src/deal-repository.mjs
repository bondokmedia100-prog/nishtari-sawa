export class DealRepository {
  constructor(pool) {
    this.pool = pool
  }

  async nearby({ latitude, longitude, radiusKm }) {
    const { rows } = await this.pool.query(
      `SELECT d.id,
              p.name,
              p.category,
              p.emoji,
              p.unit_label AS unit,
              d.unit_price_minor,
              d.retail_price_minor,
              d.moq,
              d.ends_at,
              round((extensions.ST_Distance(lp.pickup_location, extensions.ST_SetSRID(extensions.ST_MakePoint($2, $1), 4326)::extensions.geography) / 1000.0)::numeric, 1) AS distance_km,
              COALESCE(SUM(m.quantity) FILTER (WHERE m.status = 'held'), 0)::int AS committed_quantity
       FROM deals d
       JOIN products p ON p.id = d.product_id AND p.is_active
       JOIN leader_profiles lp ON lp.id = d.leader_id
       LEFT JOIN deal_memberships m ON m.deal_id = d.id
       WHERE d.status = 'active'
         AND d.starts_at <= now()
         AND d.ends_at > now()
         AND extensions.ST_DWithin(lp.pickup_location, extensions.ST_SetSRID(extensions.ST_MakePoint($2, $1), 4326)::extensions.geography, $3 * 1000)
       GROUP BY d.id, p.id, lp.id
       ORDER BY d.ends_at ASC
       LIMIT 100`,
      [latitude, longitude, radiusKm],
    )
    return rows.map((row) => ({
      id: row.id,
      name: row.name,
      category: row.category,
      emoji: row.emoji,
      unit: row.unit,
      price: Number(row.unit_price_minor) / 100,
      retailPrice: Number(row.retail_price_minor) / 100,
      moq: row.moq,
      committedQuantity: row.committed_quantity,
      distanceKm: Number(row.distance_km),
      endsAt: row.ends_at,
    }))
  }

  async join({ dealId, buyerId, quantity, requestKey }) {
    const client = await this.pool.connect()
    try {
      await client.query("BEGIN")
      const { rows: deals } = await client.query(
        `SELECT d.id, d.unit_price_minor, d.currency, d.moq, d.max_quantity, d.ends_at
         FROM deals d WHERE d.id = $1 AND d.status = 'active' AND d.starts_at <= now() AND d.ends_at > now() FOR UPDATE`,
        [dealId],
      )
      const deal = deals[0]
      if (!deal || new Date(deal.ends_at) <= new Date()) throw httpError(404, "deal_not_available")
      const previous = await client.query(
        `SELECT m.id, m.deal_id, m.status, m.quantity, p.amount_minor
         FROM deal_memberships m JOIN payments p ON p.membership_id = m.id
         WHERE m.buyer_id = $1 AND m.request_key = $2 FOR UPDATE OF m`,
        [buyerId, requestKey],
      )
      if (previous.rowCount) {
        if (previous.rows[0].deal_id !== dealId) throw httpError(409, "idempotency_key_reused")
        await client.query("COMMIT")
        return { membershipId: previous.rows[0].id, status: previous.rows[0].status, quantity: previous.rows[0].quantity, amountMinor: Number(previous.rows[0].amount_minor), paymentStatus: "not_configured", repeated: true }
      }
      await client.query(
        `UPDATE deal_memberships SET status = 'cancelled'
         WHERE deal_id = $1 AND status = 'pending_payment' AND reservation_expires_at <= now()`,
        [dealId],
      )
      const current = await client.query(
        `SELECT COALESCE(SUM(quantity), 0)::int AS quantity
         FROM deal_memberships
         WHERE deal_id = $1 AND (status = 'held' OR (status = 'pending_payment' AND reservation_expires_at > now()))`,
        [dealId],
      )
      if (deal.max_quantity && current.rows[0].quantity + quantity > deal.max_quantity) throw httpError(409, "deal_capacity_reached")

      const existing = await client.query(
        "SELECT id FROM deal_memberships WHERE deal_id = $1 AND buyer_id = $2 FOR UPDATE",
        [dealId, buyerId],
      )
      if (existing.rowCount) throw httpError(409, "already_joined")

      const { rows: inserted } = await client.query(
        `INSERT INTO deal_memberships (deal_id, buyer_id, quantity, unit_price_minor, request_key, reservation_expires_at)
         VALUES ($1, $2, $3, $4, $5, now() + interval '15 minutes') RETURNING id, status`,
        [dealId, buyerId, quantity, deal.unit_price_minor, requestKey],
      )
      const amountMinor = Number(deal.unit_price_minor) * quantity
      await client.query(
        "INSERT INTO payments (membership_id, amount_minor, currency, status) VALUES ($1, $2, $3, 'not_configured')",
        [inserted[0].id, amountMinor, deal.currency],
      )
      await client.query("COMMIT")
      return { membershipId: inserted[0].id, status: inserted[0].status, quantity, amountMinor, paymentStatus: "not_configured", repeated: false }
    } catch (error) {
      await client.query("ROLLBACK")
      throw error
    } finally {
      client.release()
    }
  }
}

function httpError(statusCode, code) {
  return Object.assign(new Error(code), { statusCode, code })
}
