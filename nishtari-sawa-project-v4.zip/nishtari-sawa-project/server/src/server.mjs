import Fastify from "fastify"
import pg from "pg"
import { createHmac, timingSafeEqual } from "node:crypto"
import { DealRepository } from "./deal-repository.mjs"
import { runMigrations } from "./migrate.mjs"

const { Pool } = pg
const app = Fastify({ logger: true, bodyLimit: 16 * 1024 })
const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 10, connectionTimeoutMillis: 5000 })
const repository = new DealRepository(pool)
const jwtSecret = process.env.JWT_SECRET

if (!jwtSecret || jwtSecret.length < 32) throw new Error("JWT_SECRET must contain at least 32 characters")

await runMigrations(pool)

app.addHook("onSend", async (request, reply, payload) => {
  if (request.method === "GET" && request.url.startsWith("/api/v1/deals/nearby")) {
    reply.header("Access-Control-Allow-Origin", "*")
  }
  return payload
})

app.get("/", async (_request, reply) => reply.send({
  service: "Nishtari Sawa API",
  status: "ok",
  health: "/health",
  nearbyDeals: "/api/v1/deals/nearby?lat=30.0444&lng=31.2357&radius_km=2",
}))

app.get("/health", async (_request, reply) => {
  await pool.query("SELECT 1")
  return reply.send({ status: "ok", database: "connected" })
})

app.get("/api/v1/deals/nearby", async (request, reply) => {
  const latitude = Number(request.query.lat)
  const longitude = Number(request.query.lng)
  const radiusKm = Number(request.query.radius_km ?? 2)
  if (!Number.isFinite(latitude) || latitude < -90 || latitude > 90 || !Number.isFinite(longitude) || longitude < -180 || longitude > 180) {
    return reply.code(400).send({ error: "invalid_coordinates" })
  }
  if (!Number.isFinite(radiusKm) || radiusKm < 1 || radiusKm > 3) {
    return reply.code(400).send({ error: "radius_must_be_between_1_and_3_km" })
  }
  const deals = await repository.nearby({ latitude, longitude, radiusKm })
  return reply.send({ deals })
})

app.post("/api/v1/deals/:dealId/memberships", async (request, reply) => {
  const identity = verifyBuyer(request.headers.authorization)
  const requestKey = request.headers["idempotency-key"]
  const quantity = Number(request.body?.quantity)
  if (typeof requestKey !== "string" || requestKey.length < 12 || requestKey.length > 120) {
    return reply.code(400).send({ error: "valid_idempotency_key_required" })
  }
  if (!Number.isInteger(quantity) || quantity < 1 || quantity > 30) {
    return reply.code(400).send({ error: "quantity_must_be_1_to_30" })
  }
  const result = await repository.join({ dealId: request.params.dealId, buyerId: identity.sub, quantity, requestKey })
  return reply.code(result.repeated ? 200 : 202).send({ ...result, message: "payment_provider_not_connected" })
})

app.setErrorHandler((error, _request, reply) => {
  if (error.statusCode) return reply.code(error.statusCode).send({ error: error.code ?? "request_failed" })
  app.log.error(error)
  return reply.code(500).send({ error: "internal_error" })
})

function verifyBuyer(header) {
  if (!header?.startsWith("Bearer ")) throw Object.assign(new Error("unauthorized"), { statusCode: 401, code: "unauthorized" })
  const token = header.slice(7)
  const parts = token.split(".")
  if (parts.length !== 3) throw Object.assign(new Error("unauthorized"), { statusCode: 401, code: "unauthorized" })
  const [encodedHeader, encodedPayload, signature] = parts
  const expected = createHmac("sha256", jwtSecret).update(`${encodedHeader}.${encodedPayload}`).digest()
  let supplied
  try { supplied = Buffer.from(signature, "base64url") } catch { supplied = Buffer.alloc(0) }
  if (supplied.length !== expected.length || !timingSafeEqual(supplied, expected)) {
    throw Object.assign(new Error("unauthorized"), { statusCode: 401, code: "unauthorized" })
  }
  try {
    const headerJson = JSON.parse(Buffer.from(encodedHeader, "base64url").toString())
    const payload = JSON.parse(Buffer.from(encodedPayload, "base64url").toString())
    const isUuid = typeof payload.sub === "string" && /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(payload.sub)
    if (headerJson.alg !== "HS256" || !isUuid || payload.role !== "buyer" || !Number.isFinite(payload.exp) || payload.exp <= Date.now() / 1000) throw new Error()
    return payload
  } catch {
    throw Object.assign(new Error("unauthorized"), { statusCode: 401, code: "unauthorized" })
  }
}

const port = Number(process.env.PORT ?? 3000)
await app.listen({ host: "0.0.0.0", port })

for (const signal of ["SIGINT", "SIGTERM"]) {
  process.on(signal, async () => {
    await app.close()
    await pool.end()
    process.exit(0)
  })
}
