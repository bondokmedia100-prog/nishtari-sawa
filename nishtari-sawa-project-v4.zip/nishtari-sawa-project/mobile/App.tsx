import React, { useEffect, useState } from "react"
import { ActivityIndicator, Alert, FlatList, Linking, SafeAreaView, StatusBar, StyleSheet, Text, TouchableOpacity, View } from "react-native"
import * as Location from "expo-location"
import { Deal, getNearbyDeals, requestToJoin } from "./src/api"

const ORANGE = "#FF6F00"
const GREEN = "#2E7D32"

function Countdown({ endsAt }: { endsAt: string }) {
  const [now, setNow] = useState(Date.now())
  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1000)
    return () => clearInterval(timer)
  }, [])
  const seconds = Math.max(0, Math.floor((new Date(endsAt).getTime() - now) / 1000))
  return <Text style={styles.timer}>{Math.floor(seconds / 3600)}س {Math.floor(seconds % 3600 / 60)}د {String(seconds % 60).padStart(2, "0")}ث</Text>
}

export default function App() {
  const [deals, setDeals] = useState<Deal[]>([])
  const [loading, setLoading] = useState(true)
  const [locationMessage, setLocationMessage] = useState("بنحدد مكانك...")
  const [error, setError] = useState("")

  async function loadDeals() {
    setLoading(true)
    setError("")
    try {
      const permission = await Location.requestForegroundPermissionsAsync()
      if (permission.status !== "granted") throw new Error("اسمحلنا بالموقع عشان نجيبلك صفقات قريبة.")
      const position = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced })
      setLocationMessage("صفقات قريبة منك · في نطاق ٢ كم")
      setDeals(await getNearbyDeals(position.coords.latitude, position.coords.longitude))
    } catch (err) {
      setError(err instanceof Error ? err.message : "حصلت مشكلة وإحنا بنجيب الصفقات.")
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { void loadDeals() }, [])

  async function join(deal: Deal) {
    try {
      const result = await requestToJoin(deal.id, 1)
      Alert.alert("طلبك اتسجل", result.message === "payment_provider_not_connected" ? "الدفع لسه مش متوصل؛ مفيش فلوس هتتخصم." : "هنأكدلك طلبك قريب.")
    } catch (err) {
      Alert.alert("محتاجين نكمّل خطوة", err instanceof Error ? err.message : "جرّب تاني كمان شوية.")
    }
  }

  function share(deal: Deal) {
    const message = `يلا نشتري سوا ${deal.name} بسعر ${deal.price.toFixed(2)} جنيه! فاضل ${Math.max(0, deal.moq - deal.committedQuantity)} وحدة ونوصل لسعر الجملة.`
    void Linking.openURL(`https://wa.me/?text=${encodeURIComponent(message)}`)
  }

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="dark-content" backgroundColor="#F5F5F5" />
      <View style={styles.header}>
        <View><Text style={styles.greeting}>صباح الفل 👋</Text><Text style={styles.location}>{locationMessage}</Text></View>
        <View style={styles.brand}><Text style={styles.brandMark}>↗</Text></View>
      </View>
      <View style={styles.titleRow}><View><Text style={styles.title}>نشتريها سوا</Text><Text style={styles.subtitle}>كل ما العدد يكمل، التوفير يزيد 🤝</Text></View><Text style={styles.live}>● شغّال</Text></View>
      {loading ? <View style={styles.center}><ActivityIndicator color={ORANGE} size="large" /><Text style={styles.emptyText}>بنلفّ على صفقات قريبة منك...</Text></View> : error ? <View style={styles.center}><Text style={styles.emptyIcon}>📍</Text><Text style={styles.emptyTitle}>مش قادرين نجيب الصفقات</Text><Text style={styles.emptyText}>{error}</Text><TouchableOpacity onPress={() => void loadDeals()} style={styles.retry}><Text style={styles.joinText}>جرّب تاني</Text></TouchableOpacity></View> : (
        <FlatList
          data={deals}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.list}
          refreshing={loading}
          onRefresh={() => void loadDeals()}
          ListEmptyComponent={<View style={styles.center}><Text style={styles.emptyIcon}>🧭</Text><Text style={styles.emptyTitle}>مفيش صفقات جنبك دلوقتي</Text><Text style={styles.emptyText}>هنعرضلك الجديد أول ما يفتح في منطقتك.</Text></View>}
          renderItem={({ item }) => {
            const progress = Math.min(100, Math.round(item.committedQuantity / item.moq * 100))
            const savings = Math.max(0, Math.round((1 - item.price / item.retailPrice) * 100))
            return <View style={styles.card}>
              <View style={styles.productRow}>
                <View style={styles.art}><Text style={styles.emoji}>{item.emoji}</Text></View>
                <View style={styles.productInfo}><Text style={styles.category}>{item.category} · {item.distanceKm.toFixed(1)} كم</Text><Text style={styles.name}>{item.name}</Text><Text style={styles.pickup}>📍 استلام من نقطة قريبة</Text></View>
                <Text style={styles.discount}>وفر {savings}٪</Text>
              </View>
              <View style={styles.priceRow}><Text style={styles.price}>{item.price.toFixed(2)} <Text style={styles.currency}>جنيه / {item.unit}</Text></Text><Text style={styles.oldPrice}>{item.retailPrice.toFixed(2)} جنيه</Text></View>
              <View style={styles.progressLabels}><Text style={styles.progressCount}>{item.committedQuantity} من {item.moq} وحدة</Text><Text style={styles.progressHint}>لسعر الجملة</Text></View>
              <View style={styles.track}><View style={[styles.fill, { width: `${progress}%` }]} /></View>
              <View style={styles.footer}><View><Text style={styles.timerLabel}>العرض هيخلص كمان</Text><Countdown endsAt={item.endsAt} /></View><View style={styles.actions}><TouchableOpacity style={styles.shareButton} onPress={() => share(item)}><Text style={styles.shareText}>شارك</Text></TouchableOpacity><TouchableOpacity style={styles.joinButton} onPress={() => void join(item)}><Text style={styles.joinText}>انضم معانا</Text></TouchableOpacity></View></View>
            </View>
          }}
        />
      )}
      <View style={styles.tabs}><Text style={styles.activeTab}>⌂  الرئيسية</Text><Text style={styles.tab}>♡  طلباتي</Text><Text style={styles.tab}>♙  حسابي</Text></View>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#F5F5F5" },
  header: { paddingHorizontal: 20, paddingTop: 12, paddingBottom: 20, flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  greeting: { fontSize: 24, fontWeight: "800", color: "#202925", textAlign: "right" },
  location: { fontSize: 12, color: "#68736E", marginTop: 3, textAlign: "right" },
  brand: { width: 38, height: 38, borderRadius: 13, backgroundColor: ORANGE, alignItems: "center", justifyContent: "center" },
  brandMark: { fontSize: 22, color: "white", fontWeight: "800" },
  titleRow: { paddingHorizontal: 20, paddingBottom: 13, flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  title: { fontSize: 20, fontWeight: "800", color: "#202925", textAlign: "right" },
  subtitle: { fontSize: 11, color: "#707B75", marginTop: 2, textAlign: "right" },
  live: { color: GREEN, backgroundColor: "#E7F2E7", paddingHorizontal: 9, paddingVertical: 5, borderRadius: 10, fontSize: 10, fontWeight: "700" },
  list: { paddingHorizontal: 14, paddingBottom: 14 },
  card: { backgroundColor: "white", borderRadius: 18, padding: 14, marginBottom: 11, borderWidth: 1, borderColor: "#ECEEEC" },
  productRow: { flexDirection: "row", alignItems: "center", gap: 9 },
  art: { width: 57, height: 57, backgroundColor: "#FFF4E9", borderRadius: 14, justifyContent: "center", alignItems: "center" },
  emoji: { fontSize: 31 },
  productInfo: { flex: 1, alignItems: "flex-end" },
  category: { color: GREEN, fontSize: 10, fontWeight: "700" },
  name: { color: "#202925", fontSize: 15, fontWeight: "800", marginTop: 2, textAlign: "right" },
  pickup: { color: "#727C76", fontSize: 9, marginTop: 3, textAlign: "right" },
  discount: { alignSelf: "flex-start", backgroundColor: "#FFF0E3", color: "#B65000", borderRadius: 7, paddingHorizontal: 6, paddingVertical: 4, fontSize: 9, fontWeight: "800" },
  priceRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "baseline", marginTop: 13 },
  price: { color: ORANGE, fontSize: 20, fontWeight: "800" },
  currency: { color: "#59645E", fontSize: 10, fontWeight: "500" },
  oldPrice: { color: "#929A95", fontSize: 10, textDecorationLine: "line-through" },
  progressLabels: { flexDirection: "row", justifyContent: "space-between", marginTop: 10 },
  progressCount: { color: "#36433B", fontSize: 10, fontWeight: "800" },
  progressHint: { color: "#7A847E", fontSize: 9 },
  track: { height: 7, borderRadius: 6, backgroundColor: "#EDF0ED", overflow: "hidden", marginTop: 5 },
  fill: { height: "100%", borderRadius: 6, backgroundColor: ORANGE },
  footer: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-end", marginTop: 12 },
  timerLabel: { color: "#7A847E", fontSize: 8 },
  timer: { color: "#202925", fontSize: 11, fontWeight: "800", fontVariant: ["tabular-nums"] },
  actions: { flexDirection: "row", gap: 6 },
  shareButton: { paddingHorizontal: 10, paddingVertical: 8, borderRadius: 9, borderWidth: 1, borderColor: "#E3E9E3" },
  shareText: { color: GREEN, fontSize: 10, fontWeight: "700" },
  joinButton: { backgroundColor: ORANGE, paddingHorizontal: 12, paddingVertical: 8, borderRadius: 9 },
  retry: { marginTop: 14, backgroundColor: ORANGE, paddingVertical: 9, paddingHorizontal: 18, borderRadius: 10 },
  joinText: { color: "white", fontSize: 10, fontWeight: "800" },
  center: { flex: 1, alignItems: "center", justifyContent: "center", padding: 30 },
  emptyIcon: { fontSize: 35 },
  emptyTitle: { fontSize: 16, fontWeight: "800", color: "#202925", marginTop: 9, textAlign: "center" },
  emptyText: { fontSize: 12, color: "#707B75", textAlign: "center", marginTop: 6 },
  tabs: { height: 56, backgroundColor: "white", borderTopWidth: 1, borderTopColor: "#E8EAE8", flexDirection: "row", justifyContent: "space-around", alignItems: "center" },
  tab: { fontSize: 10, color: "#89918C" },
  activeTab: { fontSize: 10, color: ORANGE, fontWeight: "800" },
})
