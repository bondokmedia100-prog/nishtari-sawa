import * as SecureStore from "expo-secure-store"

export type Deal = {
  id: string
  name: string
  category: string
  emoji: string
  unit: string
  price: number
  retailPrice: number
  moq: number
  committedQuantity: number
  distanceKm: number
  endsAt: string
}

const API_URL = process.env.EXPO_PUBLIC_API_URL?.replace(/\/$/, "")

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  if (!API_URL) throw new Error("ظبّط عنوان السيرفر الأول في EXPO_PUBLIC_API_URL")
  const response = await fetch(`${API_URL}${path}`, {
    ...init,
    headers: { "Content-Type": "application/json", ...init?.headers },
  })
  const body = await response.json().catch(() => ({}))
  if (!response.ok) throw new Error(body.error ?? `server_error_${response.status}`)
  return body as T
}

export async function getNearbyDeals(latitude: number, longitude: number): Promise<Deal[]> {
  const params = new URLSearchParams({ lat: String(latitude), lng: String(longitude), radius_km: "2" })
  const result = await request<{ deals: Deal[] }>(`/api/v1/deals/nearby?${params}`)
  return result.deals
}

export async function requestToJoin(dealId: string, quantity: number) {
  const token = await SecureStore.getItemAsync("nishtari_access_token")
  if (!token) throw new Error("سجّل دخولك الأول؛ تسجيل الدخول لسه مش متوصل.")
  const key = `${Date.now()}-${Math.random().toString(36).slice(2, 18)}`
  return request<{ membershipId: string; paymentStatus: string; message: string }>(`/api/v1/deals/${dealId}/memberships`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "Idempotency-Key": key },
    body: JSON.stringify({ quantity }),
  })
}
